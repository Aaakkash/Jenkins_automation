# Windows Server 2016/2019 to 2022 In-Place Upgrade Automation

This project provides a guarded Jenkins and Ansible workflow for upgrading
approved Windows Server 2016/2019 Desktop Experience virtual machines to
Windows Server 2022.

## Automation flow

```text
Jenkins -> Azure Repos -> CyberArk -> Ansible -> Target Windows Server
                                      |
                                      +-> DFS ISO repository
                                      +-> VMware vCenter API
```

- Jenkins controls parameters, approvals, execution gates, artifacts and email.
- Azure Repos stores the Jenkinsfile, playbooks, roles and configuration.
- CyberArk-managed Jenkins credentials inject Windows and vCenter secrets only
  for the stage that needs them.
- Ansible runs from the dedicated `ansible-runner` Jenkins agent.
- DFS supplies the approved ISO directly to each target with Robocopy.
- vCenter API creates, reverts and removes upgrade snapshots.

## Implemented controls

1. ISO is copied directly from DFS, not through WinRM, and SHA-256 validated.
2. Windows 2016/2019, Standard/Datacenter and Desktop Experience are enforced.
3. Domain controllers, cluster nodes, evaluation editions, low disk space and
   unresolved pending reboot are blocked.
4. An approved Jenkins parameter can reboot once to clear pending operations.
5. Native Windows Setup `/compat scanonly` must pass before upgrade.
6. SQL Server detection requires DBA backup confirmation and a DBA change task.
7. A quiesced vCenter snapshot is created before any service is stopped.
8. CredSSP server state is recorded, enabled only when absent, then restored.
9. MSSQLSERVER and IISADMIN are recorded and stopped only when present; their
   original startup/running state is restored after upgrade.
10. Upgrade runs as a one-time scheduled task under SYSTEM and survives WinRM
    interruption and multiple restarts.
11. .NET Framework 4.8.1 is checked and installed from DFS only when missing.
12. Netlogon is set to Automatic and started.
13. SCCM (`CcmExec`), Defender (`WinDefend` and AntivirusEnabled), domain secure
    channel, expected services, OS version and .NET are validated.
14. Assessment, compatibility, postcheck and final JSON reports are archived.
15. Jenkins emails success/failure with reports attached.
16. Snapshot recovery is available after failure when explicitly pre-authorized.
17. Snapshot deletion requires application-owner validation.

## Safety decision for snapshot recovery

`RECOVER_ON_FAILURE` defaults to `false`. Select it before starting the upgrade
only when the approved change authorizes snapshot reversion. When selected, a
failure after snapshot creation triggers the vCenter revert. This prevents an
unapproved rollback from discarding evidence or application/database changes.

## Required configuration

Update `inventories/test/group_vars/windows_upgrade.yml`:

- DFS path and approved ISO SHA-256
- vCenter hostname, datacenter and optional VM folder
- .NET Framework 4.8.1 installer DFS path
- SCCM and Defender enforcement policy
- notification addresses if Ansible SMTP notification is enabled

Replace the test hostname in `inventories/test/hosts.yml`.

Configure these Jenkins credentials as CyberArk-managed/dynamic credentials:

```text
cyberark-windows-upgrade-account
cyberark-vcenter-upgrade-account
```

The Jenkins agent requires network access to Azure Repos, CyberArk, WinRM 5986,
DFS SMB 445, vCenter API and the notification relay.

## Controller dependencies

Install Python dependencies:

```bash
python3 -m pip install -r requirements.txt
```

Install Ansible collections:

```bash
ansible-galaxy collection install -r requirements.yml
```

## Playbooks

| Playbook | Purpose |
|---|---|
| `00_stage_iso.yml` | Download and validate ISO from DFS |
| `01_assess.yml` | Read-only eligibility assessment; optional approved reboot |
| `02_compatibility_scan.yml` | Windows Setup scan-only validation |
| `03_upgrade.yml` | Snapshot, CredSSP, services, upgrade and postchecks |
| `04_post_validate.yml` | Rerun remediation and technical validation |
| `05_recover_snapshot.yml` | Separately approved snapshot recovery |
| `06_cleanup_snapshot.yml` | Remove snapshot after application validation |

## Recommended first test

Use a disposable non-production Windows Server 2016 VM with a verified backup.

1. Set `RUN_UPGRADE=false`.
2. Run ISO staging, assessment and compatibility scanning.
3. Review `reports/` and Windows Setup logs.
4. Confirm snapshot create/revert/remove on the disposable VM.
5. Confirm SQL/IIS service restoration, CredSSP cleanup and notifications.
6. Enable the real upgrade only after the above tests pass.

## Recovery rule

A VMware snapshot is a short-term recovery control, not a backup. SQL servers
still require the DBA backup/change task. Keep the snapshot until technical and
application validation succeeds, then remove it through the cleanup playbook.

