# Changelog

## 2.0.0

- Added direct DFS ISO staging with Robocopy and SHA-256 validation.
- Added Azure Repos checkout and CyberArk-managed Jenkins credential IDs.
- Added optional approved reboot for pending-reboot remediation.
- Added vCenter API snapshot create, recovery and cleanup playbooks.
- Added SQL detection with mandatory DBA backup/change confirmation.
- Added MSSQLSERVER and IISADMIN state capture, stop and restore handling.
- Added CredSSP state capture, conditional enablement and cleanup.
- Added conditional .NET Framework 4.8.1 installation from DFS.
- Added Netlogon Automatic/running enforcement.
- Added SCCM, Defender, .NET, domain and service postchecks.
- Added final JSON reports and Jenkins success/failure notifications.
- Added application-owner approval gate before snapshot removal.

