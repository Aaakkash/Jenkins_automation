# Implementation Checklist

## Jenkins and Azure Repos

- Create a multibranch or pipeline job connected to the approved Azure Repo.
- Run the job on a dedicated agent labelled `ansible-runner`.
- Install the Email Extension plugin if `emailext` will be used.
- Protect production branches and require peer review.

## CyberArk

- Configure Jenkins/CyberArk integration for dynamic credential retrieval.
- Map the Windows credential to `cyberark-windows-upgrade-account`.
- Map the least-privilege vCenter credential to
  `cyberark-vcenter-upgrade-account`.
- Do not save passwords in inventory, Git, playbooks or console output.

## Target and network

- Allow WinRM HTTPS 5986 from the Ansible runner.
- Allow SMB 445 from target servers to the DFS namespace/targets.
- Confirm DNS, time synchronization and trusted WinRM certificates.
- Confirm the Windows automation account can run elevated PowerShell and Setup.

## Media

- Put the approved Windows Server 2022 ISO in DFS.
- Record its SHA-256 in group variables.
- Confirm language, edition, architecture and Desktop Experience compatibility.
- Put the approved .NET Framework 4.8.1 offline installer in DFS.

## VMware and recovery

- Configure vCenter hostname, datacenter, VM mapping and certificate validation.
- Grant snapshot create/read/remove/revert permissions according to policy.
- Test snapshot recovery on a disposable VM before enabling it in the pipeline.
- Confirm a valid enterprise backup; snapshots do not replace backups.

## SQL and applications

- For MSSQLSERVER, obtain DBA backup confirmation and change-task number.
- Confirm whether IISADMIN is used by the application.
- Add application-specific ports, services and health checks before production.
- Obtain application-owner validation before snapshot removal.

## Go-live gates

- Assessment passed.
- Compatibility scan returned `0xC1900210`.
- Backup and snapshot confirmed.
- SQL backup confirmed when applicable.
- Change window active and upgrade approved.
- SCCM, Defender, .NET, Netlogon and application checks passed.
- Reports archived and Windows team notified.

