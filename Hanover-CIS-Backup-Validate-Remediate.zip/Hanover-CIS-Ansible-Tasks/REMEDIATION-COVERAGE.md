# Remediation coverage

220 controls have remediation task paths; 3.1.1 requires IPv6 identification only. Policy-dependent tasks execute after their reviewed inputs are supplied. They are not unconditional automatic fixes. All changes retain validation, backups and post-validation.

| Check | Requirement | Implementation |
|---|---|---|
| 1.1.1.1 | Ensure cramfs kernel module is not available | Remediation tasks implemented |
| 1.1.1.2 | Ensure freevxfs kernel module is not available | Remediation tasks implemented |
| 1.1.1.3 | Ensure hfs kernel module is not available | Remediation tasks implemented |
| 1.1.1.4 | Ensure hfsplus kernel module is not available | Remediation tasks implemented |
| 1.1.1.5 | Ensure jffs2 kernel module is not available | Remediation tasks implemented |
| 1.1.1.8 | Ensure usb-storage kernel module is not available | Remediation tasks implemented |
| 1.1.1.9 | Ensure unused filesystems kernel modules are not available | Guarded remediation; requires reviewed inputs |
| 1.1.2.1.1 | Ensure /tmp is a separate partition | Remediation tasks implemented |
| 1.1.2.1.2 | Ensure nodev option set on /tmp partition | Remediation tasks implemented |
| 1.1.2.1.3 | Ensure nosuid option set on /tmp partition | Remediation tasks implemented |
| 1.1.2.1.4 | Ensure noexec option set on /tmp partition | Remediation tasks implemented |
| 1.1.2.2.1 | Ensure /dev/shm is a separate partition | Remediation tasks implemented |
| 1.1.2.2.2 | Ensure nodev option set on /dev/shm partition | Remediation tasks implemented |
| 1.1.2.2.3 | Ensure nosuid option set on /dev/shm partition | Remediation tasks implemented |
| 1.1.2.2.4 | Ensure noexec option set on /dev/shm partition | Remediation tasks implemented |
| 1.1.2.3.2 | Ensure nodev option set on /home partition | Remediation tasks implemented |
| 1.1.2.3.3 | Ensure nosuid option set on /home partition | Remediation tasks implemented |
| 1.1.2.4.2 | Ensure nodev option set on /var partition | Remediation tasks implemented |
| 1.1.2.4.3 | Ensure nosuid option set on /var partition | Remediation tasks implemented |
| 1.1.2.5.2 | Ensure nodev option set on /var/tmp partition | Remediation tasks implemented |
| 1.1.2.5.3 | Ensure nosuid option set on /var/tmp partition | Remediation tasks implemented |
| 1.1.2.5.4 | Ensure noexec option set on /var/tmp partition | Remediation tasks implemented |
| 1.1.2.6.2 | Ensure nodev option set on /var/log partition | Remediation tasks implemented |
| 1.1.2.6.3 | Ensure nosuid option set on /var/log partition | Remediation tasks implemented |
| 1.1.2.6.4 | Ensure noexec option set on /var/log partition | Remediation tasks implemented |
| 1.1.2.7.2 | Ensure nodev option set on /var/log/audit partition | Remediation tasks implemented |
| 1.1.2.7.3 | Ensure nosuid option set on /var/log/audit partition | Remediation tasks implemented |
| 1.1.2.7.4 | Ensure noexec option set on /var/log/audit partition | Remediation tasks implemented |
| 1.2.1.1 | Ensure GPG keys are configured | Remediation tasks implemented |
| 1.2.1.2 | Ensure gpgcheck is globally activated | Remediation tasks implemented |
| 1.2.1.4 | Ensure package manager repositories are configured | Guarded remediation; requires reviewed inputs |
| 1.2.2.1 | Ensure updates, patches, and additional security software are installed | Remediation tasks implemented |
| 1.3.1.1 | Ensure SELinux is installed | Remediation tasks implemented |
| 1.3.1.2 | Ensure SELinux is not disabled in bootloader configuration | Remediation tasks implemented |
| 1.3.1.3 | Ensure SELinux policy is configured | Remediation tasks implemented |
| 1.3.1.4 | Ensure the SELinux mode is not disabled | Remediation tasks implemented |
| 1.3.1.7 | Ensure the MCS Translation Service (mcstrans) is not installed | Remediation tasks implemented |
| 1.3.1.8 | Ensure SETroubleshoot is not installed | Remediation tasks implemented |
| 1.4.1 | Ensure bootloader password is set | Remediation tasks implemented |
| 1.4.2 | Ensure access to bootloader config is configured | Remediation tasks implemented |
| 1.5.1 | Ensure address space layout randomization is enabled | Remediation tasks implemented |
| 1.5.2 | Ensure ptrace_scope is restricted | Remediation tasks implemented |
| 1.5.3 | Ensure core dump backtraces are disabled | Remediation tasks implemented |
| 1.5.4 | Ensure core dump storage is disabled | Remediation tasks implemented |
| 1.6.1 | Ensure system wide crypto policy is not set to legacy | Remediation tasks implemented |
| 1.6.2 | Ensure system wide crypto policy is not set in sshd configuration | Remediation tasks implemented |
| 1.6.3 | Ensure system wide crypto policy disables sha1 hash and signature support | Remediation tasks implemented |
| 1.6.4 | Ensure system wide crypto policy disables macs less than 128 bits | Remediation tasks implemented |
| 1.6.5 | Ensure system wide crypto policy disables cbc for ssh | Remediation tasks implemented |
| 1.6.6 | Ensure system wide crypto policy disables chacha20-poly1305 for ssh | Remediation tasks implemented |
| 1.6.7 | Ensure system wide crypto policy disables EtM for ssh | Remediation tasks implemented |
| 1.7.1 | Ensure message of the day is configured properly | Remediation tasks implemented |
| 1.7.2 | Ensure local login warning banner is configured properly | Remediation tasks implemented |
| 1.7.3 | Ensure remote login warning banner is configured properly | Remediation tasks implemented |
| 1.7.4 | Ensure access to /etc/motd is configured | Remediation tasks implemented |
| 1.7.5 | Ensure access to /etc/issue is configured | Remediation tasks implemented |
| 1.7.6 | Ensure access to /etc/issue.net is configured | Remediation tasks implemented |
| 1.8.2 | Ensure GDM login banner is configured | Remediation tasks implemented |
| 1.8.3 | Ensure GDM disable-user-list option is enabled | Remediation tasks implemented |
| 1.8.4 | Ensure GDM screen locks when the user is idle | Remediation tasks implemented |
| 1.8.5 | Ensure GDM screen locks cannot be overridden | Remediation tasks implemented |
| 1.8.6 | Ensure GDM automatic mounting of removable media is disabled | Remediation tasks implemented |
| 1.8.7 | Ensure GDM disabling automatic mounting of removable media is not overridden | Remediation tasks implemented |
| 1.8.8 | Ensure GDM autorun-never is enabled | Remediation tasks implemented |
| 1.8.9 | Ensure GDM autorun-never is not overridden | Remediation tasks implemented |
| 1.8.10 | Ensure XDMCP is not enabled | Remediation tasks implemented |
| 2.1.1 | Ensure autofs services are not in use | Remediation tasks implemented |
| 2.1.2 | Ensure avahi daemon services are not in use | Remediation tasks implemented |
| 2.1.3 | Ensure dhcp server services are not in use | Remediation tasks implemented |
| 2.1.4 | Ensure dns server services are not in use | Remediation tasks implemented |
| 2.1.5 | Ensure dnsmasq services are not in use | Remediation tasks implemented |
| 2.1.7 | Ensure ftp server services are not in use | Remediation tasks implemented |
| 2.1.8 | Ensure message access server services are not in use | Remediation tasks implemented |
| 2.1.9 | Ensure network file system services are not in use | Remediation tasks implemented |
| 2.1.10 | Ensure nis server services are not in use | Remediation tasks implemented |
| 2.1.11 | Ensure print server services are not in use | Remediation tasks implemented |
| 2.1.13 | Ensure rsync services are not in use | Remediation tasks implemented |
| 2.1.14 | Ensure snmp services are not in use | Remediation tasks implemented |
| 2.1.15 | Ensure telnet server services are not in use | Remediation tasks implemented |
| 2.1.16 | Ensure tftp server services are not in use | Remediation tasks implemented |
| 2.1.17 | Ensure web proxy server services are not in use | Remediation tasks implemented |
| 2.1.18 | Ensure web server services are not in use | Remediation tasks implemented |
| 2.1.19 | Ensure xinetd services are not in use | Remediation tasks implemented |
| 2.1.21 | Ensure mail transfer agents are configured for local-only mode | Remediation tasks implemented |
| 2.1.22 | Ensure only approved services are listening on a network interface | Guarded remediation; requires reviewed inputs |
| 2.2.1 | Ensure ftp client is not installed | Remediation tasks implemented |
| 2.2.3 | Ensure nis client is not installed | Remediation tasks implemented |
| 2.2.4 | Ensure telnet client is not installed | Remediation tasks implemented |
| 2.2.5 | Ensure tftp client is not installed | Remediation tasks implemented |
| 2.3.1 | Ensure time synchronization is in use | Remediation tasks implemented |
| 2.3.2 | Ensure chrony is configured | Remediation tasks implemented |
| 2.3.3 | Ensure chrony is not run as the root user | Remediation tasks implemented |
| 2.4.1.1 | Ensure cron daemon is enabled and active | Remediation tasks implemented |
| 2.4.1.2 | Ensure permissions on /etc/crontab are configured | Remediation tasks implemented |
| 2.4.1.3 | Ensure permissions on /etc/cron.hourly are configured | Remediation tasks implemented |
| 2.4.1.4 | Ensure permissions on /etc/cron.daily are configured | Remediation tasks implemented |
| 2.4.1.5 | Ensure permissions on /etc/cron.weekly are configured | Remediation tasks implemented |
| 2.4.1.6 | Ensure permissions on /etc/cron.monthly are configured | Remediation tasks implemented |
| 2.4.1.7 | Ensure permissions on /etc/cron.d are configured | Remediation tasks implemented |
| 2.4.1.8 | Ensure crontab is restricted to authorized users | Remediation tasks implemented |
| 2.4.2.1 | Ensure at is restricted to authorized users | Remediation tasks implemented |
| 3.1.1 | Ensure IPv6 status is identified | Identification only (as required by source) |
| 3.1.2 | Ensure wireless interfaces are disabled | Remediation tasks implemented |
| 3.1.3 | Ensure bluetooth services are not in use | Remediation tasks implemented |
| 3.3.1 | Ensure ip forwarding is disabled | Remediation tasks implemented |
| 3.3.2 | Ensure packet redirect sending is disabled | Remediation tasks implemented |
| 3.3.3 | Ensure bogus icmp responses are ignored | Remediation tasks implemented |
| 3.3.4 | Ensure broadcast icmp requests are ignored | Remediation tasks implemented |
| 3.3.5 | Ensure icmp redirects are not accepted | Remediation tasks implemented |
| 3.3.6 | Ensure secure icmp redirects are not accepted | Remediation tasks implemented |
| 3.3.7 | Ensure reverse path filtering is enabled | Remediation tasks implemented |
| 3.3.8 | Ensure source routed packets are not accepted | Remediation tasks implemented |
| 3.3.9 | Ensure suspicious packets are logged | Remediation tasks implemented |
| 3.3.10 | Ensure tcp syn cookies is enabled | Remediation tasks implemented |
| 3.3.11 | Ensure ipv6 router advertisements are not accepted | Remediation tasks implemented |
| 4.1.1 | Ensure nftables is installed | Remediation tasks implemented |
| 4.2.1 | Ensure firewalld drops unnecessary services and ports | Guarded remediation; requires reviewed inputs |
| 4.2.2 | Ensure firewalld loopback traffic is configured | Remediation tasks implemented |
| 4.3.1 | Ensure nftables base chains exist | Remediation tasks implemented |
| 4.3.2 | Ensure nftables established connections are configured | Remediation tasks implemented |
| 4.3.3 | Ensure nftables default deny firewall policy | Guarded remediation; requires reviewed inputs |
| 5.1.1 | Ensure permissions on /etc/ssh/sshd_config are configured | Remediation tasks implemented |
| 5.1.2 | Ensure permissions on SSH private host key files are configured | Remediation tasks implemented |
| 5.1.3 | Ensure permissions on SSH public host key files are configured | Remediation tasks implemented |
| 5.1.4 | Ensure sshd Ciphers are configured | Remediation tasks implemented |
| 5.1.5 | Ensure sshd KexAlgorithms is configured | Remediation tasks implemented |
| 5.1.6 | Ensure sshd MACs are configured | Remediation tasks implemented |
| 5.1.7 | Ensure sshd access is configured | Guarded remediation; requires reviewed inputs |
| 5.1.8 | Ensure sshd Banner is configured | Remediation tasks implemented |
| 5.1.9 | Ensure sshd ClientAliveInterval and ClientAliveCountMax are configured | Remediation tasks implemented |
| 5.1.12 | Ensure sshd HostbasedAuthentication is disabled | Remediation tasks implemented |
| 5.1.13 | Ensure sshd IgnoreRhosts is enabled | Remediation tasks implemented |
| 5.1.14 | Ensure sshd LoginGraceTime is configured | Remediation tasks implemented |
| 5.1.15 | Ensure sshd LogLevel is configured | Remediation tasks implemented |
| 5.1.16 | Ensure sshd MaxAuthTries is configured | Remediation tasks implemented |
| 5.1.17 | Ensure sshd MaxStartups is configured | Remediation tasks implemented |
| 5.1.18 | Ensure sshd MaxSessions is configured | Remediation tasks implemented |
| 5.1.19 | Ensure sshd PermitEmptyPasswords is disabled | Remediation tasks implemented |
| 5.1.20 | Ensure sshd PermitRootLogin is disabled | Remediation tasks implemented |
| 5.1.21 | Ensure sshd PermitUserEnvironment is disabled | Remediation tasks implemented |
| 5.1.22 | Ensure sshd UsePAM is enabled | Remediation tasks implemented |
| 5.2.1 | Ensure sudo is installed | Remediation tasks implemented |
| 5.2.2 | Ensure sudo commands use pty | Remediation tasks implemented |
| 5.2.3 | Ensure sudo log file exists | Remediation tasks implemented |
| 5.2.5 | Ensure re-authentication for privilege escalation is not disabled globally | Remediation tasks implemented |
| 5.2.6 | Ensure sudo authentication timeout is configured correctly | Remediation tasks implemented |
| 5.3.1.1 | Ensure latest version of pam is installed | Remediation tasks implemented |
| 5.3.1.2 | Ensure latest version of authselect is installed | Remediation tasks implemented |
| 5.3.1.3 | Ensure latest version of libpwquality is installed | Remediation tasks implemented |
| 5.3.2.1 | Ensure active authselect profile includes pam modules | Remediation tasks implemented |
| 5.3.2.2 | Ensure pam_faillock module is enabled | Remediation tasks implemented |
| 5.3.2.3 | Ensure pam_pwquality module is enabled | Remediation tasks implemented |
| 5.3.2.4 | Ensure pam_pwhistory module is enabled | Remediation tasks implemented |
| 5.3.2.5 | Ensure pam_unix module is enabled | Remediation tasks implemented |
| 5.3.3.1.1 | Ensure password failed attempts lockout is configured | Remediation tasks implemented |
| 5.3.3.1.2 | Ensure password unlock time is configured | Remediation tasks implemented |
| 5.3.3.2.1 | Ensure password number of changed characters is configured | Remediation tasks implemented |
| 5.3.3.2.2 | Ensure password length is configured | Remediation tasks implemented |
| 5.3.3.2.3 | Ensure password complexity is configured | Remediation tasks implemented |
| 5.3.3.2.4 | Ensure password same consecutive characters is configured | Remediation tasks implemented |
| 5.3.3.2.5 | Ensure password maximum sequential characters is configured | Remediation tasks implemented |
| 5.3.3.2.6 | Ensure password dictionary check is enabled | Remediation tasks implemented |
| 5.3.3.2.7 | Ensure password quality is enforced for the root user | Remediation tasks implemented |
| 5.3.3.3.1 | Ensure password history remember is configured | Remediation tasks implemented |
| 5.3.3.3.2 | Ensure password history is enforced for the root user | Remediation tasks implemented |
| 5.3.3.3.3 | Ensure pam_pwhistory includes use_authtok | Remediation tasks implemented |
| 5.3.3.4.1 | Ensure pam_unix does not include nullok | Remediation tasks implemented |
| 5.3.3.4.2 | Ensure pam_unix does not include remember | Remediation tasks implemented |
| 5.3.3.4.3 | Ensure pam_unix includes a strong password hashing algorithm | Remediation tasks implemented |
| 5.3.3.4.4 | Ensure pam_unix includes use_authtok | Remediation tasks implemented |
| 5.4.1.3 | Ensure password expiration warning days is configured | Remediation tasks implemented |
| 5.4.1.4 | Ensure strong password hashing algorithm is configured | Remediation tasks implemented |
| 5.4.1.6 | Ensure all users last password change date is in the past | Remediation tasks implemented |
| 5.4.2.1 | Ensure root is the only UID 0 account | Guarded remediation; requires reviewed inputs |
| 5.4.2.3 | Ensure group root is the only GID 0 group | Guarded remediation; requires reviewed inputs |
| 5.4.2.4 | Ensure root account access is controlled | Remediation tasks implemented |
| 5.4.2.5 | Ensure root path integrity | Guarded remediation; requires reviewed inputs |
| 5.4.2.6 | Ensure root user umask is configured | Remediation tasks implemented |
| 5.4.2.8 | Ensure accounts without a valid login shell are locked | Remediation tasks implemented |
| 5.4.3.2 | Ensure default user shell timeout is configured | Remediation tasks implemented |
| 5.4.3.3 | Ensure default user umask is configured | Remediation tasks implemented |
| 6.1.1 | Ensure AIDE is installed | Remediation tasks implemented |
| 6.1.2 | Ensure filesystem integrity is regularly checked | Remediation tasks implemented |
| 6.1.3 | Ensure cryptographic mechanisms are used to protect the integrity of audit tools | Remediation tasks implemented |
| 6.2.1.1 | Ensure journald service is enabled and active | Remediation tasks implemented |
| 6.2.1.2 | Ensure journald log file access is configured | Remediation tasks implemented |
| 6.2.1.3 | Ensure journald log file rotation is configured | Remediation tasks implemented |
| 6.2.1.4 | Ensure only one logging system is in use | Remediation tasks implemented |
| 6.2.2.1.2 | Ensure systemd-journal-upload authentication is configured | Guarded remediation; requires reviewed inputs |
| 6.2.2.1.4 | Ensure systemd-journal-remote service is not in use | Remediation tasks implemented |
| 6.2.3.1 | Ensure rsyslog is installed | Remediation tasks implemented |
| 6.2.3.2 | Ensure rsyslog service is enabled and active | Remediation tasks implemented |
| 6.2.3.3 | Ensure journald is configured to send logs to rsyslog | Remediation tasks implemented |
| 6.2.3.4 | Ensure rsyslog log file creation mode is configured | Remediation tasks implemented |
| 6.2.3.5 | Ensure rsyslog logging is configured | Remediation tasks implemented |
| 6.2.3.6 | Ensure rsyslog is configured to send logs to a remote log host | Guarded remediation; requires reviewed inputs |
| 6.2.3.7 | Ensure rsyslog is not configured to receive logs from a remote client | Remediation tasks implemented |
| 6.2.3.8 | Ensure rsyslog logrotate is configured | Remediation tasks implemented |
| 6.2.4.1 | Ensure access to all logfiles has been configured | Remediation tasks implemented |
| 7.1.1 | Ensure permissions on /etc/passwd are configured | Remediation tasks implemented |
| 7.1.2 | Ensure permissions on /etc/passwd- are configured | Remediation tasks implemented |
| 7.1.3 | Ensure permissions on /etc/group are configured | Remediation tasks implemented |
| 7.1.4 | Ensure permissions on /etc/group- are configured | Remediation tasks implemented |
| 7.1.5 | Ensure permissions on /etc/shadow are configured | Remediation tasks implemented |
| 7.1.6 | Ensure permissions on /etc/shadow- are configured | Remediation tasks implemented |
| 7.1.7 | Ensure permissions on /etc/gshadow are configured | Remediation tasks implemented |
| 7.1.8 | Ensure permissions on /etc/gshadow- are configured | Remediation tasks implemented |
| 7.1.9 | Ensure permissions on /etc/shells are configured | Remediation tasks implemented |
| 7.1.10 | Ensure permissions on /etc/security/opasswd are configured | Remediation tasks implemented |
| 7.1.11 | Ensure world writable files and directories are secured | Remediation tasks implemented |
| 7.1.12 | Ensure no files or directories without an owner and a group exist | Guarded remediation; requires reviewed inputs |
| 7.1.13 | Ensure SUID and SGID files are reviewed | Guarded remediation; requires reviewed inputs |
| 7.2.1 | Ensure accounts in /etc/passwd use shadowed passwords | Remediation tasks implemented |
| 7.2.2 | Ensure /etc/shadow password fields are not empty | Remediation tasks implemented |
| 7.2.3 | Ensure all groups in /etc/passwd exist in /etc/group | Guarded remediation; requires reviewed inputs |
| 7.2.4 | Ensure no duplicate UIDs exist | Guarded remediation; requires reviewed inputs |
| 7.2.5 | Ensure no duplicate GIDs exist | Guarded remediation; requires reviewed inputs |
| 7.2.6 | Ensure no duplicate user names exist | Guarded remediation; requires reviewed inputs |
| 7.2.7 | Ensure no duplicate group names exist | Guarded remediation; requires reviewed inputs |
| 7.2.8 | Ensure local interactive user home directories are configured | Remediation tasks implemented |
| 7.2.9 | Ensure local interactive user dot files access is configured | Remediation tasks implemented |
