# Guarded remediation inputs

These controls now have actual remediation tasks; the source requires reviewed environment facts before applying them:

- 1.1.1.9: Reviewed list of filesystem modules unused by applications
- 1.2.1.4: Approved repository definitions with trusted signing keys
- 2.1.22: Reviewed units exposing unnecessary listening services
- 4.2.1: Reviewed zone/service/port removal list
- 4.3.3: Reviewed input/output/forward traffic rules before default deny
- 5.1.7: Approved SSH user allow list
- 5.4.2.1: Reviewed full account/group record corrections
- 5.4.2.3: Reviewed full account/group record corrections
- 5.4.2.5: Reviewed root PATH and directory list
- 6.2.2.1.2: Real HTTPS logging URL and existing target certificate paths
- 6.2.3.6: Real remote log collector hostname
- 7.1.12: Reviewed ownership assignments for orphaned files
- 7.1.13: Approved SUID/SGID inventory and reviewed removals
- 7.2.3: Reviewed full account/group record corrections
- 7.2.4: Reviewed full account/group record corrections
- 7.2.5: Reviewed full account/group record corrections
- 7.2.6: Reviewed full account/group record corrections
- 7.2.7: Reviewed full account/group record corrections

Other conditional blockers include a missing trusted GPG key, unmanaged authentication configuration, unsafe user home paths and trust files. A guard prevents guessing identity, repository trust, application traffic or logging credentials.
