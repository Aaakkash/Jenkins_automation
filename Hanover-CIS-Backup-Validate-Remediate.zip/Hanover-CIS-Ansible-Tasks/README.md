# Hanover CIS — Ansible task files

The 221 supplied IDs are represented directly in seven YAML task files, with the section headings and named Ansible tasks from your example. There is no custom Python runner, Python helper script or JSON command dispatcher in this ZIP. Standard Ansible modules retain their normal controller/managed-node dependencies.

Each point backs up first, validates and records evidence, skips compliant or not-applicable results, remediates confirmed noncompliance when requested, then repeats validation. The controller CSV records final_status and remediation_completed. Source-required review and failed remediation stop enforcement before the next stage. Audit mode records findings and continues. Audit mode creates backups and evidence files but does not remediate CIS settings. See CSV-REPORTING.md for the 26-column report schema.

Run `site.yml`, or include `main.yml` in an existing RHEL9 play with facts gathered, privilege escalation, and `cis_mode: audit` or `remediate`. The default is audit. The seven actual task files are `tasks/stage_1.yml` through `tasks/stage_7.yml`. They run sequentially in numerical CIS order.

Install collections: `ansible-galaxy collection install -r collections/requirements.yml`.
Audit: `ansible-playbook -i inventory.ini site.yml`.
Remediate: `ansible-playbook -i inventory.ini site.yml -e cis_mode=remediate`.

Backups are in the private directory printed at startup. Existing paths are archived with ACLs, extended attributes and SELinux labels, archive verification and SHA256 manifests. Missing paths are recorded. Package, service and mount inventories are retained. Bulk permission changes save ACL metadata. These are file/state backups, not VM snapshots or guaranteed package rollback media. Use your existing platform backup procedure before package, boot, authentication or network changes. Automatic rollback is not performed.

Some supplied solutions explicitly require a review, an ownership decision or a real remote logging endpoint. Those points contain executable evidence tasks and stop remediation when unresolved. No environment facts are fabricated. See REVIEW-REQUIRED.md. This delivery does not claim unconditional automatic fixes for all 221 findings.

The original solution text for each ID is retained under reference/. NTP uses the source policy address 10.0.0.2; example numeric defaults follow the supplied solutions. A missing boot password is generated and saved privately on the target in the backup directory before storing its hash.

Local validation checks coverage and file structure. This bundle has not been executed against a RHEL9 server. Run Ansible syntax checking and test on a nonproduction server before production use.
