# Inputs for policy-dependent remediation

Pass only the inputs needed for findings on your server, with `-e @approved-policy.yml`. An existing compliant check is skipped. These values cannot be derived from the supplied example hostnames or from duplicate records alone. The task files implement the changes; their assertions prevent applying invented facts.

- `cis_unused_filesystem_modules`: list of reviewed unused module names.
- `cis_repository_definitions`: list of dictionaries with name, description, baseurl, gpgkey. The tasks enforce gpgcheck=true.
- `cis_unapproved_services`: list of systemd units approved for removal from active service.
- `cis_firewalld_remove`: list of dictionaries with zone, kind (service or port), value.
- `cis_nft_allow_rules`: list with hook (input, forward, output) and expression (the approved nftables rule expression). The current SSH port and established traffic are protected, but application egress must also be reviewed before default deny. Treat expressions as privileged configuration.
- `cis_ssh_allow_users`: approved local/domain usernames including the current ansible_user.
- `cis_identity_record_updates`: list with path, before, after. Paths are restricted to passwd/group/shadow/gshadow. Full record replacements must be reviewed together, including UID/GID file ownership implications. Do not use ambiguous identical duplicate records as a selection mechanism.
- `cis_root_path`: list of approved absolute PATH directories. Shared directory ownership changes require review.
- `cis_journal_upload`: dictionary with URL (HTTPS), ServerKeyFile, ServerCertificateFile, TrustedCertificateFile. Files must already exist on the target.
- `cis_remote_log_host`: real TCP collector hostname. Optional cis_remote_log_port defaults to 514, matching the supplied example.
- `cis_orphan_ownership`: list with path, owner, group, identifying the correct owner for each orphaned object.
- `cis_suid_approved`: list of approved privileged file paths; `cis_suid_remove`: reviewed paths whose SUID/SGID bits should be removed.

/tmp and /dev/shm use the source's 2G tmpfs example when a separate mount is missing. This can hide existing files under the new mount; take a server backup and review application use before remediation. Existing mounts are retained. nftables persistent rules preserve the live ruleset with a flush-and-reload configuration. Logfile permission fixes save ACL metadata and follow the source's per-log ownership exceptions. Logrotate uses the supplied weekly/four-backlog/compression example for /var/log/rsyslog/*.log; custom log destinations need their own approved rotation stanzas.

This ZIP contains Ansible YAML and templates, not custom Python runtime helpers. Live RHEL9/Ansible execution remains required; local structure checks are not server validation.
