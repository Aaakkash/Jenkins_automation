# Controller CSV reporting

The updated tasks append one row for every executed CIS check to one controller CSV, across servers and stage invocations. Defaults: `<playbook directory>/reports/cis_audit_results.csv`; directory mode 0700 and newly created report mode 0600. Existing reports must have the same header. Set an absolute controller path with `-e cis_csv_file=/home/ansible/reports/cis_audit_results.csv`.

Run stage audit: `ansible-playbook -i inventory.ini test_stage.yml --limit testserver -e cis_stage=1 -e cis_mode=audit`.
Run stage 2 with the same command and `cis_stage=2`; results append to the same file. A unique host execution ID is generated for each invocation. Supply `-e cis_run_id=my-change-123` to group multiple invocations or hosts under one identifier.

Files changed: seven stage task files, main.yml, test_stage.yml. Files added: tasks/report_init.yml, tasks/report_append.yml, templates/audit_row.csv.j2. Replace these together; original uninstrumented stage tasks do not populate reporting variables.

Columns:
run_id, run_timestamp_utc, hostname, server_ip, os_version, stage_number, check_id, check_name, execution_mode, expected_state, observed_state_before, audit_status, audit_evidence, remediation_status, changes_made, backup_path, observed_state_after, post_validation_status, error_details, duration_seconds, command_to_run_on_server, command_used_in_automation, current_state_output, expected_output, final_status, remediation_completed

New detailed columns:
- command_to_run_on_server: a sudo Bash here-document reproducing the audit, followed by its return code. Run from a Bash session on the target. It validates only; it does not perform remediation.
- command_used_in_automation: the exact audit script supplied to ansible.builtin.shell with executable=/bin/bash. Remediation modules and scripts remain visible in the corresponding stage task file.
- current_state_output: pre-remediation stdout, stderr and return code, explicitly labeled. Empty stdout is not an error by itself.
- expected_output: acceptance criteria and expected return-code meaning. Exact stdout is not fabricated when the audit validates silently or requires a policy review.

The header now has 26 columns. Previous 20/24-column reports cannot accept these rows. Preserve them and use a new path, for example `-e cis_csv_file=/home/ansible/reports/cis_audit_results_flow.csv`; all later stage runs must use that same path. Old reports are not overwritten or silently migrated.

Every check follows backup -> validation -> remediation only when required -> post-validation after remediation. Backup occurs in audit mode too, and a failed backup prevents validation or remediation for that check. Its error is recorded in the CSV before stopping. Backup_path points to the per-run directory containing this check's ID-named archive/state files. Metadata for dynamically discovered paths is also saved before its related changes.

final_status gives the outcome after the check: COMPLIANT if already compliant or successfully remediated; NONCOMPLIANT for an outstanding/failed compliance result; NOT_APPLICABLE, REVIEW_REQUIRED, or ERROR when those outcomes apply. audit_status retains the initial result. remediation_completed is true only when remediation was executed and post-validation returned compliant (code 0), without a subsequent check failure. It is false for skipped, audit-only, blocked, failed or not-applicable checks. Already compliant checks have remediation_status=NOT_NEEDED, final_status=COMPLIANT, and remediation_completed=false. Non-applicable checks retain NOT_APPLICABLE.

Evidence includes stdout/stderr and return codes. Blank stdout means the check used its return code; it is not a fabricated observed setting. Expected state contains explicit settings when available, otherwise the check objective and its reference solution filename. Remediation changes list only tasks reporting changed=true; it is a task-level summary, not a byte-level configuration diff. Passwords/secrets held in registered task results are not written to the CSV. Backup path is recorded after successful backup; for an archive with no existing paths, use the corresponding absent-paths and runtime-state files in its directory.

Valid audit statuses: COMPLIANT, NONCOMPLIANT, NOT_APPLICABLE, REVIEW_REQUIRED, ERROR. Audit-only noncompliant checks have remediation_status=NOT_REQUESTED; compliant and not-applicable checks have NOT_NEEDED. Post-validation is NOT_RUN when no remediation executes. Failed checks are written from an always block before the play stops. Hard controller termination or an unreachable target may prevent reporting that interrupted check; completed rows remain in the CSV. Unexecuted checks have no rows.

All fields are quoted; embedded quotes are doubled, and multiline evidence stays within the quoted field. Use a CSV reader or Excel rather than counting physical lines. Linux controller tools `date` and `flock` are required. Controller tasks run as the user launching Ansible, with become=false. File locks protect header creation and each append even across concurrent invocations. Report-writing failures stop execution. Evidence may include sensitive system configuration; keep the report private. Spreadsheet applications may interpret formula-like evidence; import the columns as text.

Validation: local YAML/template and CSV serialization checks; not executed on an Ansible controller or RHEL9 target.
