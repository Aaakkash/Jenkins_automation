# Client project integration

Run Ansible on a Linux controller. The supplied role metadata requires ansible-core 2.19 or later; use a compatible tested controller. Install the exact collection versions in `requirements.yml`:

```bash
ansible-galaxy collection install -r requirements.yml
```

Copy `roles/rhel9_cis_standard` into the project's role path. Copy `callback_plugins/rhel9_cis_csv_v2.py` into the project's callback directory. Merge the callback path/enabling settings from `ansible.cfg.example` into the existing project configuration; do not replace the client's configuration. Callback discovery and activation are controller settings, not guaranteed by just including a role.

Copy `config/cis_unix_team_inputs.example.yml` to a local `config/cis_unix_team_inputs.yml` and review every policy input. The template has no original credentials or formal exclusions. Enter the intended exclusions, approval reference, remediation skips, repository configuration, logging, time sources, and other site values. Missing inputs can result in CONFIG_VALUE_MISSING and skipped remediation; 221 catalog definitions do not guarantee 221 validated/remediated rows.

The default policy path is `{{ playbook_dir }}/../config/cis_unix_team_inputs.yml`, matching the supplied layout. In another project, explicitly set `cis_site_policy_file` to its real controller-side path. This file is loaded using include_vars, so avoid conflicting inventory values for the same policy keys.

Use an inventory group named `rhel9_targets` with separately named hosts. Keep existing SSH/become authentication. Call the role from your existing play or use `playbooks/site.yml`.

```bash
# Audit first; use the existing inventory and approved credentials.
ansible-playbook -i inventory.ini playbooks/site.yml -e cis_operation=validate --limit TEST_HOST

# Actual changes, explicitly selected.
ansible-playbook -i inventory.ini playbooks/site.yml -e cis_operation=remediate --limit TEST_HOST
```

The example sets `serial: 1`; it deliberately has no global-fatal setting. Later hosts may continue when one fails. `cis_fail_remediation_when_unresolved: true` fails a host when its attempted post-validation controls remain unresolved. Your orchestration system must inspect per-host failures and reports.

## Optional Unix-team MSB steps

Templates disable MSB until the server scope and inputs are reviewed. To run the requested history reset, domain join, and restarts, set these in the local policy:

```yaml
cis_msb_post_remediation_enabled: true
cis_msb_reset_opasswd: true
cis_msb_ad_join_username: svcserverdeploy
cis_msb_ad_join_password: 'YOUR_ACTUAL_AD_JOIN_PASSWORD'
cis_msb_ad_computer_ou: 'OU=SERVERS,OU=CORP_RESOURCES,OU=CORP,DC=hanover,DC=com'
```

These are site values, not generic defaults. Single quotes inside a YAML single-quoted password must be doubled. Store the actual password locally, restrict file access, and exclude it from source control. No Vault setup is required by this package. Sensitive runtime tasks have no_log; that does not encrypt the local policy.

Targets need `/usr/bin/net`, installed winbind/smb services, root/become access, and pexpect installed for the exact managed Python interpreter. The usual RHEL package is python3-pexpect; validate interpreter compatibility. Dependencies are checked before opasswd reset, but not installed automatically. GRUB 1.4.1 also uses expect. GRUB tools and applicable target packages must be present as required by their controls.

MSB runs once per selected remediation host after remediation and before final validation; it is skipped for audit/check mode or no remediation selection. It resets stored local password history, joins AD using the supplied OU argument, restarts winbind then smb, and verifies domain membership/service activity. Verify the OU argument with the installed Samba version in testing. No automatic domain-trust rollback or proof of local/AD login is provided.

Changed existing opasswd is copied to `/etc/security/backup_CIS_remediation_opasswd_<unique-id>.bak` unless an original is already tracked for this playbook. The copy is root-owned 0600. A private metadata directory under `/root` is retained. Metadata and backups contain sensitive recovery data and require an approved retention policy.

## CSV output

Default: `reports/rhel9_cis_results_<hostname>_<ip>.csv`, one server per file. Host stays as the inventory alias in the rows; hostname in the filename uses the gathered OS hostname. `ip_address` uses a literal ansible_host IP, else default_ipv4.address. All numbered control rows retain their backup_details format.

MSB is a host workflow, not a numbered CIS control. Its three separate CSV columns are `msb_status`, `msb_output`, and `msb_backup_details`, repeated on the host's rows. A control may have completed while MSB failed; review both. If MSB fails before post-validation, no successful post-validation is inferred. An empty selected scope has no control rows/report.

Use a dated directory to retain run history:

```bash
export RHEL9_CIS_CSV_DIR="reports/$(date -u +%Y%m%dT%H%M%SZ)"
```

`RHEL9_CIS_CSV_OUTPUT` remains an optional explicit output override. Templates `{hostname}`, `{host}`, and `{ip}` are supported. A fixed override for a multi-host run is automatically split into host-specific files. Ensure the controller can write to the output directory.

Official references: [callback setup](https://docs.ansible.com/projects/ansible/latest/plugins/callback.html), [error handling](https://docs.ansible.com/projects/ansible/latest/playbook_guide/playbooks_error_handling.html).
