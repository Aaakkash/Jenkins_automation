# 2.3.0 — 31 October 2026

- Added host IP to all report payload paths and the CSV. Default report output is one file per host, with hostname and IP in its name. Filename components are sanitized and host collisions are handled.
- Moved Unix-team MSB recovery before post-validation. Added explicit host-level `msb_status`, `msb_output`, and `msb_backup_details` CSV fields; an MSB failure stops the affected host and emits failure data. A CIS control result and the separate MSB result must both be checked.
- Kept `serial: 1` in example plays; did not add `any_errors_fatal` as requested.
- Replaced the invalid 7.2.3 custom-module call with native `ansible.builtin.command` using the shared pre-change transaction. Added `/etc/group`, `/etc/gshadow`, `/etc/group-`, and `/etc/gshadow-` to its candidate paths. Removed the now-unused custom module from the distribution.
- Preserved the original-file ledger across repeated role invocations within a playbook process. It is an in-memory host fact and is not persisted across separate ansible-playbook executions.
- MSB backs up changed existing `/etc/security/opasswd` beside the source. It reuses an existing ledger entry and checks the reused original exists. An unchanged, root-owned 0600 file containing exactly one newline does not get another backup or reset. A new file has no original to back up. MSB metadata remains in a private `/root/cis_msb_recovery_*` directory.
- Set `cis_fail_remediation_when_unresolved: true` in role defaults and example policy. Excluded and remediation-skipped controls keep their existing selection semantics; this setting is not a claim of full benchmark compliance.
- Removed the inactive archive-backup task, its unused variables, unused policy inputs, duplicated callback skip-reason handling, duplicate custom control ID, cache files, and historical report from delivery.
- Separated reusable role code from controller project configuration. Added sanitized policy/inventory templates; original source ZIP remains unchanged. The policy template needs site review, including exclusions, repository approval, chrony, logging, and optional MSB domain inputs.
- Updated stale regression expectations and added report naming/IP, host isolation, MSB ordering/failure fields, reset decisions, backup planning, embedded Python, and Jinja parsing checks.

Local validation: 29 tests passed, 1 Bash syntax check skipped on Windows. Ansible syntax-check, Linux Bash validation, collection execution, AD join, services, real user login, and Tenable acceptance remain to be run on the Linux test setup.

Known limits retained: snapshots cover declared/discovered candidate regular files, not every package/service side effect or directory metadata. Fingerprints include mtime, mode, ownership, and xattrs as well as contents. MSB backup is an original from the current playbook if already tracked, otherwise immediately before the reset. Backup ownership/mode is restricted; no automatic full-system rollback is supplied. The IPv6 3.1.1 validator is the submitted enabled-policy implementation; alternate IPv6 policies need separate validation before use.
