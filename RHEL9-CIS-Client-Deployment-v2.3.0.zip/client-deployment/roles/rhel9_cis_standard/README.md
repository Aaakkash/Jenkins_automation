# RHEL 9 CIS role 2.3.0

Use this role through a Linux Ansible controller. Read the project INTEGRATION.md (client package) or TESTING.md (test package) for policy inputs, CSV callback activation and test acceptance.

Defaults: audit mode; all phases; MSB disabled; unresolved attempted remediation fails its host. The calling playbook controls fleet error handling. Configuration is loaded from cis_site_policy_file. Passwords may be placed in the local policy; they are not included in this distribution. GRUB 1.4.1 takes a clear password, not a precomputed hash.

This role uses trippsc2.cis 1.4.2, ansible.posix 3.0.0 and community.general 14.0.0. Install project requirements.yml. Target expect tasks require pexpect in the managed Python interpreter.

Backup scope is declared/discovered regular files. The role does not guarantee backup of every package/service side effect or directory metadata and does not automatically roll back. Use one acceptance test server and verify actual local/AD logins and Tenable results before production.
