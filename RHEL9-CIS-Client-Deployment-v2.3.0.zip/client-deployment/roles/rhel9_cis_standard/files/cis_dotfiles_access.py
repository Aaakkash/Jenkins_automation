import os
import pwd
import stat
import sys


def scan_user(user, fix):
    home = user.pw_dir
    failed = False
    checked = 0

    if (
        not os.path.isabs(home)
        or os.path.realpath(home) == "/"
        or os.path.islink(home)
        or not os.path.isdir(home)
    ):
        raise RuntimeError(
            f"Cannot safely inspect home: user={user.pw_name} home={home}"
        )

    home_device = os.stat(home).st_dev

    def walk_error(error):
        raise error

    for directory, directories, names in os.walk(
        home, followlinks=False, onerror=walk_error
    ):
        # Match find -xdev: do not descend into other filesystems.
        retained = []
        for name in directories:
            path = os.path.join(directory, name)
            info = os.lstat(path)
            if (
                stat.S_ISDIR(info.st_mode)
                and info.st_dev == home_device
            ):
                retained.append(name)
        directories[:] = retained

        for name in names:
            if not name.startswith("."):
                continue

            path = os.path.join(directory, name)
            info = os.lstat(path)

            # Match find -type f: do not follow symbolic links.
            if not stat.S_ISREG(info.st_mode):
                continue

            checked += 1

            if name in (".forward", ".rhost", ".rhosts"):
                print(f"REVIEW_REQUIRED: user={user.pw_name} file={path}")
                failed = True
                continue

            if name == ".netrc":
                print(f"WARNING: credential file exists: {path}")

            # .netrc / .bash_history: maximum ordinary permissions 0600.
            # Other dotfiles: maximum ordinary permissions 0644.
            mask = 0o177 if name in (
                ".netrc", ".bash_history"
            ) else 0o133

            mode = stat.S_IMODE(info.st_mode)
            bad = (
                bool(mode & mask)
                or info.st_uid != user.pw_uid
                or info.st_gid != user.pw_gid
            )

            if fix and bad:
                # Refuse a symlink replacement and operate on the opened file.
                fd = os.open(
                    path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK
                )
                try:
                    current = os.fstat(fd)
                    if (
                        not stat.S_ISREG(current.st_mode)
                        or current.st_dev != info.st_dev
                        or current.st_ino != info.st_ino
                    ):
                        raise RuntimeError(f"File changed during scan: {path}")

                    wanted_mode = (
                        stat.S_IMODE(current.st_mode) & ~mask
                    )
                    os.fchown(fd, user.pw_uid, user.pw_gid)
                    os.fchmod(fd, wanted_mode)
                    info = os.fstat(fd)
                finally:
                    os.close(fd)

                mode = stat.S_IMODE(info.st_mode)
                bad = (
                    bool(mode & mask)
                    or info.st_uid != user.pw_uid
                    or info.st_gid != user.pw_gid
                )
                print(f"CHANGED: {path}")

            print(
                f"{'FAIL' if bad else 'PASS'}: "
                f"user={user.pw_name} file={path} "
                f"mode={mode:04o} uid={info.st_uid} gid={info.st_gid} "
                f"expected_uid={user.pw_uid} expected_gid={user.pw_gid}"
            )
            failed |= bad

    return failed, checked


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in (
        "validate", "remediate"
    ):
        print("VALIDATION_ERROR: use validate or remediate")
        return 2

    fix = sys.argv[1] == "remediate"
    failed = False
    errors = False
    users_checked = 0
    files_checked = 0

    try:
        with open("/etc/shells") as stream:
            shells = {
                line.strip()
                for line in stream
                if line.strip().startswith("/")
                and os.path.basename(line.strip()) != "nologin"
            }

        # Local accounts only; include root and low-UID interactive users.
        with open("/etc/passwd") as stream:
            users = list(pwd.struct_passwd(
                (
                    fields[0], fields[1], int(fields[2]),
                    int(fields[3]), fields[4], fields[5], fields[6]
                )
            ) for fields in (
                line.rstrip("\n").split(":") for line in stream
            ) if len(fields) == 7 and fields[6] in shells)

        for user in users:
            users_checked += 1
            try:
                user_failed, count = scan_user(user, fix)
                failed |= user_failed
                files_checked += count
            except (OSError, RuntimeError) as error:
                print(f"VALIDATION_ERROR: user={user.pw_name}: {error}")
                errors = True

        if not users_checked:
            print("VALIDATION_ERROR: no local interactive users identified")
            errors = True

    except (OSError, ValueError) as error:
        print(f"VALIDATION_ERROR: {error}")
        return 2

    print(f"Users checked={users_checked}; dotfiles checked={files_checked}")

    if errors:
        return 2
    return 1 if failed else 0


sys.exit(main())