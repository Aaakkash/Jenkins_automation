# Windows Server 2022 In-Place Upgrade POC

This project uses Jenkins to orchestrate Ansible playbooks that assess and,
when explicitly enabled, upgrade Windows Server 2016 or 2019 to Windows Server
2022.

## Safety model

- `RUN_UPGRADE` is `false` by default.
- Assessment and Windows Setup compatibility scan run before the upgrade.
- Jenkins requires a manual approval immediately before the upgrade.
- Domain controllers, cluster nodes, evaluation editions, unsupported
  editions, pending reboots, low disk space, and mismatched installation media
  are blocked.
- The POC does not automatically revert a VM or delete a snapshot.
- Test only on a disposable non-production VM with a verified backup.

## Prerequisites

### Ansible/Jenkins controller

- Linux Jenkins agent with Python and `ansible-core`.
- Network access from the agent to the Windows host over WinRM HTTPS/5986.
- A Jenkins username/password credential with ID
  `windows-upgrade-service-account`.
- Collections installed with:

  ```bash
  ansible-galaxy collection install -r requirements.yml
  ```

### Windows test VM

- Windows Server 2016 or 2019, nonclustered and not a domain controller.
- WinRM HTTPS configured.
- Verified backup (and a temporary hypervisor snapshot if permitted).
- Windows Server 2022 ISO copied to:

  ```text
  C:\WindowsUpgrade\Windows_Server_2022.iso
  ```

- ISO language, edition, and installation type compatible with the current OS.
- At least 50 GB free on the system drive (configurable).

## Configure the test host

Edit `inventories/test/hosts.yml` and replace `win-test-01.example.com` with
the FQDN of a disposable test VM. Review variables in
`inventories/test/group_vars/windows_upgrade.yml`.

Test connectivity from the Jenkins/Ansible agent:

```bash
export WIN_USER='DOMAIN\\service-account'
export WIN_PASS='secret-from-a-secure-store'
ansible windows_upgrade -i inventories/test/hosts.yml -m ansible.windows.win_ping
```

Do not commit passwords to this repository.

## Run assessment locally

```bash
ansible-playbook -i inventories/test/hosts.yml playbooks/01_assess.yml \
  --limit win-test-01.example.com
```

## Run compatibility scan locally

The compatibility scan does not install Windows:

```bash
ansible-playbook -i inventories/test/hosts.yml \
  playbooks/02_compatibility_scan.yml \
  --limit win-test-01.example.com
```

The expected compatibility-pass code is `0xC1900210`. Any blocking code stops
the workflow and preserves Setup logs under `C:\WindowsUpgrade\Logs`.

## Jenkins test sequence

1. Create a Pipeline job using this repository's `Jenkinsfile`.
2. Add credential ID `windows-upgrade-service-account`.
3. First build with `RUN_COMPAT_SCAN=true` and `RUN_UPGRADE=false`.
4. Review the archived assessment and compatibility reports.
5. Only for an approved disposable VM, run again with `RUN_UPGRADE=true`.
6. Approve the interactive Jenkins gate after reviewing the scan.

## Upgrade behavior

The upgrade playbook creates a one-time Scheduled Task running as `SYSTEM`.
The task mounts the local ISO and launches native Windows Setup. Ansible waits
for WinRM to disconnect and then waits up to three hours for it to return.

The default setup arguments are:

```text
/auto upgrade /quiet /eula accept /dynamicupdate disable
```

Change `upgrade_dynamic_update` only after confirming proxy, internet, patching,
and change-policy requirements.

## Reports and troubleshooting

Controller reports are written below `reports/`. Windows Setup logs remain in:

```text
C:\WindowsUpgrade\Logs
C:\$WINDOWS.~BT\Sources\Panther
C:\$WINDOWS.~BT\Sources\Rollback
C:\Windows\Panther
```

Use SetupDiag and the Panther `setupact.log`/`setuperr.log` files for failures.

## Production additions still required

Before production use, integrate:

- Backup verification and application-consistent recovery testing.
- VMware snapshot creation and approved snapshot cleanup.
- Change-ticket and maintenance-window validation.
- Application-specific health checks.
- Monitoring maintenance mode.
- Central secret management and notification.
- Pilot waves and application-owner approval.

