# RHEL 9 CIS checkpoint automation

This project implements the supplied 221-checkpoint RHEL 9 scope with the
`trippsc2.cis.rhel9` role version 1.4.1. The collection source is included in
`vendor/`, so the role itself does not need to be globally installed.

## Safety model

- Ansible runs one host at a time (`serial: 1`).
- Reboot is disabled by default.
- The role is never executed by the audit playbook.
- All 296 role rule switches are disabled first; each phase enables only the
  checkpoints explicitly present in the supplied scope.
- Apply requires deliberate confirmation variables.
- Customer-specific values must be reviewed before remediation.
- Rule 5.3.1.3 is implemented by the local `rhel9_cis_custom` role because it
  is not exposed by `trippsc2.cis` 1.4.1.

## Directory layout

```text
ansible.cfg
requirements.yml
inventory/hosts.ini
group_vars/all.yml
vars/disable_all.yml
vars/customer_values.yml
vars/phases/phase01.yml ... phase07.yml
playbooks/preflight.yml
playbooks/audit.yml
playbooks/remediate.yml
playbooks/verify.yml
roles/rhel9_cis_custom/
scripts/bootstrap.sh
scripts/run_phase.sh
vendor/ansible-collection-cis/
checkpoints/checkpoints.md
checkpoints/checkpoints.csv
```

## 1. Extract and bootstrap

```bash
unzip rhel9-cis-checkpoints.zip
cd rhel9-cis-checkpoints
chmod +x scripts/*.sh
./scripts/bootstrap.sh
```

The bootstrap installs the three bundled collection archives into the local
`collections/` folder. It does not require a preinstalled collection or a
Galaxy download. The upstream `trippsc2.cis` source is also included under
`vendor/` for review.

## 2. Configure inventory

Edit `inventory/hosts.ini`. Do not use the same name for the host alias and
group. SSH-key authentication needs no `-k`. If sudo is passwordless, `-K` is
also unnecessary.

```ini
[rhel9]
rhel9_test_01 ansible_host=192.0.2.10 ansible_user=automation_user
```

## 3. Configure approved values

Review `vars/customer_values.yml`. Replace every `CHANGE_ME` value. Store the
bootloader password in Ansible Vault rather than plaintext:

```bash
ansible-vault create vars/vault.yml
```

Example Vault content:

```yaml
vault_rhel9cis_bootloader_password: "approved-secret"
```

## 4. Run preflight and audit

```bash
ansible-playbook playbooks/preflight.yml
ansible-playbook playbooks/audit.yml
```

Audit results are fetched into `reports/<host>/` on the controller. The audit
playbook is read-only and does not invoke the remediation role.

## 5. Preview one phase

```bash
./scripts/run_phase.sh 01 check
```

Phases correspond to CIS sections 1 through 7. Always inspect the diff and
warning list. Separate-partition, approved-service, account-integrity and
review-type controls can require manual action even when their rule is enabled.

## 6. Apply one phase

After snapshot/change approval and customer-value review:

```bash
./scripts/run_phase.sh 01 apply
```

If Vault is used, append `--ask-vault-pass` to the command in the script or run
the equivalent `ansible-playbook` command directly.

## 7. Verify and prove idempotency

```bash
ansible-playbook playbooks/verify.yml -e cis_phase=01
./scripts/run_phase.sh 01 check
```

The second preview should show no unexpected changes. Compliance must also be
confirmed by the approved Tenable/SCAP scanner because Ansible task success is
not, by itself, proof that every scanner plugin passes.

## Important approvals

Do not apply until the customer has approved firewall choice, SSH access
rules, required services, NTP servers, password and lockout settings, banner
text, logging destination, SELinux mode, crypto policy, mount/reboot windows
and exceptions for application requirements.
