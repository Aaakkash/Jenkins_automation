# Tested versions and scope

- Ansible core: 2.19.13
- `trippsc2.cis`: 1.4.1
- `ansible.posix`: 3.0.0
- `community.general`: 14.0.0
- Target platform enforced by preflight: Red Hat Enterprise Linux 9
- Supplied checkpoints: 221
- Upstream role mappings: 220
- Local custom mappings: 1 (`5.3.1.3`)
- Upstream rule switches explicitly disabled before each phase: 296

Validation completed before packaging:

- Parsed every project and vendored YAML file.
- Validated both shell scripts with `bash -n`.
- Installed all bundled collection archives locally.
- Ran `ansible-playbook --syntax-check` successfully against all four
  playbooks using Ansible core 2.19.13.
- Reconciled the checkpoint list against the upstream role switches.

Runtime remediation still requires testing against the customer's RHEL 9 test
server because service, firewall, PAM, storage, logging and application state
cannot be reproduced by controller-side syntax validation.

