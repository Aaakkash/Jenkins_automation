#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 2 ]]; then
  echo "Usage: $0 <01-07> <check|apply>" >&2
  exit 2
fi

phase="$1"
mode="$2"
[[ "$phase" =~ ^0[1-7]$ ]] || { echo "Phase must be 01 through 07." >&2; exit 2; }
[[ "$mode" == "check" || "$mode" == "apply" ]] || { echo "Mode must be check or apply." >&2; exit 2; }

project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$project_dir"

args=(
  playbooks/remediate.yml
  -e "cis_phase=$phase"
  -e cis_apply_confirm=true
  -e cis_customer_values_confirm=true
  -e cis_high_risk_confirm=true
  -e cis_maintenance_window_confirm=true
  --diff
)

if [[ "$mode" == "check" ]]; then
  args+=(--check)
fi

ansible-playbook "${args[@]}"

