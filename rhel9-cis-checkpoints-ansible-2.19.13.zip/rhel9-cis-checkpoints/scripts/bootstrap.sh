#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$project_dir"

command -v ansible-playbook >/dev/null
command -v ansible-galaxy >/dev/null

mkdir -p collections reports
ansible-galaxy collection install vendor/packages/ansible-posix-3.0.0.tar.gz -p collections --no-deps --force
ansible-galaxy collection install vendor/packages/community-general-14.0.0.tar.gz -p collections --no-deps --force
ansible-galaxy collection install vendor/packages/trippsc2-cis-1.4.1.tar.gz -p collections --no-deps --force
ansible-galaxy collection list trippsc2.cis -p collections
ansible-playbook playbooks/preflight.yml --syntax-check
ansible-playbook playbooks/audit.yml --syntax-check
ansible-playbook playbooks/remediate.yml --syntax-check -e cis_phase=01
ansible-playbook playbooks/verify.yml --syntax-check
