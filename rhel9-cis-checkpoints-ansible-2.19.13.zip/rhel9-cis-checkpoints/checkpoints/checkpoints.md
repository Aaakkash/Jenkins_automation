| **Plugin** | **Plugin Name**                                                                        |
| ---------- | -------------------------------------------------------------------------------------- |
| 1000957    | 1.2.2.1 Ensure updates, patches, and additional security software are installed        |
| 1000360    | 1.1.1.1 Ensure cramfs kernel module is not available                                   |
| 1000361    | 1.1.1.2 Ensure freevxfs kernel module is not available                                 |
| 1000362    | 1.1.1.3 Ensure hfs kernel module is not available                                      |
| 1000363    | 1.1.1.4 Ensure hfsplus kernel module is not available                                  |
| 1000364    | 1.1.1.5 Ensure jffs2 kernel module is not available                                    |
| 1000365    | 1.1.1.8 Ensure usb-storage kernel module is not available                              |
| 1000366    | 1.1.2.1.1 Ensure /tmp is a separate partition                                          |
| 1000367    | 1.1.2.1.2 Ensure nodev option set on /tmp partition                                    |
| 1000368    | 1.1.2.1.3 Ensure nosuid option set on /tmp partition                                   |
| 1000369    | 1.1.2.1.4 Ensure noexec option set on /tmp partition                                   |
| 1000370    | 1.1.2.2.1 Ensure /dev/shm is a separate partition                                      |
| 1000371    | 1.1.2.2.2 Ensure nodev option set on /dev/shm partition                                |
| 1000372    | 1.1.2.2.3 Ensure nosuid option set on /dev/shm partition                               |
| 1000373    | 1.1.2.2.4 Ensure noexec option set on /dev/shm partition                               |
| 1000374    | 1.1.2.3.2 Ensure nodev option set on /home partition                                   |
| 1000375    | 1.1.2.3.3 Ensure nosuid option set on /home partition                                  |
| 1000376    | 1.1.2.4.2 Ensure nodev option set on /var partition                                    |
| 1000377    | 1.1.2.4.3 Ensure nosuid option set on /var partition                                   |
| 1000378    | 1.1.2.5.2 Ensure nodev option set on /var/tmp partition                                |
| 1000379    | 1.1.2.5.3 Ensure nosuid option set on /var/tmp partition                               |
| 1000380    | 1.1.2.5.4 Ensure noexec option set on /var/tmp partition                               |
| 1000381    | 1.1.2.6.2 Ensure nodev option set on /var/log partition                                |
| 1000382    | 1.1.2.6.3 Ensure nosuid option set on /var/log partition                               |
| 1000383    | 1.1.2.6.4 Ensure noexec option set on /var/log partition                               |
| 1000384    | 1.1.2.7.2 Ensure nodev option set on /var/log/audit partition                          |
| 1000385    | 1.1.2.7.3 Ensure nosuid option set on /var/log/audit partition                         |
| 1000386    | 1.1.2.7.4 Ensure noexec option set on /var/log/audit partition                         |
| 1000407    | 1.6.1 Ensure system wide crypto policy is not set to legacy                            |
| 1000411    | 1.6.4 Ensure system wide crypto policy disables macs less than 128 bits                |
| 1000419    | 1.7.4 Ensure access to /etc/motd is configured                                         |
| 1000420    | 1.7.5 Ensure access to /etc/issue is configured                                        |
| 1000421    | 1.7.6 Ensure access to /etc/issue.net is configured                                    |
| 1000423    | 1.8.10 Ensure XDMCP is not enabled                                                     |
| 1000424    | 1.8.2 Ensure GDM login banner is configured                                            |
| 1000425    | 1.8.3 Ensure GDM disable-user-list option is enabled                                   |
| 1000426    | 1.8.4 Ensure GDM screen locks when the user is idle                                    |
| 1000427    | 1.8.5 Ensure GDM screen locks cannot be overridden                                     |
| 1000428    | 1.8.6 Ensure GDM automatic mounting of removable media is disabled                     |
| 1000429    | 1.8.7 Ensure GDM disabling automatic mounting of removable media is not overridden     |
| 1000430    | 1.8.8 Ensure GDM autorun-never is enabled                                              |
| 1000431    | 1.8.9 Ensure GDM autorun-never is not overridden                                       |
| 1000518    | 3.1.1 Ensure IPv6 status is identified                                                 |
| 1000519    | 3.1.2 Ensure wireless interfaces are disabled                                          |
| 1000521    | 3.1.3 Ensure bluetooth services are not in use                                         |
| 1000524    | 3.3.1 Ensure ip forwarding is disabled                                                 |
| 1000525    | 3.3.10 Ensure tcp syn cookies is enabled                                               |
| 1000526    | 3.3.11 Ensure ipv6 router advertisements are not accepted                              |
| 1000527    | 3.3.2 Ensure packet redirect sending is disabled                                       |
| 1000528    | 3.3.3 Ensure bogus icmp responses are ignored                                          |
| 1000529    | 3.3.4 Ensure broadcast icmp requests are ignored                                       |
| 1000530    | 3.3.5 Ensure icmp redirects are not accepted                                           |
| 1000531    | 3.3.6 Ensure secure icmp redirects are not accepted                                    |
| 1000532    | 3.3.7 Ensure reverse path filtering is enabled                                         |
| 1000533    | 3.3.8 Ensure source routed packets are not accepted                                    |
| 1000534    | 3.3.9 Ensure suspicious packets are logged                                             |
| 1000678    | 1.1.1.9 Ensure unused filesystems kernel modules are not available                     |
| 1000680    | 1.2.1.1 Ensure GPG keys are configured                                                 |
| 1000683    | 1.2.1.4 Ensure package manager repositories are configured                             |
| 1000684    | 1.3.1.1 Ensure SELinux is installed                                                    |
| 1000685    | 1.3.1.2 Ensure SELinux is not disabled in bootloader configuration                     |
| 1000686    | 1.3.1.7 Ensure the MCS Translation Service (mcstrans) is not installed                 |
| 1000687    | 1.3.1.8 Ensure SETroubleshoot is not installed                                         |
| 1000688    | 1.4.1 Ensure bootloader password is set                                                |
| 1000689    | 1.4.2 Ensure access to bootloader config is configured                                 |
| 1000690    | 1.5.1 Ensure address space layout randomization is enabled                             |
| 1000691    | 1.5.2 Ensure ptrace_scope is restricted                                                |
| 1000692    | 1.5.3 Ensure core dump backtraces are disabled                                         |
| 1000693    | 1.5.4 Ensure core dump storage is disabled                                             |
| 1000694    | 1.6.2 Ensure system wide crypto policy is not set in sshd configuration                |
| 1000696    | 1.6.5 Ensure system wide crypto policy disables cbc for ssh                            |
| 1000704    | 1.7.1 Ensure message of the day is configured properly                                 |
| 1000705    | 2.1.1 Ensure autofs services are not in use                                            |
| 1000706    | 2.1.10 Ensure nis server services are not in use                                       |
| 1000707    | 2.1.11 Ensure print server services are not in use                                     |
| 1000709    | 2.1.13 Ensure rsync services are not in use                                            |
| 1000710    | 2.1.14 Ensure snmp services are not in use                                             |
| 1000711    | 2.1.15 Ensure telnet server services are not in use                                    |
| 1000712    | 2.1.16 Ensure tftp server services are not in use                                      |
| 1000713    | 2.1.17 Ensure web proxy server services are not in use                                 |
| 1000714    | 2.1.19 Ensure xinetd services are not in use                                           |
| 1000715    | 2.1.2 Ensure avahi daemon services are not in use                                      |
| 1000726    | 2.1.22 Ensure only approved services are listening on a network interface              |
| 1000727    | 2.1.3 Ensure dhcp server services are not in use                                       |
| 1000728    | 2.1.4 Ensure dns server services are not in use                                        |
| 1000729    | 2.1.5 Ensure dnsmasq services are not in use                                           |
| 1000731    | 2.1.7 Ensure ftp server services are not in use                                        |
| 1000734    | 2.1.9 Ensure network file system services are not in use                               |
| 1000735    | 2.2.1 Ensure ftp client is not installed                                               |
| 1000736    | 2.2.3 Ensure nis client is not installed                                               |
| 1000737    | 2.2.4 Ensure telnet client is not installed                                            |
| 1000738    | 2.2.5 Ensure tftp client is not installed                                              |
| 1000739    | 2.3.1 Ensure time synchronization is in use                                            |
| 1000741    | 2.3.3 Ensure chrony is not run as the root user                                        |
| 1000744    | 2.4.1.2 Ensure permissions on /etc/crontab are configured                              |
| 1000745    | 2.4.1.3 Ensure permissions on /etc/cron.hourly are configured                          |
| 1000746    | 2.4.1.4 Ensure permissions on /etc/cron.daily are configured                           |
| 1000747    | 2.4.1.5 Ensure permissions on /etc/cron.weekly are configured                          |
| 1000748    | 2.4.1.6 Ensure permissions on /etc/cron.monthly are configured                         |
| 1000749    | 2.4.1.7 Ensure permissions on /etc/cron.d are configured                               |
| 1000753    | 4.1.1 Ensure nftables is installed                                                     |
| 1000756    | 4.2.1 Ensure firewalld drops unnecessary services and ports                            |
| 1000757    | 4.2.2 Ensure firewalld loopback traffic is configured                                  |
| 1000759    | 5.1.1 Ensure permissions on /etc/ssh/sshd_config are configured                        |
| 1000760    | 5.1.14 Ensure sshd LoginGraceTime is configured                                        |
| 1000761    | 5.1.17 Ensure sshd MaxStartups is configured                                           |
| 1000775    | 5.1.2 Ensure permissions on SSH private host key files are configured                  |
| 1000776    | 5.1.21 Ensure sshd PermitUserEnvironment is disabled                                   |
| 1000777    | 5.1.22 Ensure sshd UsePAM is enabled                                                   |
| 1000778    | 5.1.3 Ensure permissions on SSH public host key files are configured                   |
| 1000779    | 5.1.4 Ensure sshd Ciphers are configured                                               |
| 1000789    | 5.1.5 Ensure sshd KexAlgorithms is configured                                          |
| 1000791    | 5.1.7 Ensure sshd access is configured                                                 |
| 1000796    | 5.2.1 Ensure sudo is installed                                                         |
| 1000800    | 5.2.5 Ensure re-authentication for privilege escalation is not disabled globally       |
| 1000802    | 5.3.1.1 Ensure latest version of pam is installed                                      |
| 1000803    | 5.3.1.2 Ensure latest version of authselect is installed                               |
| 1000804    | 5.3.1.3 Ensure latest version of libpwquality is installed                             |
| 1000805    | 5.3.2.1 Ensure active authselect profile includes pam modules                          |
| 1000806    | 5.3.3.2.3 Ensure password complexity is configured                                     |
| 1000807    | 5.3.3.2.7 Ensure password quality is enforced for the root user                        |
| 1000808    | 5.3.3.3.2 Ensure password history is enforced for the root user                        |
| 1000814    | 5.4.1.4 Ensure strong password hashing algorithm is configured                         |
| 1000818    | 5.4.1.6 Ensure all users last password change date is in the past                      |
| 1000820    | 5.4.2.4 Ensure root account access is controlled                                       |
| 1000821    | 5.4.2.5 Ensure root path integrity                                                     |
| 1000822    | 5.4.2.6 Ensure root user umask is configured                                           |
| 1000857    | 5.4.2.8 Ensure accounts without a valid login shell are locked                         |
| 1000859    | 5.4.3.3 Ensure default user umask is configured                                        |
| 1000860    | 6.1.1 Ensure AIDE is installed                                                         |
| 1000861    | 6.1.2 Ensure filesystem integrity is regularly checked                                 |
| 1000872    | 6.1.3 Ensure cryptographic mechanisms are used to protect the integrity of audit tools |
| 1000873    | 6.2.1.3 Ensure journald log file rotation is configured                                |
| 1000874    | 6.2.1.4 Ensure only one logging system is in use                                       |
| 1000877    | 6.2.2.1.2 Ensure systemd-journal-upload authentication is configured                   |
| 1000894    | 6.2.3.1 Ensure rsyslog is installed                                                    |
| 1000895    | 6.2.3.3 Ensure journald is configured to send logs to rsyslog                          |
| 1000896    | 6.2.3.4 Ensure rsyslog log file creation mode is configured                            |
| 1000901    | 6.2.3.8 Ensure rsyslog logrotate is configured                                         |
| 1000903    | 7.1.1 Ensure permissions on /etc/passwd are configured                                 |
| 1000904    | 7.1.2 Ensure permissions on /etc/passwd- are configured                                |
| 1000905    | 7.1.3 Ensure permissions on /etc/group are configured                                  |
| 1000906    | 7.1.4 Ensure permissions on /etc/group- are configured                                 |
| 1000907    | 7.1.5 Ensure permissions on /etc/shadow are configured                                 |
| 1000908    | 7.1.6 Ensure permissions on /etc/shadow- are configured                                |
| 1000909    | 7.1.7 Ensure permissions on /etc/gshadow are configured                                |
| 1000910    | 7.1.8 Ensure permissions on /etc/gshadow- are configured                               |
| 1000912    | 7.1.9 Ensure permissions on /etc/shells are configured                                 |
| 1000913    | 7.2.1 Ensure accounts in /etc/passwd use shadowed passwords                            |
| 1000914    | 7.2.2 Ensure /etc/shadow password fields are not empty                                 |
| 1000915    | 7.2.8 Ensure local interactive user home directories are configured                    |
| 1000916    | 7.2.9 Ensure local interactive user dot files access is configured                     |
| 1000923    | 5.4.2.1 Ensure root is the only UID 0 account                                          |
| 1000924    | 5.4.2.3 Ensure group root is the only GID 0 group                                      |
| 1000926    | 7.1.12 Ensure no files or directories without an owner and a group exist               |
| 1000948    | 7.1.13 Ensure SUID and SGID files are reviewed                                         |
| 1000950    | 7.2.3 Ensure all groups in /etc/passwd exist in /etc/group                             |
| 1000951    | 7.2.4 Ensure no duplicate UIDs exist                                                   |
| 1000952    | 7.2.5 Ensure no duplicate GIDs exist                                                   |
| 1000953    | 7.2.6 Ensure no duplicate user names exist                                             |
| 1000954    | 7.2.7 Ensure no duplicate group names exist                                            |
| 1000956    | 1.2.1.2 Ensure gpgcheck is globally activated                                          |
| 1000958    | 1.3.1.3 Ensure SELinux policy is configured                                            |
| 1000960    | 1.3.1.4 Ensure the SELinux mode is not disabled                                        |
| 1000962    | 1.6.7 Ensure system wide crypto policy disables EtM for ssh                            |
| 1000963    | 2.1.18 Ensure web server services are not in use                                       |
| 1000964    | 2.1.21 Ensure mail transfer agents are configured for local-only mode                  |
| 1000965    | 2.1.8 Ensure message access server services are not in use                             |
| 1000966    | 2.4.1.1 Ensure cron daemon is enabled and active                                       |
| 1000967    | 2.4.1.8 Ensure crontab is restricted to authorized users                               |
| 1000969    | 2.4.2.1 Ensure at is restricted to authorized users                                    |
| 1000970    | 4.3.1 Ensure nftables base chains exist                                                |
| 1000971    | 4.3.2 Ensure nftables established connections are configured                           |
| 1000972    | 4.3.3 Ensure nftables default deny firewall policy                                     |
| 1000973    | 5.1.12 Ensure sshd HostbasedAuthentication is disabled                                 |
| 1000974    | 5.1.13 Ensure sshd IgnoreRhosts is enabled                                             |
| 1000975    | 5.1.15 Ensure sshd LogLevel is configured                                              |
| 1000976    | 5.1.16 Ensure sshd MaxAuthTries is configured                                          |
| 1000981    | 5.1.18 Ensure sshd MaxSessions is configured                                           |
| 1000982    | 5.1.19 Ensure sshd PermitEmptyPasswords is disabled                                    |
| 1000983    | 5.1.20 Ensure sshd PermitRootLogin is disabled                                         |
| 1000985    | 5.1.9 Ensure sshd ClientAliveInterval and ClientAliveCountMax are configured           |
| 1000986    | 5.2.2 Ensure sudo commands use pty                                                     |
| 1000987    | 5.2.6 Ensure sudo authentication timeout is configured correctly                       |
| 1000988    | 5.3.2.2 Ensure pam_faillock module is enabled                                          |
| 1000989    | 5.3.2.3 Ensure pam_pwquality module is enabled                                         |
| 1000990    | 5.3.2.4 Ensure pam_pwhistory module is enabled                                         |
| 1000991    | 5.3.2.5 Ensure pam_unix module is enabled                                              |
| 1000992    | 5.3.3.1.1 Ensure password failed attempts lockout is configured                        |
| 1000993    | 5.3.3.1.2 Ensure password unlock time is configured                                    |
| 1000994    | 5.3.3.2.1 Ensure password number of changed characters is configured                   |
| 1000995    | 5.3.3.2.2 Ensure password length is configured                                         |
| 1000996    | 5.3.3.2.4 Ensure password same consecutive characters is configured                    |
| 1000997    | 5.3.3.2.5 Ensure password maximum sequential characters is configured                  |
| 1000998    | 5.3.3.2.6 Ensure password dictionary check is enabled                                  |
| 1000999    | 5.3.3.3.1 Ensure password history remember is configured                               |
| 1001000    | 5.3.3.3.3 Ensure pam_pwhistory includes use_authtok                                    |
| 1001001    | 5.3.3.4.1 Ensure pam_unix does not include nullok                                      |
| 1001002    | 5.3.3.4.2 Ensure pam_unix does not include remember                                    |
| 1001003    | 5.3.3.4.3 Ensure pam_unix includes a strong password hashing algorithm                 |
| 1001004    | 5.3.3.4.4 Ensure pam_unix includes use_authtok                                         |
| 1001006    | 5.4.1.3 Ensure password expiration warning days is configured                          |
| 1001008    | 6.2.1.1 Ensure journald service is enabled and active                                  |
| 1001009    | 6.2.1.2 Ensure journald log file access is configured                                  |
| 1001011    | 6.2.2.1.4 Ensure systemd-journal-remote service is not in use                          |
| 1001012    | 6.2.3.2 Ensure rsyslog service is enabled and active                                   |
| 1001015    | 6.2.3.7 Ensure rsyslog is not configured to receive logs from a remote client          |
| 1001016    | 7.1.10 Ensure permissions on /etc/security/opasswd are configured                      |
| 1000697    | 1.6.6 Ensure system wide crypto policy disables chacha20-poly1305 for ssh              |
| 1000740    | 2.3.2 Ensure chrony is configured                                                      |
| 1000790    | 5.1.6 Ensure sshd MACs are configured                                                  |
| 1000799    | 5.2.3 Ensure sudo log file exists                                                      |
| 1000858    | 5.4.3.2 Ensure default user shell timeout is configured                                |
| 1000862    | 1.7.2 Ensure local login warning banner is configured properly                         |
| 1000863    | 1.7.3 Ensure remote login warning banner is configured properly                        |
| 1000902    | 6.2.4.1 Ensure access to all logfiles has been configured                              |
| 1000925    | 7.1.11 Ensure world writable files and directories are secured                         |
| 1000961    | 1.6.3 Ensure system wide crypto policy disables sha1 hash and signature support        |
| 1000984    | 5.1.8 Ensure sshd Banner is configured                                                 |
| 1001013    | 6.2.3.5 Ensure rsyslog logging is configured                                           |
| 1001014    | 6.2.3.6 Ensure rsyslog is configured to send logs to a remote log host                 |