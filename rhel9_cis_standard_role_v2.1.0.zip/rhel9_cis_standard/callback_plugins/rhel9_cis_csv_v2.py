"""Write one CSV from structured, read-only RHEL 9 CIS validation results."""

from __future__ import annotations

import csv
import os
from datetime import datetime, timezone
from pathlib import Path

from ansible.plugins.callback import CallbackBase


DOCUMENTATION = r"""
callback: rhel9_cis_csv_v2
type: aggregate
short_description: Write structured RHEL 9 CIS validation results to CSV
version_added: "2.0"
requirements:
  - Enable with callbacks_enabled=rhel9_cis_csv_v2
"""


class CallbackModule(CallbackBase):
    CALLBACK_VERSION = 2.0
    CALLBACK_TYPE = "aggregate"
    CALLBACK_NAME = "rhel9_cis_csv_v2"
    CALLBACK_NEEDS_ENABLED = True

    def __init__(self):
        super().__init__()
        self.payloads: list[dict] = []

    def v2_runner_on_ok(self, result, **kwargs):
        data = result._result or {}
        message = data.get("msg")
        if not isinstance(message, dict):
            return
        payload = message.get("cis_report_payload")
        if not isinstance(payload, dict):
            return
        payload = dict(payload)
        payload["host"] = str(payload.get("host") or result._host.get_name())
        self.payloads.append(payload)

    def v2_playbook_on_stats(self, stats):
        if not self.payloads:
            return

        output = Path(
            os.environ.get("RHEL9_CIS_CSV_OUTPUT", "reports/rhel9_cis_results.csv")
        )
        output.parent.mkdir(parents=True, exist_ok=True)
        generated = datetime.now(timezone.utc).isoformat()
        rows = []
        controls: dict[tuple[str, str], dict] = {}

        for payload in self.payloads:
            host = str(payload.get("host", "unknown"))
            pre_results = payload.get("results") or []
            post_by_id = {
                item.get("control_id"): item
                for item in (payload.get("post_results") or [])
            }
            attempted = set(payload.get("remediation_attempted") or [])
            stage_priority = {
                "pre": 1,
                "remediation": 2,
                "final": 3,
            }.get(payload.get("stage"), 0)

            for pre in pre_results:
                key = (host, str(pre.get("control_id", "")))
                if key not in controls or stage_priority >= controls[key]["priority"]:
                    controls[key] = {
                        "host": host,
                        "operation": payload.get("operation", "validate"),
                        "pre": pre,
                        "post": post_by_id.get(pre.get("control_id")),
                        "attempted": attempted,
                        "priority": stage_priority,
                    }

        for state in controls.values():
            host = state["host"]
            operation = state["operation"]
            pre = state["pre"]
            post = state["post"]
            attempted = state["attempted"]
            control_id = str(pre.get("control_id", ""))
            pre_status = str(pre.get("status", "VALIDATION_ERROR"))
            post_status = str(post.get("status")) if post else "NOT_RUN"

            if operation == "validate":
                final_status = pre_status
            elif pre_status != "NON_COMPLIANT":
                final_status = pre_status
            elif control_id not in attempted:
                final_status = "REMEDIATION_NOT_ATTEMPTED"
            elif post_status == "COMPLIANT":
                final_status = "REMEDIATION_COMPLETED"
            elif post_status == "NON_COMPLIANT":
                final_status = "NON_COMPLIANT_AFTER_REMEDIATION"
            elif post_status == "VALIDATION_ERROR":
                final_status = "POST_VALIDATION_ERROR"
            elif post_status == "NOT_RUN":
                final_status = "REMEDIATION_INCOMPLETE"
            else:
                final_status = post_status

            rows.append(
                {
                    "generated_utc": generated,
                    "host": host,
                    "plugin_id": pre.get("plugin_id", ""),
                    "phase": str(pre.get("phase", "")).zfill(2),
                    "control_id": control_id,
                    "checkpoint": pre.get("checkpoint", ""),
                    "validation_type": pre.get("validation_type", ""),
                    "validation_source": pre.get("validation_source", ""),
                    "remediation_safe": (
                        "YES" if pre.get("remediation_safe") else "NO"
                    ),
                    "pre_validation": pre_status,
                    "remediation_required": (
                        "YES" if pre_status == "NON_COMPLIANT" else "NO"
                    ),
                    "remediation_attempted": (
                        "YES" if control_id in attempted else "NO"
                    ),
                    "remediation_completed": (
                        "YES" if final_status == "REMEDIATION_COMPLETED" else "NO"
                    ),
                    "post_validation": post_status,
                    "final_status": final_status,
                    "evidence": (
                        post.get("evidence", "") if post else pre.get("evidence", "")
                    ),
                }
            )

        fields = [
            "generated_utc",
            "host",
            "plugin_id",
            "phase",
            "control_id",
            "checkpoint",
            "validation_type",
            "validation_source",
            "remediation_safe",
            "pre_validation",
            "remediation_required",
            "remediation_attempted",
            "remediation_completed",
            "post_validation",
            "final_status",
            "evidence",
        ]

        def control_key(row):
            return (
                row["host"],
                [int(part) for part in row["control_id"].split(".")],
            )

        with output.open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=fields)
            writer.writeheader()
            writer.writerows(sorted(rows, key=control_key))

        self._display.display(f"RHEL 9 CIS CSV report: {output}", color="green")
