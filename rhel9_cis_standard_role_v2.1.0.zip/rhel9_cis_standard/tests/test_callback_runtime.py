from __future__ import annotations

import csv
import importlib.util
import os
import sys
import tempfile
import types
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class Display:
    def display(self, message, color=None):
        self.last = message


class CallbackBase:
    def __init__(self):
        self._display = Display()


ansible = types.ModuleType("ansible")
plugins = types.ModuleType("ansible.plugins")
callback = types.ModuleType("ansible.plugins.callback")
callback.CallbackBase = CallbackBase
sys.modules.setdefault("ansible", ansible)
sys.modules.setdefault("ansible.plugins", plugins)
sys.modules.setdefault("ansible.plugins.callback", callback)

spec = importlib.util.spec_from_file_location(
    "rhel9_cis_csv_v2",
    ROOT / "callback_plugins/rhel9_cis_csv_v2.py",
)
module = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(module)


class Host:
    def get_name(self):
        return "rhel9-test"


class Result:
    def __init__(self, payload):
        self._host = Host()
        self._result = {"msg": {"cis_report_payload": payload}}


def main():
    pre = [
        {
            "plugin_id": "1000525",
            "phase": 3,
            "control_id": "3.3.10",
            "checkpoint": "Ensure tcp syn cookies is enabled",
            "validation_type": "automatic",
            "status": "NON_COMPLIANT",
            "evidence": "net.ipv4.tcp_syncookies=0",
        },
        {
            "plugin_id": "1000518",
            "phase": 3,
            "control_id": "3.1.1",
            "checkpoint": "Ensure IPv6 status is identified",
            "validation_type": "automatic",
            "status": "MANUAL_REVIEW_REQUIRED",
            "evidence": "policy=review",
        },
    ]
    post = [dict(pre[0], status="COMPLIANT", evidence="net.ipv4.tcp_syncookies=1")]
    payload = {
        "stage": "final",
        "operation": "remediate",
        "host": "rhel9-test",
        "results": pre,
        "post_results": post,
        "remediation_attempted": ["3.3.10"],
    }

    with tempfile.TemporaryDirectory() as directory:
        report = Path(directory) / "report.csv"
        os.environ["RHEL9_CIS_CSV_OUTPUT"] = str(report)
        instance = module.CallbackModule()
        instance.v2_runner_on_ok(
            Result(
                {
                    "stage": "pre",
                    "operation": "remediate",
                    "host": "rhel9-test",
                    "results": pre,
                    "post_results": [],
                    "remediation_attempted": [],
                }
            )
        )
        instance.v2_runner_on_ok(Result(payload))
        instance.v2_playbook_on_stats(None)
        rows = list(csv.DictReader(report.open(encoding="utf-8")))
        assert len(rows) == 2
        by_id = {row["control_id"]: row for row in rows}
        assert by_id["3.3.10"]["final_status"] == "REMEDIATION_COMPLETED"
        assert by_id["3.3.10"]["remediation_completed"] == "YES"
        assert by_id["3.1.1"]["final_status"] == "MANUAL_REVIEW_REQUIRED"
    print("PASS callback runtime and CSV state mapping")


if __name__ == "__main__":
    main()
