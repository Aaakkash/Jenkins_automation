# Validation coverage

The supplied inventory contains 221 unique checkpoints. Version 2.1 provides
191 automatic read-only validators. The remaining 30 checkpoints are included
and report `MANUAL_REVIEW_REQUIRED` because they require a site-approved value,
an application inventory, or human review.

| Phase | Total | Automatic | Manual/policy |
|---:|---:|---:|---:|
| 01 | 66 | 52 | 14 |
| 02 | 35 | 33 | 2 |
| 03 | 14 | 14 | 0 |
| 04 | 6 | 5 | 1 |
| 05 | 60 | 58 | 2 |
| 06 | 18 | 12 | 6 |
| 07 | 22 | 17 | 5 |
| **Total** | **221** | **191** | **30** |

Checkpoint 3.1.1 has an automatic detector but returns
`MANUAL_REVIEW_REQUIRED` while `cis_ipv6_policy=review`.

## Manual or organization-policy checkpoints

- `1.1.1.9` Site policy must define unused filesystem types.
- `1.2.1.2` Repository-specific gpgcheck settings require repository review.
- `1.7.1`, `1.7.2`, `1.7.3` Banner text must match the approved legal text.
- `1.8.2` through `1.8.10` GDM controls require the approved workstation scope and dconf policy.
- `2.1.22` Listening ports must match the approved application inventory.
- `2.3.2` Chrony sources must match approved time servers.
- `4.2.1` Firewalld services and ports require the approved network inventory.
- `5.1.7` SSH allow/deny entries require the approved access list.
- `5.1.9` SSH inactivity values require the approved timeout.
- `6.2.1.3` Journald rotation requires capacity/retention policy.
- `6.2.2.1.2` Journal upload requires approved URL and certificate paths.
- `6.2.3.5` Rsyslog facilities and severities require logging policy.
- `6.2.3.6` Remote logging requires the approved destination and transport.
- `6.2.3.8` The supplied audit explicitly requires human review of logrotate policy.
- `6.2.4.1` Application log ownership requires service-owner review.
- `7.1.11` World-writable findings require filesystem-by-filesystem review.
- `7.1.12` Unowned files require application-owner review.
- `7.1.13` SUID/SGID files require an approved executable inventory.
- `7.2.8`, `7.2.9` Interactive home and dot-file findings require account-owner review.

These controls are not skipped. Each receives its own CSV row with the reason
manual review is required.

