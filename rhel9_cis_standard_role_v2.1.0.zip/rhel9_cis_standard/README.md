# RHEL 9 CIS Standard Role v2.1.0

This role contains all 221 supplied RHEL 9 CIS checkpoints. Validation uses
read-only commands and never calls the remediation collection. The
`trippsc2.cis.rhel9` collection role is called only when
`cis_operation=remediate`, and only for controls that were proven
`NON_COMPLIANT` and are present in the remediation allowlist.

## Requirements

- Ansible Core 2.19.13
- RHEL 9 managed nodes with Python 3
- `trippsc2.cis` 1.4.2
- `ansible.posix` 3.0.0
- `community.general` 14.0.0

```bash
ansible-galaxy collection install -r requirements.yml
```

## Inventory

Do not use the same name for a host and a group.

```ini
[rhel9_targets]
rhel9_server_01 ansible_host=192.0.2.10 ansible_user=axp551
```

## Verify configuration

Run from the extracted `rhel9_cis_standard` directory:

```bash
ansible --version
```

It must show this directory's `ansible.cfg`.

## Mandatory site configuration

Review and update this single file before testing:

```text
config/cis_unix_team_inputs.yml
```

Linux and security teams must supply the IPv6 policy, firewall and logging
backends, approved services and ports, time sources, SSH access policy,
banners, password settings, and session timeout. Validation is allowed while
`cis_site_policy_configured` is `false`; controls that need an organization
decision remain `MANUAL_REVIEW_REQUIRED`. Remediation is blocked until the
file has been reviewed, uses explicit policy choices, and contains:

```yaml
cis_site_policy_configured: true
cis_unix_team_inputs_reviewed: true
```

For bootloader remediation, copy `config/vault.example.yml` to a project or
inventory variable file, replace the placeholder, and encrypt it:

```bash
cp config/vault.example.yml inventory/group_vars/rhel9_targets/vault.yml
ansible-vault encrypt inventory/group_vars/rhel9_targets/vault.yml
```

Do not put a real password in the role's example file.

## Validation only

All phases:

```bash
ansible-playbook -i inventory.ini example/run_all_phases.yml \
  -e "cis_operation=validate"
```

One phase:

```bash
ansible-playbook -i inventory.ini example/run_one_phase.yml \
  -e "cis_operation=validate cis_phase=03"
```

Validation does not take a backup and does not include
`trippsc2.cis.rhel9`. Every validation command uses `changed_when: false`.

## Remediation

All phases:

```bash
ansible-playbook -i inventory.ini example/run_all_phases.yml \
  -e "cis_operation=remediate" --diff
```

One phase:

```bash
ansible-playbook -i inventory.ini example/run_one_phase.yml \
  -e "cis_operation=remediate cis_phase=03" --diff
```

The remediation workflow is:

1. Read-only pre-validation.
2. Select proven non-compliant controls.
3. Back up major configuration paths.
4. Enable only approved collection flags.
5. Run `trippsc2.cis.rhel9`.
6. Run read-only post-validation.
7. Automatically generate CSV.

## Site-policy variables

The values below are maintained in `config/cis_unix_team_inputs.yml`. Controls
without an organization decision report `MANUAL_REVIEW_REQUIRED`.

```yaml
cis_ipv6_policy: enabled         # review, enabled, disabled
cis_firewall_backend: firewalld # review, firewalld, nftables
cis_logging_backend: rsyslog    # review, journald, rsyslog
```

Version 2.1.0 does not allow configuration to expand the tested automatic
remediation allowlist. This prevents a policy file from sending a manual or
unverified control to the remediation collection.

Bootloader remediation requires an encrypted variable, but bootloader
validation never asks for it:

```yaml
rhel9cis_bootloader_password: "{{ vault_rhel9cis_bootloader_password }}"
```

## CSV report

The callback automatically writes:

```text
reports/rhel9_cis_results.csv
```

To override the path:

```bash
export RHEL9_CIS_CSV_OUTPUT="$PWD/reports/my_run.csv"
```

Statuses are explicit: `COMPLIANT`, `NON_COMPLIANT`, `NOT_APPLICABLE`,
`MANUAL_REVIEW_REQUIRED`, `APPROVED_EXCEPTION`, `VALIDATION_ERROR`, `REMEDIATION_COMPLETED`,
`REMEDIATION_NOT_ATTEMPTED`, `NON_COMPLIANT_AFTER_REMEDIATION`, and
`POST_VALIDATION_ERROR` or `REMEDIATION_INCOMPLETE`.

## Safety rule

An automatic result is produced only when a safe local command can prove the
checkpoint. Policy-based or review controls are included but are never
converted to `COMPLIANT` from an Ansible skip or unchanged result. See
`COVERAGE.md` for the automatic/manual breakdown.

## Verification scope

Every selected checkpoint is processed and receives a CSV row. For an all
phases run, that is all 221 supplied checkpoints: 191 have automatic,
read-only validators and 30 receive an explicit manual/policy result. A manual
result is not silently treated as compliant. See `COVERAGE.md` for the phase
breakdown.

## Audit alignment

The validation baseline is the supplied Tenable
`CIS_Red_Hat_Enterprise_Linux_9_v2.0.0_L1_Server.audit`, revision 1.15
(2026-07-23), SHA-256
`32d20b5d5dd69c5a1bad1b420fedb721b3d0e3335eac5d0afaa9fc38003ec3bd`.
The licensed audit file is not redistributed. The role implements independent,
read-only checks for the supplied 221-control inventory. Final parity must be
confirmed by running this role and the Tenable audit on the same RHEL 9 test
host after the Unix-team configuration is completed.
