# Source-required reviews

- 1.1.1.9 Ensure unused filesystems kernel modules are not available — Identify unused filesystem modules before unloading application dependencies.
- 1.2.1.4 Ensure package manager repositories are configured — Repository approval requires review per source.
- 2.1.22 Ensure only approved services are listening on a network interface — Review approved application listeners before disabling services.
- 4.2.1 Ensure firewalld drops unnecessary services and ports — Determine unnecessary ports and services before removal.
- 4.3.1 Ensure nftables base chains exist — Existing chain structure and application traffic must be preserved before applying nftables changes.
- 4.3.2 Ensure nftables established connections are configured — Existing chain structure and application traffic must be preserved before applying nftables changes.
- 4.3.3 Ensure nftables default deny firewall policy — Existing chain structure and application traffic must be preserved before applying nftables changes.
- 5.4.2.5 Ensure root path integrity — Root PATH entries and directory ownership require review.
- 6.2.1.2 Ensure journald log file access is configured — Apply source-specific permissions by log type and owner, preserving daemon access.
- 6.2.2.1.2 Ensure systemd-journal-upload authentication is configured — Remote HTTPS collector and certificates are not provided by the source.
- 6.2.3.6 Ensure rsyslog is configured to send logs to a remote log host — Source contains an example collector; a real endpoint cannot be invented.
- 6.2.3.8 Ensure rsyslog logrotate is configured — Review all configured destinations against existing rotation stanzas; do not duplicate rotation rules.
- 6.2.4.1 Ensure access to all logfiles has been configured — Apply source-specific permissions by log type and owner, preserving daemon access.
- 7.1.12 Ensure no files or directories without an owner and a group exist — Ownership assignment or SUID/SGID approval requires source-directed investigation.
- 7.1.13 Ensure SUID and SGID files are reviewed — Ownership assignment or SUID/SGID approval requires source-directed investigation.

Additional conditional blockers: missing separate mount points, missing trusted GPG keys, missing SSH access rules, unmanaged authentication profiles, ambiguous UID/GID/name corrections, and unsafe home paths/trust files. These stop remediation with evidence.
