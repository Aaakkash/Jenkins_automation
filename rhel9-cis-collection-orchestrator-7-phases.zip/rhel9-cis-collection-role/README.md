# RHEL 9 CIS collection orchestration role

This package wraps the `trippsc2.cis.rhel9` role with backup, validation,
conditional remediation, post-validation and CSV reporting.

## Collections

The tested versions are defined in `requirements.yml`:

- `trippsc2.cis` 1.4.2
- `ansible.posix` 3.0.0
- `community.general` 14.0.0

Install them locally inside the project:

```bash
./scripts/install_collections.sh
```

## Configure

1. Update `inventory/hosts.ini` with the RHEL 9 servers and SSH user.
2. Review `group_vars/all.yml`, especially NTP, firewall, SSH access and the
   remote log server.
3. Add the GRUB password to `group_vars/vault.yml`, then encrypt it:

```bash
ansible-vault encrypt group_vars/vault.yml
```

## Run one phase

```bash
./scripts/run_phase.sh 01 --ask-vault-pass
```

The script automatically performs:

1. Backup.
2. Pre-remediation validation using Ansible check mode.
3. Remediation only when changed/non-compliant checkpoints are found.
4. Post-remediation validation.
5. CSV generation.

## Run all seven phases

```bash
./scripts/run_all_phases.sh --ask-vault-pass
```

The consolidated CSV is created at:

```text
reports/<run-id>/cis-results.csv
```

Backups are created on each managed server at:

```text
/var/backups/rhel9-cis/<run-id>/phase<phase>/
```

## CSV status meanings

- `COMPLIANT`: Validation found no remediation requirement.
- `REMEDIATION_COMPLETED`: Remediation ran and post-validation is clean.
- `NON_COMPLIANT_AFTER_REMEDIATION`: Post-validation still proposes changes.
- `PRE_VALIDATION_FAILED`: The initial validation failed.
- `REMEDIATION_FAILED`: A remediation task failed.
- `POST_VALIDATION_FAILED`: The validation after remediation failed.
- `NOT_EVALUATED`: The collection did not return a result for the checkpoint.

The `remediation_completed` CSV column is set to `YES` for each checkpoint
that required remediation and passed post-validation.
