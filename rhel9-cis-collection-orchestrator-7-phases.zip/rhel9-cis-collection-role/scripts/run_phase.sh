#!/usr/bin/env bash
set -uo pipefail

if [[ $# -lt 1 ]]; then
  echo "Usage: $0 <01-07> [additional ansible-playbook arguments]" >&2
  exit 2
fi

printf -v phase '%02d' "$1"
shift
[[ "$phase" =~ ^0[1-7]$ ]] || { echo "Phase must be 01 through 07." >&2; exit 2; }

project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$project_dir"

run_id="${CIS_RUN_ID:-$(date -u +%Y%m%dT%H%M%SZ)}"
run_dir="reports/$run_id"
events="$run_dir/events.jsonl"
control_map="reference/checkpoint-list.csv"
mkdir -p "$run_dir"

run_stage() {
  local stage="$1"
  local logfile="$2"
  shift 2
  CIS_RUN_ID="$run_id" CIS_RUN_STAGE="$stage" CIS_PHASE="$phase" CIS_EVENT_FILE="$events" \
    ansible-playbook playbooks/cis.yml \
      -e "cis_phase=$phase" -e "cis_run_id=$run_id" "$@" 2>&1 | tee "$logfile"
  return "${PIPESTATUS[0]}"
}

echo "Phase $phase - Step 1: backup"
run_stage backup "$run_dir/phase${phase}-01-backup.log" --tags backup "$@"
backup_rc=$?
if [[ "$backup_rc" -ne 0 ]]; then
  echo "Backup failed. No validation or remediation was attempted." >&2
  exit "$backup_rc"
fi

echo "Phase $phase - Step 2: pre-remediation validation"
run_stage pre_validation "$run_dir/phase${phase}-02-pre-validation.log" --tags cis --check --diff "$@"
pre_rc=$?

drift="$(python3 scripts/cis_report.py count \
  --events "$events" --map "$control_map" --run-id "$run_id" --phase "$phase")"

remediation_rc=0
post_rc=0
if [[ "$pre_rc" -eq 0 && "$drift" -gt 0 ]]; then
  echo "Phase $phase - Step 3: remediation required for $drift checkpoint(s)"
  run_stage remediation "$run_dir/phase${phase}-03-remediation.log" --tags cis --diff "$@"
  remediation_rc=$?

  echo "Phase $phase - Step 4: post-remediation validation"
  run_stage post_validation "$run_dir/phase${phase}-04-post-validation.log" --tags cis --check --diff "$@"
  post_rc=$?
elif [[ "$pre_rc" -eq 0 ]]; then
  echo "Phase $phase is compliant. Remediation was not required."
else
  echo "Pre-validation failed; remediation was not started." >&2
fi

python3 scripts/cis_report.py report \
  --events "$events" --map "$control_map" --run-id "$run_id" \
  --output "$run_dir/cis-results.csv"

if [[ "$pre_rc" -ne 0 || "$remediation_rc" -ne 0 || "$post_rc" -ne 0 ]]; then
  exit 1
fi

echo "Phase $phase completed. CSV: $run_dir/cis-results.csv"
