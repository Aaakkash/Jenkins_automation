#!/usr/bin/env python3
"""Count pre-validation drift and create the final per-checkpoint CSV."""

from __future__ import annotations

import argparse
import csv
import json
import re
from collections import defaultdict
from pathlib import Path


CONTROL_RE = re.compile(r"(?<![0-9.])([1-7](?:\.\d+){1,5})(?![0-9.])")


def load_events(path: Path, run_id: str):
    if not path.exists():
        return []
    events = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        event = json.loads(line)
        if event.get("run_id") == run_id:
            events.append(event)
    return events


def load_controls(path: Path):
    with path.open(newline="", encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream))
    return {row["rule"]: row for row in rows}


def aggregate(events, known_controls):
    grouped = defaultdict(lambda: defaultdict(lambda: {
        "seen": False, "skipped": False, "changed": False,
        "failed": False, "messages": []
    }))
    phases = {}
    for event in events:
        task = event.get("task", "")
        controls = [item for item in CONTROL_RE.findall(task) if item in known_controls]
        for control in controls:
            key = (event.get("host", "unknown"), control)
            stage = event.get("stage", "unknown")
            state = grouped[key][stage]
            state["seen"] = True
            state["skipped"] |= event.get("status") == "skipped"
            state["changed"] |= bool(event.get("changed"))
            state["failed"] |= event.get("status") in {"failed", "unreachable"}
            if event.get("message"):
                state["messages"].append(event["message"])
            phases[key] = event.get("phase", "")
    return grouped, phases


def count_drift(args):
    controls = load_controls(args.map)
    events = [e for e in load_events(args.events, args.run_id)
              if e.get("stage") == "pre_validation" and e.get("phase") == args.phase]
    grouped, _ = aggregate(events, controls)
    drift = sum(1 for stages in grouped.values()
                if stages["pre_validation"]["changed"] or stages["pre_validation"]["failed"])
    print(drift)


def create_report(args):
    controls = load_controls(args.map)
    events = load_events(args.events, args.run_id)
    grouped, phases = aggregate(events, controls)
    hosts = sorted({event.get("host", "unknown") for event in events})
    executed_phases = defaultdict(set)
    for event in events:
        if event.get("stage") == "pre_validation":
            executed_phases[event.get("host", "unknown")].add(event.get("phase", ""))

    output_rows = []
    for host in hosts:
        for control, metadata in controls.items():
            expected_phase = control.split('.', 1)[0].zfill(2)
            if expected_phase not in executed_phases[host]:
                continue
            key = (host, control)
            stages = grouped[key]
            pre = stages["pre_validation"]
            remediation = stages["remediation"]
            post = stages["post_validation"]

            if not pre["seen"]:
                final = "NOT_EVALUATED"
            elif pre["failed"]:
                final = "PRE_VALIDATION_FAILED"
            elif not pre["changed"]:
                final = "COMPLIANT"
            elif remediation["failed"]:
                final = "REMEDIATION_FAILED"
            elif post["failed"]:
                final = "POST_VALIDATION_FAILED"
            elif post["changed"]:
                final = "NON_COMPLIANT_AFTER_REMEDIATION"
            elif post["seen"] and not post["changed"]:
                final = "REMEDIATION_COMPLETED"
            else:
                final = "REMEDIATION_ATTEMPTED_NO_CHANGE"

            phase = phases.get(key, expected_phase)
            output_rows.append({
                "run_id": args.run_id,
                "host": host,
                "phase": phase,
                "control_id": control,
                "title": metadata.get("title", ""),
                "pre_validation": (
                    "NOT_EVALUATED" if not pre["seen"] else
                    "NON_COMPLIANT" if pre["changed"] else "COMPLIANT"
                ),
                "remediation_required": "YES" if pre["changed"] else "NO",
                "remediation_changed": "YES" if remediation["changed"] else "NO",
                "remediation_completed": "YES" if final == "REMEDIATION_COMPLETED" else "NO",
                "post_validation": (
                    "NON_COMPLIANT" if post["changed"] else
                    "COMPLIANT" if post["seen"] else "NOT_REQUIRED"
                ),
                "final_status": final,
                "backup_path": f"/var/backups/rhel9-cis/{args.run_id}/phase{phase}",
            })

    args.output.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "run_id", "host", "phase", "control_id", "title",
        "pre_validation", "remediation_required", "remediation_changed",
        "remediation_completed", "post_validation", "final_status", "backup_path"
    ]
    with args.output.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(sorted(output_rows, key=lambda row: (row["host"], row["phase"], row["control_id"])))
    print(args.output)


def main():
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="command", required=True)

    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--events", type=Path, required=True)
    common.add_argument("--map", type=Path, required=True)
    common.add_argument("--run-id", required=True)

    count = subparsers.add_parser("count", parents=[common])
    count.add_argument("--phase", required=True)
    count.set_defaults(func=count_drift)

    report = subparsers.add_parser("report", parents=[common])
    report.add_argument("--output", type=Path, required=True)
    report.set_defaults(func=create_report)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
