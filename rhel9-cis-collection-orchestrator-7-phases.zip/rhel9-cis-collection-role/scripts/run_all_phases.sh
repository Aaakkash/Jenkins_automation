#!/usr/bin/env bash
set -uo pipefail

project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$project_dir"

run_id="$(date -u +%Y%m%dT%H%M%SZ)"
export CIS_RUN_ID="$run_id"
overall_rc=0

for phase in 01 02 03 04 05 06 07; do
  echo "===== Starting phase $phase ====="
  scripts/run_phase.sh "$phase" "$@" || overall_rc=1
done

python3 scripts/cis_report.py report \
  --events "reports/$run_id/events.jsonl" \
  --map reference/checkpoint-list.csv \
  --run-id "$run_id" \
  --output "reports/$run_id/cis-results.csv"

echo "Final CSV: reports/$run_id/cis-results.csv"
exit "$overall_rc"
