"""Write controller-side task results as JSON lines for the CIS CSV report."""

from __future__ import annotations

import fcntl
import json
import os
from datetime import datetime, timezone
from pathlib import Path

from ansible.plugins.callback import CallbackBase


DOCUMENTATION = r"""
callback: cis_event_logger
type: aggregate
short_description: Records CIS task results for reporting
version_added: "1.0"
requirements:
  - Set CIS_EVENT_FILE, CIS_RUN_STAGE, CIS_PHASE and CIS_RUN_ID
"""


class CallbackModule(CallbackBase):
    CALLBACK_VERSION = 2.0
    CALLBACK_TYPE = "aggregate"
    CALLBACK_NAME = "cis_event_logger"
    CALLBACK_NEEDS_ENABLED = True

    def _write(self, result, status: str) -> None:
        target = os.environ.get("CIS_EVENT_FILE")
        if not target:
            return

        data = result._result or {}
        event = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "run_id": os.environ.get("CIS_RUN_ID", "manual"),
            "stage": os.environ.get("CIS_RUN_STAGE", "unknown"),
            "phase": os.environ.get("CIS_PHASE", "unknown"),
            "host": result._host.get_name(),
            "task": result._task.get_name().strip(),
            "status": status,
            "changed": bool(data.get("changed", False)),
            "message": str(data.get("msg", ""))[:1000],
        }

        path = Path(target)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as stream:
            fcntl.flock(stream.fileno(), fcntl.LOCK_EX)
            stream.write(json.dumps(event, ensure_ascii=False) + "\n")
            stream.flush()
            fcntl.flock(stream.fileno(), fcntl.LOCK_UN)

    def v2_runner_on_ok(self, result, **kwargs):
        self._write(result, "ok")

    def v2_runner_on_failed(self, result, ignore_errors=False):
        self._write(result, "failed_ignored" if ignore_errors else "failed")

    def v2_runner_on_unreachable(self, result):
        self._write(result, "unreachable")

    def v2_runner_on_skipped(self, result):
        self._write(result, "skipped")
