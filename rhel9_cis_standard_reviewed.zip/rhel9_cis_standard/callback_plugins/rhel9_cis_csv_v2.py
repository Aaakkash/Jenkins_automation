"""Write one CSV from structured, read-only RHEL 9 CIS validation results."""

from __future__ import annotations

import csv
import json
import os
import re
from datetime import datetime, timezone
from pathlib import Path

from ansible.plugins.callback import CallbackBase


DOCUMENTATION = r"""
callback: rhel9_cis_csv_v2
type: aggregate
short_description: Write structured RHEL 9 CIS validation results to CSV
version_added: "2.0"
requirements:
  - Enable with callbacks_enabled=rhel9_cis_csv_v2
"""


class CallbackModule(CallbackBase):
    CALLBACK_VERSION = 2.0
    CALLBACK_TYPE = "aggregate"
    CALLBACK_NAME = "rhel9_cis_csv_v2"
    CALLBACK_NEEDS_ENABLED = True

    def __init__(self):
        super().__init__()
        self.payloads: list[dict] = []
        self.remediation_events: dict[tuple[str, str], list[dict]] = {}
        self.remediation_hosts: set[str] = set()

    def _record_remediation(self, result, failed=False):
        """Collect real task results between the pre and remediation payloads.

        Control IDs come from the task/block names, rule tags or conditions.
        Shared tasks can be associated with several selected controls. No
        target commands are executed by this callback.
        """
        host = result._host.get_name()
        if host not in self.remediation_hosts:
            return
        task = getattr(result, '_task', None)
        if task is None:
            return
        data = result._result or {}
        if data.get('skipped'):
            return
        action = str(getattr(task, 'action', '')).rsplit('.', 1)[-1]
        if action in {
            'assert', 'debug', 'fail', 'find', 'getent', 'include_role',
            'include_tasks', 'include_vars', 'import_role', 'import_tasks',
            'meta', 'read_csv', 'service_facts', 'set_fact', 'setup', 'slurp',
            'stat', 'wait_for', 'wait_for_connection',
        }:
            return

        ids = set()
        node = task
        visited = set()
        hidden = bool(data.get('_ansible_no_log'))
        while node is not None and id(node) not in visited:
            visited.add(id(node))
            hidden = hidden or bool(getattr(node, 'no_log', False))
            name = str(getattr(node, 'name', '') or '')
            # Prefer the nearest explicit control name over a broad parent.
            if not ids:
                ids.update(re.findall(r'(?<![\d.])([1-7](?:\.\d+)+)(?![\d.])', name))
            if not ids:
                conditions = str(getattr(node, 'when', []) or [])
                ids.update(re.findall(r"['\"]([1-7](?:\.\d+)+)['\"]", conditions))
                rule_text = str(getattr(node, 'tags', []) or []) + ' ' + conditions
                ids.update(
                    value.replace('_', '.')
                    for value in re.findall(r'rhel9cis_rule_([1-7](?:_\d+)+)', rule_text)
                )
            node = getattr(node, '_parent', None)
        if not ids:
            return

        def event_for(item):
            private = hidden or bool(item.get('_ansible_no_log'))
            event = {
                'task': str(getattr(task, 'name', '') or action),
                'module': action,
                'status': 'failed' if item.get('failed', failed if item is data else False) else 'ok',
                'changed': bool(item.get('changed', False)),
                'controls': sorted(ids),
            }
            if private:
                event['output'] = 'REDACTED: Ansible no_log task'
                return event
            # Select result fields; never dump invocation, environment, facts,
            # slurped file contents or module-specific service status dictionaries.
            for key in ('cmd', 'rc', 'stdout', 'stderr', 'msg', 'path', 'dest',
                        'state', 'mode', 'owner', 'group', 'uid', 'gid',
                        'enabled', 'masked', 'backup_file'):
                if key in item:
                    event[key] = item[key]
            args = (item.get('invocation') or {}).get('module_args') or {}
            safe_keys = ('name', 'path', 'dest', 'src', 'state', 'mode', 'owner',
                         'group', 'enabled', 'masked', 'regexp', 'line', 'section',
                         'option', 'value', 'argv', 'cmd', 'recurse')
            event['parameters'] = {key: args[key] for key in safe_keys if key in args}
            # File permission diffs are useful even when module stdout is empty.
            # Omit content diffs, which could contain credentials.
            diffs = item.get('diff') or []
            if isinstance(diffs, dict):
                diffs = [diffs]
            changes = []
            for diff in diffs:
                if not isinstance(diff, dict):
                    continue
                change = {}
                for side in ('before', 'after'):
                    values = diff.get(side)
                    if isinstance(values, dict):
                        change[side] = {key: values[key] for key in
                                        ('path', 'mode', 'owner', 'group', 'state')
                                        if key in values}
                if any(change.values()):
                    changes.append(change)
            if changes:
                event['changes'] = changes
            return event

        items = data.get('results')
        if not isinstance(items, list):
            items = [data]
        for item in items:
            if not isinstance(item, dict) or item.get('skipped'):
                continue
            event = event_for(item)
            for control_id in ids:
                self.remediation_events.setdefault((host, control_id), []).append(event)

    def v2_runner_on_failed(self, result, ignore_errors=False):
        self._record_remediation(result, failed=True)

    def v2_runner_on_unreachable(self, result):
        self._record_remediation(result, failed=True)

    def v2_runner_on_ok(self, result, **kwargs):
        self._record_remediation(result)
        data = result._result or {}
        message = data.get("msg")
        if not isinstance(message, dict):
            return
        payload = message.get("cis_report_payload")
        if not isinstance(payload, dict):
            return
        payload = dict(payload)
        payload["host"] = str(payload.get("host") or result._host.get_name())
        host = payload['host']
        if payload.get('stage') == 'pre':
            self.remediation_events = {
                key: value for key, value in self.remediation_events.items()
                if key[0] != host
            }
            if payload.get('operation') == 'remediate':
                self.remediation_hosts.add(host)
        elif payload.get('stage') in {'remediation', 'final'}:
            self.remediation_hosts.discard(host)
        self.payloads.append(payload)

    def v2_playbook_on_stats(self, stats):
        if not self.payloads:
            return

        output = Path(
            os.environ.get("RHEL9_CIS_CSV_OUTPUT", "reports/rhel9_cis_results.csv")
        )
        output.parent.mkdir(parents=True, exist_ok=True)
        generated = datetime.now(timezone.utc).isoformat()
        rows = []
        controls: dict[tuple[str, str], dict] = {}

        for payload in self.payloads:
            host = str(payload.get("host", "unknown"))
            pre_results = payload.get("results") or []
            post_by_id = {
                item.get("control_id"): item
                for item in (payload.get("post_results") or [])
            }
            attempted = set(payload.get("remediation_attempted") or [])
            stage_priority = {
                "pre": 1,
                "remediation": 2,
                "final": 3,
            }.get(payload.get("stage"), 0)

            for pre in pre_results:
                key = (host, str(pre.get("control_id", "")))
                if key not in controls or stage_priority >= controls[key]["priority"]:
                    controls[key] = {
                        "host": host,
                        "operation": payload.get("operation", "validate"),
                        "pre": pre,
                        "post": post_by_id.get(pre.get("control_id")),
                        "attempted": attempted,
                        "priority": stage_priority,
                    }

        for state in controls.values():
            host = state["host"]
            operation = state["operation"]
            pre = state["pre"]
            post = state["post"]
            attempted = state["attempted"]
            control_id = str(pre.get("control_id", ""))
            pre_status = str(pre.get("status", "VALIDATION_ERROR"))
            post_status = str(post.get("status")) if post else "NOT_RUN"

            if operation == "validate":
                final_status = pre_status
            elif pre_status != "NON_COMPLIANT":
                final_status = pre_status
            elif control_id not in attempted:
                final_status = "REMEDIATION_NOT_ATTEMPTED"
            elif post_status == "COMPLIANT":
                final_status = "REMEDIATION_COMPLETED"
            elif post_status == "NON_COMPLIANT":
                final_status = "NON_COMPLIANT_AFTER_REMEDIATION"
            elif post_status == "VALIDATION_ERROR":
                final_status = "POST_VALIDATION_ERROR"
            elif post_status == "NOT_RUN":
                final_status = "REMEDIATION_INCOMPLETE"
            else:
                final_status = post_status

            rows.append(
                {
                    "generated_utc": generated,
                    "host": host,
                    "plugin_id": pre.get("plugin_id", ""),
                    "phase": str(pre.get("phase", "")).zfill(2),
                    "control_id": control_id,
                    "checkpoint": pre.get("checkpoint", ""),
                    "validation_type": pre.get("validation_type", ""),
                    "validation_source": pre.get("validation_source", ""),
                    "remediation_safe": (
                        "YES" if pre.get("remediation_safe") else "NO"
                    ),
                    "pre_validation": pre_status,
                    "remediation_required": (
                        "YES" if pre_status == "NON_COMPLIANT" else "NO"
                    ),
                    "remediation_attempted": (
                        "YES" if control_id in attempted else "NO"
                    ),
                    "remediation_completed": (
                        "YES" if final_status == "REMEDIATION_COMPLETED" else "NO"
                    ),
                    "post_validation": post_status,
                    "final_status": final_status,
                    "pre_validation_output": pre.get("evidence", ""),
                    "remediation_output": (
                        json.dumps(self.remediation_events[(host, control_id)],
                                   ensure_ascii=False, default=str)
                        if self.remediation_events.get((host, control_id)) else
                        ('No mapped remediation task result was captured; '
                         'do not infer a change from the final status.'
                         if control_id in attempted else
                         'Not run: validation only, already compliant, missing input, '
                         'unsupported control or skipped by policy.')
                    ),
                    "evidence": (
                        post.get("evidence", "") if post else pre.get("evidence", "")
                    ),
                }
            )

        fields = [
            "generated_utc",
            "host",
            "plugin_id",
            "phase",
            "control_id",
            "checkpoint",
            "validation_type",
            "validation_source",
            "remediation_safe",
            "pre_validation",
            "remediation_required",
            "remediation_attempted",
            "remediation_completed",
            "post_validation",
            "final_status",
            "pre_validation_output",
            "remediation_output",
            "evidence",
        ]

        def control_key(row):
            return (
                row["host"],
                [int(part) for part in row["control_id"].split(".")],
            )

        with output.open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=fields)
            writer.writeheader()
            writer.writerows(sorted(rows, key=control_key))

        self._display.display(f"RHEL 9 CIS CSV report: {output}", color="green")
