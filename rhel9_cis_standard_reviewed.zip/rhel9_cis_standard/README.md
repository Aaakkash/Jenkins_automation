# RHEL 9 CIS Standard Role v2.2.1

This reusable role processes all 221 supplied RHEL 9 CIS checkpoints. Every
checkpoint has a read-only validator. Validator return code `0` is the only
result classified `COMPLIANT`; every other executed return code is
`NON_COMPLIANT`.

If a checkpoint needs a site value that has not been supplied, it is reported
as `CONFIG_VALUE_MISSING`, skipped for remediation, and the remaining controls
continue. No checkpoint is put on an exclusion list and no result is classified
as manual review.

## Requirements

- Ansible Core 2.19.13
- RHEL 9 managed nodes with Python 3
- `trippsc2.cis` 1.4.2
- `ansible.posix` 3.0.0
- `community.general` 14.0.0

```bash
ansible-galaxy collection install -r requirements.yml
```

## One configuration file

All Unix, security, network and application-team inputs are kept only in
`config/cis_unix_team_inputs.yml`.

Replace every `CHANGE_ME` value, select non-`review` policy values, populate
the approved inventories, and change each relevant `_configured` or
`_completed` confirmation flag to `true`. Because the same file contains the
GRUB password, encrypt it before production use:

```bash
ansible-vault encrypt config/cis_unix_team_inputs.yml
```

Then add `--ask-vault-pass` or your normal vault-ID option to the playbook
command. The role never writes back to this configuration file.

Confirm the firewall source CIDRs, management ports and application ports
before setting `cis_nftables_policy_configured: true`; an incorrect value can
block SSH.

## Inventory

Do not use the same name for a host and a group.

```ini
[rhel9_targets]
rhel9_server_01 ansible_host=192.0.2.10 ansible_user=axp551
```

Run commands from the extracted `rhel9_cis_standard` directory. Verify that
`ansible --version` reports this directory's `ansible.cfg`.

## Validation only

```bash
# All phases
ansible-playbook -i inventory.ini example/run_all_phases.yml \
  -e "cis_operation=validate cis_phase=all"

# One phase
ansible-playbook -i inventory.ini example/run_one_phase.yml \
  -e "cis_operation=validate cis_phase=03"
```

## Remediation

```bash
# All phases
ansible-playbook -i inventory.ini example/run_all_phases.yml \
  -e "cis_operation=remediate cis_phase=all" --diff

# One phase
ansible-playbook -i inventory.ini example/run_one_phase.yml \
  -e "cis_operation=remediate cis_phase=03" --diff
```

The workflow is pre-validation, failed-control selection, backup, targeted
remediation, collection/custom remediation, post-validation, and automatic CSV
generation. The collection is never used for validation. Only controls that
executed and returned nonzero are candidates for remediation.

For nftables, the role uses a custom ruleset because the supplied collection
does not fully implement controls 4.3.1 through 4.3.3. The current firewall
configuration is backed up before replacement. When nftables is selected, the
role stops, disables and masks firewalld, then un-masks, enables and starts
nftables so that only the selected firewall service is active.

## CSV report

The callback automatically writes `reports/rhel9_cis_results.csv`.
`CONFIG_VALUE_MISSING` rows contain the exact missing variable names in the
evidence column. A remediated row is marked `REMEDIATION_COMPLETED` only when
post-validation returns RC 0.

## Acceptance requirement

Static tests prove inventory, YAML and shell syntax coverage, but they do not
prove target compliance. Run this role and the supplied Tenable audit on the
same non-production RHEL 9 server and compare every control before production.
See `AUDIT_ALIGNMENT.md` for the audit scope difference.


## Report evidence columns

The CSV retains all existing status columns and adds:

- `pre_validation_output`: the initial validator evidence, including its return
  code and output as provided by `tasks/validate_one.yml`.
- `remediation_output`: a JSON list in one CSV cell containing actual mapped
  remediation task results: task, module, changed flag, command/return code and
  stdout/stderr when returned. Native modules provide returned path, mode,
  ownership and selected parameters instead of invented command output. Shared
  tasks list their associated controls. Unchanged tasks explicitly say
  `changed=false`; a successful task result alone does not prove compliance.
- The existing `evidence` column contains post-validation evidence when available,
  otherwise initial evidence. Compare it with `pre_validation_output` and
  `post_validation` to see whether the selected remediation resolved the finding.

Ansible `no_log` task output is redacted. Full file-content diffs, environments,
slurped contents and service status dictionaries are not copied into the CSV.
If no mapped task result was captured, the CSV says so; it does not invent a
change. This callback must remain enabled in the controller's active Ansible
configuration. When integrating the role into a client project, configure that
project to load this role's `callback_plugins` directory and enable
`rhel9_cis_csv_v2` as in the supplied `ansible.cfg`.

## Cleanup and validation of this delivery

Removed 14 exact duplicate top-level remediation tasks, the extra include of
`remediate.yml` (that file is absent; the workflow already includes
`remediate_report_gaps.yml`), cached Python bytecode, an old generated CSV,
the duplicate example `ansible.cfg`, and development tests from the runtime
package. Required templates, conditional remediation files, checkpoint inventory,
collection flags, dependencies and configuration are retained. No runtime files
were added. Existing remediation actions, policy values and validators were not
rewritten; reporting changes are confined to the existing callback.

Checks completed: unique YAML keys and parsing, reference inspection, all 221
validator templates rendered and Bash syntax checked, embedded validator Python
syntax checked, and the callback exercised using Ansible Core 2.19.13 on two
local fixture hosts. Callback fixtures covered native module results, command
output, loops, failures, parent control association and `no_log` redaction.
These fixtures did not run CIS remediation on a RHEL server. Full role syntax
and execution validation are limited by the pinned `trippsc2.cis:1.4.2`
dependency, which the available Galaxy resolver could not resolve. The full
role syntax check stops at the unavailable `community.general.read_csv` module;
the declared collection dependencies must be installed on the controller.

### Reboot behavior

The reboot task runs once per host only when `cis_operation == 'remediate'`
and `cis_remediation_ids` is nonempty. It follows the complete remediation
include (custom and collection tasks, including the handler flush) and precedes
post-validation. Validation-only runs and runs with no selected remediation
skip reboot. An unhandled task failure stops normal execution before reboot.
The module waits for the server to reconnect before post-validation starts.
This is a selected-remediation condition, not a changed-only condition: if
selected tasks finish without changes, the reboot still occurs.

Keep the site-owned input file encrypted as described above when distributing
it to the client.

## IPv6 enabled remediation selection update

The existing IPv6 enable task and validator are retained. Both selection
filters in `tasks/main.yml` now permit control `3.1.1` when
`cis_ipv6_policy: enabled`, matching the task assertion. Disabled or review
policy skips this enable-only remediation. Other selection filters, configuration values and remediation tasks are
unchanged. The reboot condition is updated as described above.


## Unresolved compliance findings

`cis_fail_remediation_when_unresolved` now defaults to `false`. A control that
remains non-compliant after remediation is still recorded honestly as
`NON_COMPLIANT_AFTER_REMEDIATION` in the CSV, with initial, remediation and
post-validation evidence. The final unresolved-control assertion is skipped
by default, so compliance findings alone do not produce a fatal playbook error.
Actual task/command failures are not suppressed or changed. Explicitly
setting `cis_fail_remediation_when_unresolved: true` restores strict failure
behavior if a future caller requests it.


## Consolidated nftables remediation

The nine tasks previously in `tasks/remediate_nftables.yml` are now an inline
block in `tasks/remediate_report_gaps.yml`, at the former include position.
Task order, parameters, registers, per-task conditions and both outer
nftables-selection conditions are preserved. The separate task file and its
include are removed. `templates/cis-nftables.nft.j2` is still required.
