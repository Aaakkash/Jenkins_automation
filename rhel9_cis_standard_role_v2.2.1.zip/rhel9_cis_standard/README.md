# RHEL 9 CIS Standard Role v2.2.1

This reusable role processes all 221 supplied RHEL 9 CIS checkpoints. Every
checkpoint has a read-only validator. Validator return code `0` is the only
result classified `COMPLIANT`; every other executed return code is
`NON_COMPLIANT`.

If a checkpoint needs a site value that has not been supplied, it is reported
as `CONFIG_VALUE_MISSING`, skipped for remediation, and the remaining controls
continue. No checkpoint is put on an exclusion list and no result is classified
as manual review.

## Requirements

- Ansible Core 2.19.13
- RHEL 9 managed nodes with Python 3
- `trippsc2.cis` 1.4.2
- `ansible.posix` 3.0.0
- `community.general` 14.0.0

```bash
ansible-galaxy collection install -r requirements.yml
```

## One configuration file

All Unix, security, network and application-team inputs are kept only in
`config/cis_unix_team_inputs.yml`.

Replace every `CHANGE_ME` value, select non-`review` policy values, populate
the approved inventories, and change each relevant `_configured` or
`_completed` confirmation flag to `true`. Because the same file contains the
GRUB password, encrypt it before production use:

```bash
ansible-vault encrypt config/cis_unix_team_inputs.yml
```

Then add `--ask-vault-pass` or your normal vault-ID option to the playbook
command. The role never writes back to this configuration file.

Confirm the firewall source CIDRs, management ports and application ports
before setting `cis_nftables_policy_configured: true`; an incorrect value can
block SSH.

## Inventory

Do not use the same name for a host and a group.

```ini
[rhel9_targets]
rhel9_server_01 ansible_host=192.0.2.10 ansible_user=axp551
```

Run commands from the extracted `rhel9_cis_standard` directory. Verify that
`ansible --version` reports this directory's `ansible.cfg`.

## Validation only

```bash
# All phases
ansible-playbook -i inventory.ini example/run_all_phases.yml \
  -e "cis_operation=validate cis_phase=all"

# One phase
ansible-playbook -i inventory.ini example/run_one_phase.yml \
  -e "cis_operation=validate cis_phase=03"
```

## Remediation

```bash
# All phases
ansible-playbook -i inventory.ini example/run_all_phases.yml \
  -e "cis_operation=remediate cis_phase=all" --diff

# One phase
ansible-playbook -i inventory.ini example/run_one_phase.yml \
  -e "cis_operation=remediate cis_phase=03" --diff
```

The workflow is pre-validation, failed-control selection, backup, targeted
remediation, collection/custom remediation, post-validation, and automatic CSV
generation. The collection is never used for validation. Only controls that
executed and returned nonzero are candidates for remediation.

For nftables, the role uses a custom ruleset because the supplied collection
does not fully implement controls 4.3.1 through 4.3.3. The current firewall
configuration is backed up before replacement. When nftables is selected, the
role stops, disables and masks firewalld, then un-masks, enables and starts
nftables so that only the selected firewall service is active.

## CSV report

The callback automatically writes `reports/rhel9_cis_results.csv`.
`CONFIG_VALUE_MISSING` rows contain the exact missing variable names in the
evidence column. A remediated row is marked `REMEDIATION_COMPLETED` only when
post-validation returns RC 0.

## Acceptance requirement

Static tests prove inventory, YAML and shell syntax coverage, but they do not
prove target compliance. Run this role and the supplied Tenable audit on the
same non-production RHEL 9 server and compare every control before production.
See `AUDIT_ALIGNMENT.md` for the audit scope difference.
