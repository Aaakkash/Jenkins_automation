# Supplied Tenable audit alignment

Reference: `CIS_Red_Hat_Enterprise_Linux_9_v2.0.0_L1_Server.audit`

- Benchmark: CIS Red Hat Enterprise Linux 9 v2.0.0 L1 Server
- Tenable audit revision: 1.15
- Audit date: 2026-07-23
- SHA-256: `32d20b5d5dd69c5a1bad1b420fedb721b3d0e3335eac5d0afaa9fc38003ec3bd`
- Supplied project inventory: 221 checkpoints
- Role coverage: 221 explicit result definitions
- Automatic read-only checks: 221
- Manual/policy results: 0

The licensed Tenable file and its long command bodies are not included in this
package. Validators are concise, independent implementations of the same
requirements. Important parity protections include persistent and runtime
sysctl evaluation, persistent fstab option evaluation, BIOS and UEFI boot-file
permissions, contextual `sshd -T -C` crypto evaluation, and site-input-driven
checks where the audit itself calls for review. Missing site data is reported
as `CONFIG_VALUE_MISSING`.

Static and simulated callback tests do not replace RHEL 9 acceptance testing.
Before production remediation, run validation and the Tenable audit against
the same test server, compare every control ID, and investigate differences.

## Scope difference

The supplied project checkpoint list is a 221-control subset of the attached
235-control audit. The following audit controls are not present in the supplied
`files/checkpoints.csv` and are therefore not run or remediated by this role:

`2.1.6`, `2.1.12`, `4.1.2`, `4.3.4`, `5.2.7`, `5.4.1.1`, `5.4.1.5`,
`5.4.2.2`, `5.4.2.7`, `6.2.2.1.1`, `6.2.2.1.3`, `6.2.2.2`, `6.2.2.3`,
and `6.2.2.4`.
