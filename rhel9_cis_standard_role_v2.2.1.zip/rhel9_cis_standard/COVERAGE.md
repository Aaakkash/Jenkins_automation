# Validation coverage

All 221 supplied checkpoints have explicit automatic, read-only validators.
There are no manual validators and no excluded controls.

| Phase | Total | Automatic | Manual |
|---:|---:|---:|---:|
| 01 | 66 | 66 | 0 |
| 02 | 35 | 35 | 0 |
| 03 | 14 | 14 | 0 |
| 04 | 6 | 6 | 0 |
| 05 | 60 | 60 | 0 |
| 06 | 18 | 18 | 0 |
| 07 | 22 | 22 | 0 |
| **Total** | **221** | **221** | **0** |

Only validator RC 0 is `COMPLIANT`. A nonzero RC is `NON_COMPLIANT`. When an
organization-specific input has not been supplied, the validator is not
executed and the checkpoint is `CONFIG_VALUE_MISSING`. The evidence identifies
the variables to complete in `config/cis_unix_team_inputs.yml`.

The role can automatically remediate a control only when the installed
collection exposes its rule flag or this role supplies a tested custom task.
Unsupported failures remain visible in post-validation; they are never marked
compliant merely because no change occurred.
