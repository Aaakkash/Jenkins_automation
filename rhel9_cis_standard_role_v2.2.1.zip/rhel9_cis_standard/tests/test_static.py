from __future__ import annotations

import ast
import csv
import re
import subprocess
from pathlib import Path

import yaml


ROOT = Path(__file__).resolve().parents[1]


class UniqueLoader(yaml.SafeLoader):
    pass


def _mapping(loader, node, deep=False):
    result = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node, deep=deep)
        assert key not in result, f"duplicate YAML key: {key}"
        result[key] = loader.construct_object(value_node, deep=deep)
    return result


UniqueLoader.add_constructor(
    yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,
    _mapping,
)


def load_yaml(path: Path):
    return yaml.load(path.read_text(encoding="utf-8"), Loader=UniqueLoader)


def test_all_yaml_parses_without_duplicate_keys():
    for path in ROOT.rglob("*.yml"):
        load_yaml(path)


def test_checkpoint_inventory_is_complete_and_unique():
    with (ROOT / "files/checkpoints.csv").open(encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream))
    ids = [row["rule"] for row in rows]
    assert len(rows) == 221
    assert len(ids) == len(set(ids))
    assert {control.split(".", 1)[0] for control in ids} == set("1234567")


def test_every_checkpoint_is_processed_and_reported():
    with (ROOT / "files/checkpoints.csv").open(encoding="utf-8") as stream:
        ids = {row["rule"] for row in csv.DictReader(stream)}
    validators = load_yaml(ROOT / "vars/validators.yml")["cis_validators"]
    automatic = {
        control
        for control, value in validators.items()
        if value.get("type") == "automatic"
    }
    assert len(ids) == 221
    assert set(validators) == ids
    assert len(automatic) == 221
    assert len(ids - automatic) == 0

    validation = (ROOT / "tasks/validation.yml").read_text(encoding="utf-8")
    one = (ROOT / "tasks/validate_one.yml").read_text(encoding="utf-8")
    assert "loop: \"{{ cis_selected_checkpoints }}\"" in validation
    assert "cis_validator_catalog.cis_validators.get(cis_current_control_id)" in one
    assert "cis_validation_results + [" in one
    assert "CONFIG_VALUE_MISSING" in one


def test_mandatory_site_policy_is_loaded_and_guards_remediation():
    policy_path = ROOT / "config/cis_unix_team_inputs.yml"
    policy = load_yaml(policy_path)
    required = {
        "cis_site_policy_configured",
        "cis_unix_team_inputs_reviewed",
        "cis_ipv6_policy",
        "cis_firewall_backend",
        "cis_logging_backend",
        "cis_chrony_sources",
        "cis_service_decisions",
        "cis_approved_listening_services",
        "cis_remote_log_host",
        "cis_ssh_allowed_users",
        "cis_ssh_allowed_groups",
        "cis_local_login_banner_text",
        "cis_remote_login_banner_text",
        "cis_password_min_length",
        "cis_password_history",
        "cis_shell_timeout",
    }
    assert required.issubset(policy)
    assert policy["cis_site_policy_configured"] is False

    main = (ROOT / "tasks/main.yml").read_text(encoding="utf-8")
    load_position = main.index("Load mandatory site-policy configuration")
    validation_position = main.index("Run read-only pre-validation")
    assert load_position < validation_position
    assert "CONFIG_VALUE_MISSING" in main
    assert "when: cis_operation == 'remediate'" in main


def test_automatic_validators_have_commands_and_known_ids():
    with (ROOT / "files/checkpoints.csv").open(encoding="utf-8") as stream:
        ids = {row["rule"] for row in csv.DictReader(stream)}
    data = load_yaml(ROOT / "vars/validators.yml")
    validators = data["cis_validators"]
    assert set(validators).issubset(ids)
    automatic = {
        control: value
        for control, value in validators.items()
        if value.get("type") == "automatic"
    }
    assert len(automatic) == 221
    assert all(value.get("command", "").strip() for value in automatic.values())


def test_remediation_allowlist_is_known_and_automatically_validated():
    data = load_yaml(ROOT / "vars/validators.yml")
    validators = data["cis_validators"]
    allowlist = data["cis_remediation_allowlist"]
    assert len(allowlist) == len(set(allowlist))
    assert all(validators[item]["type"] == "automatic" for item in allowlist)
    assert "1.4.1" not in allowlist
    assert "3.1.1" in allowlist
    assert "6.2.3.8" not in allowlist

    disabled = load_yaml(ROOT / "vars/disable_all.yml")
    for control in allowlist:
        variable = f"rhel9cis_rule_{control.replace('.', '_')}_enabled"
        assert variable in disabled, f"missing collection flag for {control}"


def test_validation_commands_are_read_only():
    data = load_yaml(ROOT / "vars/validators.yml")
    commands = "\n".join(
        value.get("command", "")
        for value in data["cis_validators"].values()
        if value.get("type") == "automatic"
    )
    forbidden = [
        "check_mode: true",
        "sysctl -w",
        "systemctl enable",
        "systemctl disable",
        "systemctl mask",
        "chmod ",
        "chown ",
        "sed -i",
        "modprobe -r",
        "grubby --update-kernel",
        "update-crypto-policies --set",
        "dnf install",
        "dnf remove",
    ]
    for token in forbidden:
        assert token not in commands


def test_validation_commands_do_not_contain_jinja_comment_markers():
    data = load_yaml(ROOT / "vars/validators.yml")
    commands = "\n".join(
        value.get("command", "")
        for value in data["cis_validators"].values()
        if value.get("type") == "automatic"
    )
    assert "{#" not in commands
    assert "#}" not in commands


def test_automatic_validator_bash_syntax():
    data = load_yaml(ROOT / "vars/validators.yml")
    variables = data.copy()
    expression = re.compile(
        r"^{{\s*(\w+)\s*\|\s*replace\('([^']*)',\s*'([^']*)'\)\s*}}$"
    )
    for control, validator in data["cis_validators"].items():
        if validator.get("type") != "automatic":
            continue
        command = validator["command"]
        match = expression.match(command.strip())
        if match:
            source, old, new = match.groups()
            command = variables[source].replace(old, new)
        assert "{{" not in command, f"unresolved template in {control}"
        result = subprocess.run(
            ["bash", "-n"],
            input=command,
            text=True,
            capture_output=True,
            check=False,
        )
        assert result.returncode == 0, f"{control}: {result.stderr}"


def test_collection_is_not_used_as_validator():
    main = (ROOT / "tasks/main.yml").read_text(encoding="utf-8")
    validation = (ROOT / "tasks/validation.yml").read_text(encoding="utf-8")
    one = (ROOT / "tasks/validate_one.yml").read_text(encoding="utf-8")
    assert "check_mode: true" not in main
    assert "trippsc2.cis.rhel9" not in validation
    assert "trippsc2.cis.rhel9" not in one
    assert main.count("name: trippsc2.cis.rhel9") == 1
    assert "cis_operation == 'remediate'" in main
    assert "_rhel9cis_expected_crypto_policy" in main
    assert "NO-WEAKMAC" in main
    assert "rhel9cis_additional_crypto_subpolicies | default([])" in main


def test_nftables_remediation_selects_only_one_firewall_service():
    tasks = (ROOT / "tasks/remediate_nftables.yml").read_text(encoding="utf-8")
    assert "name: nftables" in tasks
    assert "name: firewalld.service" in tasks
    assert "state: stopped" in tasks
    assert "enabled: false" in tasks
    assert "masked: true" in tasks
    assert "name: nftables.service" in tasks
    assert "masked: false" in tasks
    assert "state: started" in tasks
    assert "enabled: true" in tasks


def test_tenable_alignment_regressions():
    data = load_yaml(ROOT / "vars/validators.yml")
    validators = data["cis_validators"]
    assert "/boot/efi/EFI" in validators["1.4.2"]["command"]
    assert "systemd-sysctl --cat-config" in data["cis_sysctl_policy_check"]
    for control in ["1.5.1", "1.5.2"] + [f"3.3.{i}" for i in range(1, 12)]:
        assert "cis_sysctl_policy_check" in validators[control]["command"]
    for control in [
        "1.1.2.1.2", "1.1.2.1.3", "1.1.2.1.4",
        "1.1.2.2.2", "1.1.2.2.3", "1.1.2.2.4",
        "1.1.2.3.2", "1.1.2.3.3", "1.1.2.4.2", "1.1.2.4.3",
        "1.1.2.5.2", "1.1.2.5.3", "1.1.2.5.4",
        "1.1.2.6.2", "1.1.2.6.3", "1.1.2.6.4",
        "1.1.2.7.2", "1.1.2.7.3", "1.1.2.7.4",
    ]:
        assert "cis_mount_policy_check" in validators[control]["command"]
    assert "[ -z \"$bad\" ]" in validators["1.6.4"]["command"]
    assert "sshd -T -C" in data["cis_sshd_effective_check"]
    assert "net.ipv6.conf.all.disable_ipv6" in validators["3.1.1"]["command"]
    assert "net.ipv6.conf.default.disable_ipv6" in validators["3.1.1"]["command"]
    assert "systemd-sysctl --cat-config" in validators["3.1.1"]["command"]
    assert "[ -n \"$value\" ] || exit 1" in validators["6.2.3.4"]["command"]
    assert validators["6.2.3.8"]["type"] == "automatic"


def test_callback_python_parses():
    callback = ROOT / "callback_plugins/rhel9_cis_csv_v2.py"
    ast.parse(callback.read_text(encoding="utf-8"))


if __name__ == "__main__":
    tests = sorted(
        (name, value)
        for name, value in globals().items()
        if name.startswith("test_") and callable(value)
    )
    for name, test in tests:
        test()
        print(f"PASS {name}")
