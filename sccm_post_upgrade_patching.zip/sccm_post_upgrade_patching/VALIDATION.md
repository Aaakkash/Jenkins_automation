# Validation performed

Date: 2026-10-30

- Both delivered PowerShell files passed the Windows PowerShell AST parser.
- Eight mocked client-state scenarios passed: clean no-op, active installation,
  service-window wait, reboot ready, reboot deferred while another install is active,
  exclusive batch completes with another update remaining, explicit error rejection,
  unknown compliance rejection.
- Reviewed task ownership gates, successful-validation-only removal, bounded polling,
  clean rescan convergence, exact-name matching, typed client API submissions and
  all include/file lookup paths.
- Cmdlet names/parameter sets and client APIs checked against Microsoft Learn; links
  and mapping are in docs/MICROSOFT_REFERENCES.md.
- ZIP CRC and manifest consistency verified during packaging.

Not run: ansible-playbook --syntax-check, ansible-lint, or live SCCM/Windows integration.
This environment has no Ansible installation, YAML parser or SCCM site access.
The files use standard Ansible YAML, including same-document YAML anchors.
Run the following on your Ansible controller before a lab deployment:

```sh
ansible-galaxy collection install -r requirements.yml
ansible-playbook -i examples/inventory.yml examples/patch.yml --syntax-check
```

Review the lab acceptance scenarios in README.md before production use.
