# SCCM post-upgrade patching — Windows Server 2022

An Ansible role that operates the SCCM/MECM site through a delegated Windows
management host, then uses each target's SCCM ClientSDK to patch it. The OS upgrade
itself is outside this role. Complete the upgrade and its reboot first.

## Prerequisites

- Linux/WSL Ansible controller, ansible-core 2.16+, Python WinRM/Kerberos dependencies,
  and the `ansible.windows` collection. Ansible is not run natively from Windows.
- Windows management host in inventory, Windows PowerShell 5.1, compatible SCCM
  console installed (ConfigurationManager module), and network access to SMS Provider.
- Target: Windows Server 2022, build 20348, discovered uniquely by its actual computer
  name in SCCM, healthy current SCCM client, CcmExec running, ClientSDK and machine
  policy WMI namespaces accessible, WUAHandler.log present. Normal Windows install
  path is supported; custom SCCM client/log paths require editing the scan path.
- Authenticated WinRM to management and targets; local administrator rights on targets.
  Use valid HTTPS certificates and store secrets in Vault or a secret manager.
- SCCM identity needs read device/collection/deployment permissions, add/remove
  membership rights on the dedicated collection, and create collection permission
  only if enabled. Apply least privilege/RBAC and security scopes in your site.
- A WinRM session to a management host does not automatically authenticate its next
  connection to a remote SMS Provider. Use Kerberos constrained delegation configured
  by your AD team, an appropriate management-host execution identity (for example a
  separately configured become/runas account), or run the management endpoint on the
  provider. Do not enable CredSSP broadly to work around double-hop failures.
- Approved software update deployments already exist, are enabled and available on
  the selected collection, contain updates for Server 2022, and have distributed
  content, correct boundaries/DP access and working SUP/WSUS connectivity.
- Use a dedicated collection with no unrelated deployments. Review all deployments
  on it, including applications, scripts, baselines and task sequences: membership
  may activate them immediately. The role does not create deployments or change
  maintenance windows, deadlines, restart policies or content distribution.
- Schedule an approved maintenance window with reboot permission and ensure SCCM's
  deployment settings match it. Application owners must define service checks and
  any external health checks. Set serial: 1 and prevent overlapping jobs for the
  same device/collection. The role does not provide a distributed lock.

## Run

Extract the ZIP and work from its `sccm_post_upgrade_patching` directory:

```sh
ansible-galaxy collection install -r requirements.yml
# Install pywinrm and the Kerberos dependencies suitable for your controller.
# Edit inventory, site, collection, approved deployment names and Vault secrets.
ansible-playbook -i examples/inventory.yml examples/patch.yml --ask-vault-pass
```

`ansible.cfg` supplies the bundled roles path. If copying the role into another
project, place `roles/sccm_post_upgrade_patching` in that project's role search path.
The management inventory alias is not a patch target. Credentials and delegation
variables come from that host's inventory. Check mode fails explicitly; it cannot
predict SCCM asynchronous client behavior safely. Start with one lab server.

## Behavior and safety

1. Confirm Server 2022/client health and reject any preexisting reboot requirement.
2. Find exactly one discovered device and an exact collection name. Optionally
   create the collection with an explicitly supplied limiting collection ID.
3. Require each named deployment on that collection to be uniquely found, enabled,
   available now and nonempty before adding the target. A newly created collection
   normally has no deployments: this run stops safely, leaving the empty collection
   for an administrator to deploy approved updates, then rerun. It never deploys a
   software update group automatically.
4. Check both effective membership and direct rules. Existing effective membership
   (including query/include membership) and unevaluated existing direct rules are
   preserved. Only add when neither exists, then request evaluation and poll actual
   membership. Limiting/exclude rules can prevent membership and cause timeout.
5. Request/evaluate machine policy and wait for expected deployment assignment GUIDs
   in ActualConfig. Request a scan and require a fresh successful WUAHandler.log
   completion marker; trigger update evaluation and allow state propagation.
6. Submit missing applicable deployed updates through ClientSDK. Exclusive updates
   are submitted individually; upgrades are rejected. Monitor compliance, evaluation
   state, percent and error codes. Error/unknown compliance fails; service-window,
   orchestration, content and other waits remain bounded by the poll budget.
7. Reboot only with explicit `sccm_allow_reboot: true`; wait for connectivity and
   repeat fresh scan rounds. A run needs an additional clean round after installation
   or reboot; increase max_rounds for exclusive/dependent updates.
8. Require a clean round, zero remaining missing deployed updates, no pending reboot,
   Server 2022/client health and all configured services running. Remove a direct
   rule only if added by this invocation and validation succeeded. Verify the rule
   disappeared and request collection reevaluation. Other membership sources remain.

**Installation scope:** ClientSDK enumerates applicable, not-yet-installed updates
deployed to the client from ALL its collections. The deployment-name list is a
policy readiness gate, not an update allowlist. Setting
`sccm_acknowledge_all_deployed_updates: true` acknowledges this behavior. No internet
Microsoft Update fallback is used. A fresh successful scan with no applicable
deployed updates is a valid no-op; this does not prove every Microsoft patch is
installed or that an expected KB was deployed. Define organizational compliance
and application acceptance checks separately.

**Failure ownership:** Nothing removes membership on a failure path. A failed or
interrupted run can leave the added direct rule, or a newly created collection.
Ansible unreachable/controller loss may bypass rescue; cleanup is never in `always`.
Ownership is intentionally per invocation, held in controller facts. On rerun a
retained rule is preexisting and will NOT be removed automatically even after success.
Reconcile the prior job's logs and remove that rule manually after approval. Do not
infer ownership from a collection name. An error after server-side add but before
the controller receives its result also requires manual reconciliation. Concurrent
membership edits can invalidate ownership assumptions; serialize jobs and changes.

Cleanup failure fails the play even if patch validation passed. Effective collection
removal is asynchronous and can persist through include/query rules. Removing the
rule does not cancel updates/policy already received or roll back installed patches.

SCCM deployments can themselves initiate restarts. This role cannot prevent those
restarts; configure deployment restart behavior for automation coordination. An
unexpected restart during a task conservatively fails/retains membership; investigate
and rerun. The role does not disable SCCM or force maintenance-window overrides.

## Variables

See `roles/sccm_post_upgrade_patching/defaults/main.yml` for every default.

| Variable | Default / purpose |
| --- | --- |
| sccm_management_host | Required inventory alias |
| sccm_site_code / sccm_provider_server | Required 3-character site / provider FQDN |
| sccm_module_path | Standard console module path; override for your installation |
| sccm_collection_name | Required dedicated collection exact name |
| sccm_create_collection | false; never creates deployments |
| sccm_limiting_collection_id | Required for creation; choose a narrow limiting scope |
| sccm_deployment_names | Required list of exact existing deployment names |
| sccm_acknowledge_all_deployed_updates | false; must explicitly become true |
| sccm_allow_reboot | false; fails safely if a reboot is required |
| sccm_reboot_timeout | 1800 seconds for win_reboot (module phases may each use this) |
| sccm_max_rounds | 3; includes final clean validation scan round |
| sccm_poll_seconds / sccm_poll_retries | 30 / 120; per membership/installation polling stage |
| sccm_policy_timeout / sccm_scan_timeout | 900 seconds per stage/round |
| sccm_client_settle_seconds | 60 after scan; minimum 30 |
| sccm_required_services | [] ; service names that must be running at validation |

These are per-stage budgets, not a global job deadline. Allow your automation
platform enough total runtime. WinRM operation timeouts are renewed while
win_powershell runs; keep read timeout greater than operation timeout.

## Troubleshooting and validation limits

Review task results, `sccm_prepare`, `sccm_install`, `sccm_status`, and
`sccm_validation`. Client logs: PolicyAgent.log, PolicyEvaluator.log, ScanAgent.log,
WUAHandler.log, UpdatesDeployment.log, UpdatesHandler.log, RebootCoordinator.log,
CAS.log and ContentTransferManager.log. Site membership: colleval.log. Site reporting
can lag client state; this role validates local client compliance, not immediate
console compliance percentages. Get-HotFix alone is not a complete SCCM audit.

The scan log reader only accepts appended completion evidence, rejects rotation/
truncation and times out without fresh success. Validate the English log marker
on your client version. No concurrent scans should run; a log marker is not a
transaction-ID correlated scan result. State propagation is asynchronous; increase
settle time for a slow site. These constraints deliberately fail rather than treat
an empty stale client query as scan success.

Microsoft cmdlet names/parameter sets and client methods were checked against
official documentation; see `docs/MICROSOFT_REFERENCES.md`. Offline structure and
PowerShell parser checks are recorded in `VALIDATION.md`. No SCCM infrastructure
was available for integration testing. Before production, test existing direct and
indirect membership, missing/disabled/future deployments, creation without a
deployment, policy/scan failure, install error, maintenance-window timeout, reboot
disabled/enabled, multiple/exclusive update rounds, failed health checks and
interrupted runs. Verify that failure always retains membership and that only a
successful run's newly added rule is removed.

License: MIT; see LICENSE.
