# Microsoft reference verification

Checked 2026-10-30 against Microsoft Learn. This is API/documentation verification, not a live SCCM certification.

- [Get-CMDevice](https://learn.microsoft.com/en-us/powershell/module/configurationmanager/get-cmdevice?view=sccm-ps)
- [Get-CMDeviceCollection](https://learn.microsoft.com/en-us/powershell/module/configurationmanager/get-cmdevicecollection?view=sccm-ps)
- [New-CMDeviceCollection](https://learn.microsoft.com/en-us/powershell/module/configurationmanager/new-cmdevicecollection?view=sccm-ps)
- [Get-CMCollectionMember](https://learn.microsoft.com/en-us/powershell/module/configurationmanager/get-cmcollectionmember?view=sccm-ps)
- [Get-CMDeviceCollectionDirectMembershipRule](https://learn.microsoft.com/en-us/powershell/module/configurationmanager/get-cmdevicecollectiondirectmembershiprule?view=sccm-ps)
- [Add-CMDeviceCollectionDirectMembershipRule](https://learn.microsoft.com/en-us/powershell/module/configurationmanager/add-cmdevicecollectiondirectmembershiprule?view=sccm-ps)
- [Remove-CMDeviceCollectionDirectMembershipRule](https://learn.microsoft.com/en-us/powershell/module/configurationmanager/remove-cmdevicecollectiondirectmembershiprule?view=sccm-ps)
- [Invoke-CMCollectionUpdate](https://learn.microsoft.com/en-us/powershell/module/configurationmanager/invoke-cmcollectionupdate?view=sccm-ps)
- [Get-CMSoftwareUpdateDeployment](https://learn.microsoft.com/en-us/powershell/module/configurationmanager/get-cmsoftwareupdatedeployment?view=sccm-ps)
- [TriggerSchedule](https://learn.microsoft.com/en-us/intune/configmgr/develop/reference/core/clients/client-classes/triggerschedule-method-in-class-sms_client)
- [CCM_SoftwareUpdate](https://learn.microsoft.com/en-us/intune/configmgr/develop/reference/core/clients/sdk/ccm_softwareupdate-client-wmi-class)
- [InstallUpdates](https://learn.microsoft.com/en-us/intune/configmgr/develop/reference/core/clients/sdk/installupdates-method-in-class-ccm_softwareupdatesmanager)
- [Scan evidence](https://learn.microsoft.com/en-us/troubleshoot/mem/configmgr/update-management/track-software-update-compliance-assessment)
- [Deployment policy flow](https://learn.microsoft.com/en-us/troubleshoot/mem/configmgr/update-management/track-software-update-deployment-process)

Parameter mapping used by the role:

| API | Parameters/behavior checked |
| --- | --- |
| Get-CMDevice | Name, DisableWildcardHandling; exact name filtered again; require unique ResourceID |
| Get-CMDeviceCollection | Name; exact equality filter |
| New-CMDeviceCollection | Name, LimitingCollectionId, Comment |
| Get-CMCollectionMember | CollectionId, ResourceId; effective membership |
| Get/Add/Remove direct rule | CollectionId; ResourceId for add/remove; Force for remove |
| Invoke-CMCollectionUpdate | CollectionId; asynchronous evaluation requires polling |
| Get-CMSoftwareUpdateDeployment | CollectionId; inspect full assignment objects, not summary objects |
| TriggerSchedule | sScheduleID suffix 021 request policy, 022 evaluate policy, 113 scan, 108 evaluate updates |
| InstallUpdates | CCMUpdates typed CIM instance array; check ReturnValue, then monitor |
| CCM_SoftwareUpdate | ComplianceState determines applicability; EvaluationState tracks progress; ErrorCode is checked |

All ConfigurationManager cmdlets run inside a CMSite drive. No nonexistent
Install-CMSoftwareUpdate client command or generic Windows Update installer is used.
Scan completion uses the documented WUAHandler marker and requires newly appended
content. This log-based completion check is deliberately conservative and may fail
on localized/custom logging, rotation, or concurrent scan activity; validate in your lab.
