# Windows Server 2016 to 2022 In-Place Upgrade — UAT

This project implements the client-approved flow:

`Jenkins → Azure Repos → CyberArk-backed Jenkins credentials → Ansible controller → UAT Windows server`

The first Jenkins run is safe by default: compatibility scanning is enabled and the real upgrade is disabled.

## Important design rules

- Scope is one non-production Windows Server 2016 Desktop Experience VM at a time.
- The ISO is copied directly by the target from the DFS path; no DFS credential is stored.
- An approved SHA-256 value is mandatory.
- The vCenter snapshot excludes VM memory and is verified by exact snapshot name/ID.
- SQL backup is owned by the DBA team. Automation detects SQL and reports it but does not validate a database backup.
- CredSSP is not used for the Ansible control connection. Its original target-server state is captured and changed only when `ENABLE_CREDSSP_DURING_UPGRADE=true`.
- `MSSQLSERVER` and `IISADMIN` are stopped only after an explicit pipeline approval and restored to their recorded states.
- Snapshot revert is disabled by default and is attempted only after Setup launch when explicitly approved.
- Snapshot cleanup is a separate approved action after the stability window.

## Configure before UAT

1. Replace the sample host and vCenter mapping in `inventories/uat/hosts.yml`.
2. Update `inventories/uat/group_vars/windows_upgrade.yml` with the DFS ISO path, local ISO path, ISO SHA-256, vCenter datacenter/folder and notification addresses.
3. Configure Jenkins credentials supplied by the CyberArk provider:
   - `cyberark-windows-upgrade-admin`
   - `cyberark-vcenter-upgrade-api`
   Required Jenkins capabilities/plugins are Pipeline, Git/Azure Repos SCM,
   Credentials Binding, CyberArk credential provider, and Email Extension.
4. Install Python dependencies on the Ansible controller:

   ```bash
   python3 -m pip install -r requirements.txt
   ansible-galaxy collection install -r requirements.yml
   ```

5. Configure WinRM HTTPS (5986) and an internal-CA certificate. The sample uses NTLM so Ansible can connect even when target CredSSP is initially disabled. Use Kerberos instead if your enterprise controller is configured for it.

## Recommended UAT sequence

1. Run with `RUN_COMPATIBILITY_SCAN=false`, `RUN_UPGRADE=false` to test connectivity, ISO staging and assessment.
2. Run with `RUN_COMPATIBILITY_SCAN=true`, `RUN_UPGRADE=false` to create/verify the snapshot and run scan-only.
3. Review `reports/*-assessment.json`, `*-snapshot.json`, and `*-compatibility.json`.
4. Obtain Windows/DBA/change approvals.
5. Run with `RUN_UPGRADE=true`. Keep snapshot recovery and .NET remediation disabled unless separately approved.
6. Review the postcheck/final reports and complete application-owner validation.
7. After the stability window, rerun with `APPLICATION_VALIDATION_PASSED=true` to remove the snapshot.

## Local commands

Connectivity:

```bash
export WIN_USER='DOMAIN\\service-account'
export WIN_PASS='retrieved securely at runtime'
ansible windows_upgrade -i inventories/uat/hosts.yml -m ansible.windows.win_ping
```

Assessment only:

```bash
ansible-playbook -i inventories/uat/hosts.yml playbooks/01_assess.yml \
  --limit win2016-uat-01.example.com \
  -e change_number=CHG0000001 \
  -e upgrade_reboot_if_pending=false
```

Do not put credentials, product keys, real email addresses, or approved checksums into source control unless your policy explicitly permits the non-secret value.
