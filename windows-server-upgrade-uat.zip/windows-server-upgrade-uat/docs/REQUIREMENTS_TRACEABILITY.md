# Requirement Traceability

| Step | Implementation |
|---|---|
| Jenkins/Azure Repos/CyberArk/Ansible | `Jenkinsfile`; CyberArk-backed Jenkins credential IDs |
| WinRM and admin validation | `playbooks/00_connectivity.yml` |
| 2016 Desktop Experience assessment | `windows_upgrade_assessment` |
| Pending reboot approval | `upgrade_reboot_if_pending` and `ansible.windows.win_reboot` |
| DFS ISO and SHA-256 | `windows_upgrade_media` |
| SQL detection; DBA owns backup | Assessment/service report; no backup assertion |
| No-memory VM snapshot plus verification | `windows_upgrade_snapshot` using `vmware.vmware` modules |
| CredSSP capture/temporary enable/restore | `windows_upgrade_credssp` |
| Stop/restore MSSQLSERVER and IISADMIN | `windows_upgrade_service_control` |
| Native scan-only | `windows_upgrade_compatibility` |
| Multiple upgrade reboots | Scheduled task launcher plus WinRM disconnect/reconnect wait |
| OS, edition and activation | `windows_upgrade_postcheck` |
| Netlogon automatic/running | `windows_upgrade_postcheck` |
| SCCM, SCOM and Defender | Postcheck warnings and final notification |
| .NET Framework 4.8.1 | `windows_upgrade_dotnet`, approval and SHA-256 gated |
| Audit report and evidence | `windows_upgrade_reporting`, Jenkins archive/email |
| Snapshot stability/cleanup | Separate `06_cleanup_snapshot.yml` approval gate |
| Snapshot recovery | Exact-name revert, disabled by default and limited to post-Setup failures |
