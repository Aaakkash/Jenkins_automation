# UAT Test Plan

Run every case on a disposable Windows Server 2016 Desktop Experience VM with a confirmed rollback window.

| ID | Test | Expected result |
|---|---|---|
| UAT-01 | Invalid/not-in-inventory target | Jenkins stops before contacting a server |
| UAT-02 | WinRM or non-admin account | Connectivity playbook fails and writes a report |
| UAT-03 | ISO missing or wrong SHA-256 | Media stage fails; no snapshot or service change |
| UAT-04 | Pending reboot, approval false | Assessment blocks compatibility scan |
| UAT-05 | Pending reboot, approval true | One reboot occurs, Ansible reconnects and reruns assessment |
| UAT-06 | Unsupported OS/Core/DC/cluster | Assessment blocks with a clear reason |
| UAT-07 | SQL installed | Report shows SQL detected; no backup validation is attempted |
| UAT-08 | vCenter snapshot cannot be verified | Workflow stops before CredSSP, service stop or Setup |
| UAT-09 | CredSSP initially disabled, flag false | State is recorded and remains disabled |
| UAT-10 | CredSSP initially disabled, flag true | Enabled temporarily and restored to disabled |
| UAT-11 | MSSQLSERVER/IISADMIN running | States are recorded, services stop for scan/upgrade, then restore |
| UAT-12 | Compatibility blocker | Setup code/report captured; services/CredSSP restore; snapshot retained |
| UAT-13 | Compatibility pass, upgrade false | No OS upgrade starts; snapshot remains for review |
| UAT-14 | Upgrade approved | Scheduled task launches Setup; Ansible waits for WinRM return |
| UAT-15 | Postcheck | 2022, edition, activation, domain, Netlogon, services and .NET validated |
| UAT-16 | SCCM/SCOM/Defender issue | Warning appears in report and Windows-team notification is sent |
| UAT-17 | .NET 4.8.1 missing, remediation false | Workflow blocks and requests approval |
| UAT-18 | .NET 4.8.1 missing, remediation true | Installer checksum is verified, install/repair runs, reboot if required |
| UAT-19 | Failure after Setup launch, recovery false | Snapshot retained; teams notified; no automatic revert |
| UAT-20 | Failure after Setup launch, recovery true | Exact verified snapshot is reverted; teams notified |
| UAT-21 | Cleanup without sign-off | Snapshot removal is blocked |
| UAT-22 | Cleanup after sign-off/stability window | Only the workflow snapshot is removed |

UAT acceptance requires evidence for all applicable cases, Windows-team consent, DBA acknowledgement for SQL hosts, and application-owner sign-off.
