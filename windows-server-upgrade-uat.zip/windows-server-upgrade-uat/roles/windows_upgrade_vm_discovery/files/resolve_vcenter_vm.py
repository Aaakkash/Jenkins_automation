#!/usr/bin/env python3
"""Resolve vCenter VM metadata from the VCCombined XLSX export."""

from __future__ import annotations

import argparse
import json
import re
import sys
import unicodedata
from pathlib import Path

from openpyxl import load_workbook


def normalize_header(value: object) -> str:
    return re.sub(r"[^a-z0-9]", "", str(value or "").strip().lower())


def normalize_host(value: object) -> str:
    text = unicodedata.normalize("NFKC", str(value or ""))
    short_name = text.strip().casefold().split(".", 1)[0]
    return re.sub(r"[^a-z0-9_-]", "", short_name)


def find_column(headers: dict[str, int], *candidates: str) -> int | None:
    for candidate in candidates:
        index = headers.get(normalize_header(candidate))
        if index is not None:
            return index
    return None


def find_header_row(sheet, scan_limit: int = 100):
    """Find the real header row; RVTools exports can contain title rows."""
    diagnostics: list[tuple[int, list[str]]] = []
    for row_number, row in enumerate(
        sheet.iter_rows(min_row=1, max_row=scan_limit, values_only=True), start=1
    ):
        headers = {
            normalize_header(value): index
            for index, value in enumerate(row)
            if value is not None and str(value).strip()
        }
        if headers:
            diagnostics.append((row_number, list(headers)[:12]))

        vm_col = find_column(headers, "VM", "VM Name", "Name")
        vc_col = find_column(headers, "VI SDK Server", "vCenter", "vCenter Server")
        dc_col = find_column(headers, "Datacenter")
        moid_col = find_column(headers, "VM ID", "MoID")
        if None not in (vm_col, vc_col, dc_col, moid_col):
            return row_number, headers, diagnostics
    return None, {}, diagnostics


def normalize_folder(datacenter: str, folder: str) -> str:
    """Convert /DC/Folder from the export to /DC/vm/Folder for VMware APIs."""
    folder = folder.strip().replace("\\", "/")
    datacenter = datacenter.strip().strip("/")
    if not folder:
        return f"/{datacenter}/vm"
    if not folder.startswith("/"):
        folder = f"/{folder}"
    if re.match(rf"^/{re.escape(datacenter)}/vm(?:/|$)", folder, re.I):
        return folder.rstrip("/")
    prefix = f"/{datacenter}"
    if folder.lower() == prefix.lower():
        return f"/{datacenter}/vm"
    if folder.lower().startswith(f"{prefix.lower()}/"):
        relative = folder[len(prefix) :].lstrip("/")
        return f"/{datacenter}/vm/{relative}".rstrip("/")
    return folder.rstrip("/")


def cell(row: tuple[object, ...], index: int | None) -> str:
    if index is None or index >= len(row):
        return ""
    return str(row[index] or "").strip()


def resolve(path: Path, target: str) -> dict[str, object]:
    """Filter the vInfo VM column first, then read metadata from that row."""
    target_short = normalize_host(target)
    if not target_short:
        raise ValueError("Target hostname is empty after normalization")

    workbook = load_workbook(path, read_only=True, data_only=True)
    matches: list[dict[str, object]] = []
    vm_samples: list[str] = []
    vm_count = 0

    try:
        sheet = next(
            (ws for ws in workbook.worksheets if ws.title.casefold() == "vinfo"),
            None,
        )
        if sheet is None:
            available = ", ".join(workbook.sheetnames)
            raise ValueError(
                f"Worksheet 'vInfo' was not found. Available sheets: {available}"
            )

        # Some RVTools/combined XLSX files contain an incorrect worksheet
        # dimension (for example, the XML reports only row 1 even though Excel
        # displays thousands of rows). ReadOnlyWorksheet trusts that value and
        # would otherwise return the header only. Reset it so openpyxl streams
        # the complete vInfo worksheet XML.
        reported_dimension = sheet.calculate_dimension(force=True)
        sheet.reset_dimensions()

        header_row_number, headers, _ = find_header_row(sheet)
        if header_row_number is None:
            raise ValueError("A supported header row was not found in worksheet 'vInfo'")

        columns = {
            "vm": find_column(headers, "VM", "VM Name"),
            "dns": find_column(headers, "DNS Name", "Guest Host Name", "Hostname"),
            "vcenter": find_column(
                headers, "VI SDK Server", "vCenter", "vCenter Server"
            ),
            "datacenter": find_column(headers, "Datacenter"),
            "folder": find_column(headers, "Folder"),
            "moid": find_column(headers, "VM ID", "MoID"),
            "uuid": find_column(headers, "VM UUID"),
            "powerstate": find_column(headers, "Powerstate", "Power State"),
            "connection_state": find_column(headers, "Connection state"),
        }

        required = {
            "VM": columns["vm"],
            "VI SDK Server": columns["vcenter"],
            "Datacenter": columns["datacenter"],
            "Folder": columns["folder"],
            "VM ID": columns["moid"],
        }
        missing = [name for name, index in required.items() if index is None]
        if missing:
            raise ValueError(
                "Missing required vInfo columns: " + ", ".join(missing)
            )

        rows = sheet.iter_rows(
            min_row=header_row_number + 1,
            values_only=True,
        )
        for row_number, row in enumerate(rows, start=header_row_number + 1):
            vm_name = cell(row, columns["vm"])
            if not vm_name:
                continue

            vm_count += 1
            if len(vm_samples) < 10:
                vm_samples.append(vm_name)

            # Filtering happens only on the VM column, as required.
            if normalize_host(vm_name) != target_short:
                continue

            datacenter = cell(row, columns["datacenter"])
            folder_export = cell(row, columns["folder"])
            matches.append(
                {
                    "sheet": sheet.title,
                    "reported_dimension": reported_dimension,
                    "row": row_number,
                    "target": target,
                    "vm_name": vm_name,
                    "dns_name": cell(row, columns["dns"]),
                    "match_source": "vInfo VM column",
                    "vcenter_hostname": cell(row, columns["vcenter"]),
                    "vcenter_datacenter": datacenter,
                    "vcenter_vm_folder_export": folder_export,
                    "vcenter_vm_folder": normalize_folder(
                        datacenter, folder_export
                    ),
                    "vcenter_vm_moid": cell(row, columns["moid"]),
                    "vcenter_vm_uuid": cell(row, columns["uuid"]),
                    "powerstate": cell(row, columns["powerstate"]),
                    "connection_state": cell(
                        row, columns["connection_state"]
                    ),
                }
            )
    finally:
        workbook.close()

    if not matches:
        samples = ", ".join(repr(value) for value in vm_samples) or "none"
        raise ValueError(
            f"Target {target!r} was not found in the vInfo VM column. "
            f"VM rows read: {vm_count}. First VM values: {samples}"
        )
    if len(matches) > 1:
        locations = ", ".join(
            f"{item['sheet']}!{item['row']}:{item['vcenter_hostname']}:{item['vcenter_vm_moid']}"
            for item in matches
        )
        raise ValueError(f"Multiple VCCombined records found for {target!r}: {locations}")

    result = matches[0]
    for required_key in (
        "vm_name",
        "vcenter_hostname",
        "vcenter_datacenter",
        "vcenter_vm_folder",
        "vcenter_vm_moid",
    ):
        if not result[required_key]:
            raise ValueError(
                f"VCCombined field {required_key!r} is empty for target {target!r}"
            )
    if not re.fullmatch(r"vm-\d+", str(result["vcenter_vm_moid"]), re.I):
        raise ValueError(
            f"Unexpected VM ID {result['vcenter_vm_moid']!r}; expected format vm-12345"
        )
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--file", required=True, type=Path)
    parser.add_argument("--target", required=True)
    args = parser.parse_args()
    try:
        print(json.dumps(resolve(args.file, args.target), sort_keys=True))
    except Exception as exc:  # concise message for Ansible/Jenkins
        print(str(exc), file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
 