param(
    [Parameter(Mandatory=$true)]
    [string]$IsoPath,

    [Parameter(Mandatory=$true)]
    [string]$ExpectedSha256,

    [Parameter(Mandatory=$true)]
    [string]$LogDirectory,

    [ValidateSet('enable','disable')]
    [string]$DynamicUpdateMode = 'disable'
)

$ErrorActionPreference = 'Stop'

$report = [ordered]@{
    compatible               = $false
    reason                   = 'Not started'
    hostname                 = $env:COMPUTERNAME
    timestamp_utc            = [DateTime]::UtcNow.ToString('o')

    iso_path                 = $IsoPath
    iso_sha256               = $null

    source_caption           = $null
    source_version           = $null
    source_edition           = $null
    source_installation_type = $null

    media_images             = @()
    target_image             = $null
    target_image_index       = $null

    mounted_drive            = $null
    setup_path               = $null

    exit_code_hex            = 'N/A'
    setup_log_directory      = $LogDirectory
}

$mountedHere = $false

try {

    New-Item -ItemType Directory `
             -Path $LogDirectory `
             -Force | Out-Null

    #
    # Validate ISO
    #
    if (-not (Test-Path -LiteralPath $IsoPath -PathType Leaf)) {
        throw "ISO not found: $IsoPath"
    }

    $actualHash = (
        Get-FileHash `
            -LiteralPath $IsoPath `
            -Algorithm SHA256
    ).Hash

    $report.iso_sha256 = $actualHash

    if ($actualHash -ine $ExpectedSha256) {
        throw "ISO SHA256 mismatch."
    }

    #
    # Source OS validation
    #
    $os = Get-CimInstance Win32_OperatingSystem

    $report.source_caption = $os.Caption
    $report.source_version = $os.Version

    $cv = Get-ItemProperty `
        'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion'

    $report.source_edition = $cv.EditionID
    $report.source_installation_type = $cv.InstallationType

    if ($cv.EditionID -ne 'ServerStandard') {
        throw "Expected ServerStandard. Found $($cv.EditionID)"
    }

    if ($cv.InstallationType -ne 'Server') {
        throw "Desktop Experience required. Found $($cv.InstallationType)"
    }

    #
    # Pending reboot check
    #
    $pendingReboot =
        (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending') -or
        (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired')

    if ($pendingReboot) {
        throw 'Pending reboot detected.'
    }

    #
    #
# Mount ISO
#
$disk = Get-DiskImage `
    -ImagePath $IsoPath `
    -ErrorAction SilentlyContinue

if (-not $disk) {

    Write-Host "ISO is not currently mounted. Mounting: $IsoPath"

    Mount-DiskImage `
        -ImagePath $IsoPath `
        -ErrorAction Stop | Out-Null

    $mountedHere = $true
}
elseif (-not $disk.Attached) {

    Write-Host "ISO found but not attached. Mounting: $IsoPath"

    Mount-DiskImage `
        -ImagePath $IsoPath `
        -ErrorAction Stop | Out-Null

    $mountedHere = $true
}

$volume = $null

for ($i = 1; $i -le 12; $i++) {

    Write-Host "Waiting for mounted ISO drive letter (attempt $i of 12)..."

    try {

        $volume = Get-DiskImage `
            -ImagePath $IsoPath `
            -ErrorAction SilentlyContinue |
            Get-Volume |
            Where-Object {
                $_.DriveLetter
            } |
            Select-Object -First 1

        if ($volume) {

            Write-Host "ISO mounted successfully as drive $($volume.DriveLetter):"

            break
        }
    }
    catch {
        Write-Host $_.Exception.Message
    }

    Start-Sleep -Seconds 5
}

if (-not $volume) {

    $allVolumes = Get-Volume |
        Select-Object DriveLetter,
                      DriveType,
                      FileSystemLabel

    throw @"
Mounted ISO has no drive letter after waiting 60 seconds.

Available Volumes:

$($allVolumes | Out-String)
"@
}

$root = "$($volume.DriveLetter):\"

$report.mounted_drive = $volume.DriveLetter

Write-Host "ISO Root: $root"

    #
    # Validate setup.exe
    #
    $setup = Join-Path $root 'setup.exe'

    if (-not (Test-Path $setup)) {
        throw 'setup.exe missing from ISO.'
    }

    $report.setup_path = $setup

    #
    # Find install.wim / install.esd
    #
    $install = @(
        'sources\install.wim',
        'sources\install.esd'
    ) |
    ForEach-Object {
        Join-Path $root $_
    } |
    Where-Object {
        Test-Path $_
    } |
    Select-Object -First 1

    if (-not $install) {
        throw 'install.wim/install.esd missing.'
    }

    #
    # Read image metadata
    #
    $images = @(Get-WindowsImage `
                    -ImagePath $install `
                    -ErrorAction Stop)

    $report.media_images = @(
        $images |
        Select-Object ImageIndex,
                      ImageName,
                      ImageDescription
    )

    #
    # MUST select Desktop Experience image
    #
    $target = $images |
        Where-Object {
            $_.ImageName -eq 'Windows Server 2022 SERVERSTANDARD'
        } |
        Select-Object -First 1

    if (-not $target) {

        $available = $images.ImageName -join ', '

        throw @"
Windows Server 2022 SERVERSTANDARD image not found.

Available images:
$available
"@
    }

    #
    # Safety check
    #
    if ($target.ImageName -match 'CORE') {
        throw "Desktop Experience server cannot be upgraded to Server Core."
    }

    $report.target_image       = $target.ImageName
    $report.target_image_index = $target.ImageIndex

    Write-Host "Selected Image: $($target.ImageName)"
    Write-Host "Selected Index: $($target.ImageIndex)"

    #
    # Compatibility Scan
    #
    $arguments = @(
        '/auto','upgrade',
        '/quiet',
        '/compat','scanonly',
        '/dynamicupdate',$DynamicUpdateMode,
        '/imageindex',$target.ImageIndex,
        '/copylogs',$LogDirectory,
        '/eula','accept'
    )

    $process = Start-Process `
        -FilePath $setup `
        -ArgumentList $arguments `
        -Wait `
        -PassThru `
        -ErrorAction Stop

    $hex = '0x{0:X8}' -f (
        [uint32]([int64]$process.ExitCode -band 0xFFFFFFFFL)
    )

    $report.exit_code_hex = $hex

    switch ($hex) {

        '0xC1900210' {
            $report.compatible = $true
            $report.reason = 'Windows Setup compatibility scan passed.'
        }

        '0xC1900208' {
            $report.reason = 'Application or driver compatibility blocker.'
        }

        '0xC1900204' {
            $report.reason = 'Migration choice unavailable.'
        }

        '0xC1900200' {
            $report.reason = 'System requirements not met.'
        }

        '0xC190020E' {
            $report.reason = 'Insufficient free space.'
        }

        '0xC1900215' {
            $report.reason = 'Windows Setup product key/image validation failed.'
        }

        default {
            $report.reason = "Setup returned $hex."
        }
    }
}
catch {
    $report.compatible = $false
    $report.reason = $_.Exception.Message
}
finally {

    if ($mountedHere) {
        try {
            Dismount-DiskImage `
                -ImagePath $IsoPath `
                -ErrorAction Stop | Out-Null
        }
        catch {
        }
    }

    $statusDir = Join-Path `
        (Split-Path $LogDirectory -Parent) `
        'Status'

    New-Item `
        -ItemType Directory `
        -Path $statusDir `
        -Force | Out-Null

    $reportFile = Join-Path `
        $statusDir `
        'compatibility_report.json'

    $report |
        ConvertTo-Json -Depth 10 |
        Set-Content `
            -Path $reportFile `
            -Encoding UTF8

    $Ansible.Result = $report
}