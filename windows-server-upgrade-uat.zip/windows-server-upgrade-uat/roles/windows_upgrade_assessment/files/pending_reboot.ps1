$ErrorActionPreference = 'Stop'
$pending = New-Object System.Collections.Generic.List[string]
if (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending') { $pending.Add('CBS') }
if (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired') { $pending.Add('WindowsUpdate') }
$session = Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' -Name PendingFileRenameOperations -ErrorAction SilentlyContinue
if ($null -ne $session -and $null -ne $session.PendingFileRenameOperations -and $session.PendingFileRenameOperations.Count -gt 0) { $pending.Add('PendingFileRenameOperations') }
$computerName = Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\ComputerName\ComputerName' -Name ComputerName
$activeName = Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\ComputerName\ActiveComputerName' -Name ComputerName
if ($computerName.ComputerName -ne $activeName.ComputerName) { $pending.Add('ComputerRename') }
[pscustomobject]@{ Pending = ($pending.Count -gt 0); Reasons = @($pending.ToArray()) } | ConvertTo-Json -Compress -Depth 4
