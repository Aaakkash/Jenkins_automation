param(
    [Parameter(Mandatory=$true)][string]$ReportPath,
    [Parameter(Mandatory=$true)][int]$MinimumFreeSpaceGB
)
$ErrorActionPreference = 'Stop'
$blockers = New-Object System.Collections.Generic.List[string]
$warnings = New-Object System.Collections.Generic.List[string]
try {
    $os = Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction Stop
    $cs = Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction Stop
    $cv = Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -ErrorAction Stop
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    $isAdmin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    if (-not $isAdmin) { $blockers.Add('Account is not a local administrator') }
    if ($os.Caption -notmatch 'Windows Server 2016' -or [string]$os.BuildNumber -ne '14393') { $blockers.Add('Source must be Windows Server 2016 build 14393') }
    if ($cv.EditionID -ne 'ServerStandard') { $blockers.Add("Edition must be ServerStandard; detected: $($cv.EditionID)") }
    if ($cv.InstallationType -ne 'Server') { $blockers.Add("Desktop Experience required; detected: $($cv.InstallationType)") }
    if ($os.OSArchitecture -notmatch '64') { $blockers.Add('64-bit Windows required') }
    if ($os.Caption -match 'Evaluation' -or $cv.EditionID -match 'Eval') { $blockers.Add('Evaluation edition is not supported by this workflow') }
    if ([int]$cs.DomainRole -ge 4) { $blockers.Add('Domain controller requires a separate approved upgrade procedure') }
    $cluster = Get-WindowsFeature -Name Failover-Clustering -ErrorAction Stop
    if ($cluster.Installed) { $blockers.Add('Failover Clustering installed; separate cluster-aware workflow required') }
    $driveLetter = $env:SystemDrive.TrimEnd(':')
    $disk = Get-CimInstance -ClassName Win32_LogicalDisk -Filter "DeviceID='$($env:SystemDrive)'" -ErrorAction Stop
    if (-not $disk) { throw 'Unable to query system drive free space' }
    $freeGB = [math]::Round(([double]$disk.FreeSpace / 1GB), 2)
    if ($freeGB -lt $MinimumFreeSpaceGB) { $blockers.Add("System drive free space $freeGB GB below minimum $MinimumFreeSpaceGB GB") }
    $setupProcesses = @(Get-Process -Name setup,setuphost,setupprep -ErrorAction SilentlyContinue)
    if ($setupProcesses.Count -gt 0) { $blockers.Add('Windows Setup process already running') }
    $pending = @()
    if (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending') { $pending += 'CBS' }
    if (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired') { $pending += 'WindowsUpdate' }
    $rename = Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' -Name PendingFileRenameOperations -ErrorAction SilentlyContinue
    if ($null -ne $rename -and $null -ne $rename.PendingFileRenameOperations -and $rename.PendingFileRenameOperations.Count -gt 0) { $pending += 'PendingFileRenameOperations' }
    $cn = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\ComputerName\ComputerName' -Name ComputerName).ComputerName
    $an = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\ComputerName\ActiveComputerName' -Name ComputerName).ComputerName
    if ($cn -ne $an) { $pending += 'ComputerRename' }
    if ($pending.Count -gt 0) { $blockers.Add("Pending reboot after restart/check: $($pending -join ', ')") }
    $services = @(Get-CimInstance -ClassName Win32_Service -Filter "StartMode='Auto'" -ErrorAction Stop | Select-Object Name, State, StartName)
    $report = [ordered]@{
        Hostname = $env:COMPUTERNAME
        TimestampUTC = (Get-Date).ToUniversalTime().ToString('o')
        Assessment = 'Windows Server 2016 Standard Desktop Experience'
        Status = $(if ($blockers.Count -eq 0) { 'PASS' } else { 'FAIL' })
        OS = [ordered]@{ Caption = $os.Caption; BuildNumber = $os.BuildNumber; EditionID = $cv.EditionID; InstallationType = $cv.InstallationType; Architecture = $os.OSArchitecture }
        DomainRole = $cs.DomainRole
        IsAdministrator = $isAdmin
        ClusterFeatureInstalled = [bool]$cluster.Installed
        SystemDrive = $env:SystemDrive
        FreeSpaceGB = $freeGB
        MinimumFreeSpaceGB = $MinimumFreeSpaceGB
        PendingRebootReasons = @($pending)
        AutomaticServices = @($services)
        Blockers = @($blockers.ToArray())
        Warnings = @($warnings.ToArray())
    }
    $json = $report | ConvertTo-Json -Depth 8
    $json | Set-Content -LiteralPath $ReportPath -Encoding UTF8 -ErrorAction Stop
    Write-Output $json
} catch {
    $reason = $_.Exception.Message
    $failure = [ordered]@{ Hostname=$env:COMPUTERNAME; TimestampUTC=(Get-Date).ToUniversalTime().ToString('o'); Status='FAIL'; Blockers=@("Assessment execution error: $reason") }
    $json = $failure | ConvertTo-Json -Depth 5
    $json | Set-Content -LiteralPath $ReportPath -Encoding UTF8
    Write-Output $json
}
