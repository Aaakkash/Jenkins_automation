"""Release behavior checks; never connect to a managed host."""
import ast
import csv
import importlib.util
import json
import os
import sys
from pathlib import Path

import pytest
import yaml

PROJECT = Path(__file__).resolve().parents[1]
ROLE = PROJECT/'roles/rhel9_cis_standard'
spec = importlib.util.spec_from_file_location('callback_fixture', PROJECT/'tests/test_callback_runtime.py')
fixture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture)

def load(name): return yaml.safe_load((ROLE/name).read_text())
def flatten(items):
    for item in items:
        yield item
        for key in ['block','rescue','always']:
            yield from flatten(item.get(key, []))

def emit(callback, host, connection='192.0.2.10', fallback='192.0.2.20', **extra):
    result = fixture.Result(dict(stage='final', operation='remediate', host=host,
        hostname=extra.pop('hostname',host), connection_address=connection, default_ipv4=fallback,
        results=[dict(control_id='1.4.2',phase=1,plugin_id='test',checkpoint='Ensure GRUB permissions',
                      status='NON_COMPLIANT',evidence='before')],
        post_results=[dict(control_id='1.4.2',status='COMPLIANT',evidence='after')],
        remediation_attempted=['1.4.2'], **extra))
    callback.v2_runner_on_ok(result)

@pytest.fixture
def report_env(tmp_path, monkeypatch):
    monkeypatch.delenv('RHEL9_CIS_CSV_OUTPUT', raising=False)
    monkeypatch.setenv('RHEL9_CIS_CSV_DIR',str(tmp_path))
    return tmp_path

def test_per_host_filename_ip_and_success(report_env):
    cb=fixture.module.CallbackModule()
    emit(cb,'alias-a',hostname='server-a')
    emit(cb,'alias-b',connection='192.0.2.11',hostname='server-b')
    cb.v2_playbook_on_stats(None)
    paths=sorted(report_env.glob('*.csv'))
    assert {p.name for p in paths} == {'rhel9_cis_results_server-a_192.0.2.10.csv','rhel9_cis_results_server-b_192.0.2.11.csv'}
    for path in paths:
        with path.open() as stream: rows=list(csv.DictReader(stream))
        assert len(rows)==1
        assert list(rows[0])[2]=='ip_address'
        assert rows[0]['final_status']=='REMEDIATION_COMPLETED'
        assert rows[0]['ip_address'] in path.name

@pytest.mark.parametrize('connection,fallback,expected',[
    ('server.example.com','192.0.2.20','192.0.2.20'),
    ('2001:db8::1','192.0.2.20','2001:db8::1'),
    ('not-an-ip','',''),
])
def test_ip_fallback_and_filename_sanitization(report_env,connection,fallback,expected):
    cb=fixture.module.CallbackModule();emit(cb,'host/unsafe',connection,fallback)
    cb.v2_playbook_on_stats(None)
    paths=list(report_env.glob('*.csv'));assert len(paths)==1
    with paths[0].open() as stream:row=next(csv.DictReader(stream))
    assert row['ip_address']==expected
    assert ':' not in paths[0].name and '/' not in paths[0].name

def test_alias_collision_does_not_overwrite(report_env):
    cb=fixture.module.CallbackModule()
    emit(cb,'alias-a',hostname='same');emit(cb,'alias-b',hostname='same')
    cb.v2_playbook_on_stats(None)
    assert len(list(report_env.glob('*.csv')))==2

def test_msb_failure_is_reported_without_claiming_login_success(report_env):
    cb=fixture.module.CallbackModule()
    emit(cb,'host-a',msb_status='FAILED',msb_output='AD join failed',
         msb_backup_details='File: /etc/security/opasswd\nBackup: /etc/security/backup_CIS_remediation_opasswd_test.bak')
    cb.v2_playbook_on_stats(None)
    with next(report_env.glob('*.csv')).open() as stream:row=next(csv.DictReader(stream))
    assert row['msb_status']=='FAILED'
    assert row['msb_output']=='AD join failed'
    assert '/etc/security/backup_' in row['msb_backup_details']

def test_native_group_commands_have_shared_backup_coverage():
    items=list(flatten(load('tasks/remediate_report_gaps.yml')))
    assert all('cis_command_with_backup' not in t for t in items)
    creation=next(t for t in items if t.get('name','').startswith('7.2.3 | Create missing groups'))
    assert creation['ansible.builtin.command']['argv']=='{{ item }}'
    planner=next(t for t in items if t.get('name')=='Plan existing files for selected remediation backups')
    code=planner['ansible.builtin.command']['argv'][-1]
    tree=ast.parse(code)
    coverage=[]
    for node in ast.walk(tree):
        if isinstance(node,ast.Dict):
            for k,v in zip(node.keys,node.values):
                if isinstance(k,ast.Constant) and k.value=='7.2.3':coverage.append(ast.literal_eval(v))
    assert any({'/etc/group','/etc/gshadow','/etc/group-','/etc/gshadow-'}.issubset(v) for v in coverage)

def test_msb_precedes_validation_and_failure_is_explicit():
    tasks=load('tasks/main.yml');names=[t['name'] for t in tasks]
    assert names.index('Run MSB recovery before final validation') < names.index('Run read-only post-validation')
    wrapper=next(t for t in tasks if t['name']=='Run MSB recovery before final validation')
    assert any('ansible.builtin.fail' in t for t in wrapper['rescue'])
    assert any('cis_operation' in c for c in wrapper['when'])
    ledger=next(t for t in tasks if t['name'].startswith('Initialize original-file ledger'))
    assert ledger['when']=='cis_run_file_backups is not defined'
    play=yaml.safe_load((PROJECT/'playbooks/remediate.yml').read_text())[0]
    assert 'any_errors_fatal' not in play

def test_msb_does_not_publish_a_second_original():
    tasks=load('tasks/post_remediation_msb.yml')
    backup=next(t for t in tasks if t.get('register')=='cis_msb_opasswd_backup_copy')
    assert 'cis_msb_prior_backups | length == 0' in backup['when']
    assert 'cis_msb_opasswd_needs_change | bool' in backup['when']
    assert backup['ansible.builtin.copy']['force'] is False
    join=next(t for t in tasks if 'ansible.builtin.expect' in t)
    assert 'cis_msb_ad_join_password' not in join['ansible.builtin.expect']['command']
    assert join['no_log'] is True

@pytest.mark.parametrize('exists,checksum,mode,uid,gid,expected',[
    (False,'','',0,0,True),
    (True,'old','0600',0,0,True),
    (True,'01ba4719c80b6fe911b091a7c05124b64eeece964e09c058ef8f9805daca546b','0600',0,0,False),
    (True,'01ba4719c80b6fe911b091a7c05124b64eeece964e09c058ef8f9805daca546b','0644',0,0,True),
])
def test_msb_history_reset_decision(exists,checksum,mode,uid,gid,expected):
    from jinja2 import Environment
    env=Environment()
    expr=next(t for t in load('tasks/post_remediation_msb.yml') if t['name'].startswith('MSB | Identify original ledger'))['ansible.builtin.set_fact']['cis_msb_opasswd_needs_change']
    result=env.compile_expression(expr.removeprefix('{{').removesuffix('}}').strip())(
        cis_msb_opasswd_before={'stat':dict(exists=exists,checksum=checksum,mode=mode,uid=uid,gid=gid)})
    assert result is expected

def test_embedded_python_and_jinja_parse():
    from jinja2 import Environment
    env=Environment()
    for file in ROLE.rglob('*.yml'):
        obj=yaml.safe_load(file.read_text())
        def check(x):
            if isinstance(x,str):env.parse(x)
            elif isinstance(x,dict):
                for value in x.values():check(value)
            elif isinstance(x,list):
                for value in x:check(value)
        check(obj)
    for t in flatten(load('tasks/remediate_report_gaps.yml')):
        cmd=t.get('ansible.builtin.command',{})
        if isinstance(cmd,dict):
            argv=cmd.get('argv',[])
            if isinstance(argv,list) and '-c' in argv:
                code=argv[argv.index('-c')+1]
                if isinstance(code,str) and '{{' not in code:ast.parse(code)

def test_callback_legacy_state_mapping(tmp_path,monkeypatch):
    monkeypatch.setenv('TEMP',str(tmp_path));monkeypatch.setenv('TMP',str(tmp_path))
    fixture.main()
