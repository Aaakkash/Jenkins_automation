# Standalone test project

Runtime role and callback are identical to the client package. Use a Linux controller and an isolated RHEL 9 test host. No server has been changed by preparing this package.

From this directory:

```bash
cp inventory.example.ini inventory.ini
cp config/cis_unix_team_inputs.example.yml config/cis_unix_team_inputs.yml
chmod 600 inventory.ini config/cis_unix_team_inputs.yml
ansible-galaxy collection install -r requirements.yml
```

Edit inventory.ini for the intended server and existing SSH/become credentials. Fill/review the local policy; template secrets are placeholders. Transfer your approved policy values from the original working config, including exclusions and MSB account/OU/password when applicable. The original ZIP and passwords have not been changed. Do not put real credentials into the example or commit the local files.

```bash
ansible --version
ansible-config dump --only-changed
ansible-playbook -i inventory.ini playbooks/validate.yml --syntax-check
ansible-playbook -i inventory.ini playbooks/remediate.yml --syntax-check
python3 -m pip install pytest PyYAML Jinja2
python3 -m pytest -q tests
```

Confirm the intended ansible.cfg is loaded. The Bash syntax test requires a usable Linux bash. Syntax-check does not traverse all dynamically included tasks; the remaining acceptance run is required.

```bash
export RHEL9_CIS_CSV_DIR="reports/$(date -u +%Y%m%dT%H%M%SZ)"
ansible-playbook -i inventory.ini playbooks/validate.yml --limit rhel9_test_01

# Review audit evidence and policy before executing changes.
ansible-playbook -i inventory.ini playbooks/remediate.yml --limit rhel9_test_01
```

Optional selection: `-e '{"cis_requested_control_ids":["1.4.1","1.4.2"]}'`. The config is loaded by include_vars; extra-vars can override selection. Do not use --check as a substitute for read-only `cis_operation=validate`: shell validators are skipped in check mode and cannot prove compliance.

Validate:

1. Correct filename/IP and one report per server. Repeated runs overwrite matching files in the same report directory; choose a fresh directory when needed.
2. Changed planned files have one original per playbook execution; unchanged candidates do not retain snapshots. Check real backup paths and contents, not CSV text alone. Directory metadata and undeclared package writes are outside this guarantee.
3. Test 7.2.3 using a controlled test account with a missing local primary GID. Confirm group creation, group database backup coverage and revalidation, including failure/retry paths. Do not create this condition on production accounts.
4. If MSB is enabled, verify adjacent opasswd original, history reset, AD membership, and active winbind/smb. Then test an approved local and AD login separately. Confirm MSB is before final validation and inspect the MSB columns.
5. GRUB 1.4.1 consumes a plain password and generates its hash; 1.4.2 consumes neither. Never use a hash as the plain-password variable.
6. Re-run validation, then the same licensed Tenable audit against the same host. Reconcile actual plugin evidence and scanner privileges; local validators alone do not certify Tenable compliance.

Examples use serial: 1 and intentionally omit any_errors_fatal. A failed host does not automatically stop the fleet. There is no automatic system/domain rollback; retain console/recovery access and follow your change procedure.

Local preparation result: 29 tests passed, 1 Bash check skipped on Windows. No real Ansible/RHEL/AD/Tenable acceptance run was completed here.
