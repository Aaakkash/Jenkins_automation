# Standard reusable RHEL 9 CIS role

`rhel9_cis_standard` is a single role intended for reuse in server-build and
in-place-upgrade projects.

One role call performs:

1. Configuration backup.
2. Pre-remediation validation in check mode.
3. Idempotent remediation; compliant controls remain unchanged.
4. Post-remediation validation in check mode.
5. Automatic per-checkpoint CSV generation.

There are no shell runner scripts, installed collection folders, reference
folders or manual CSV commands in this role.

## Prerequisites

The Ansible controller must already have:

- Ansible Core 2.19.13
- `trippsc2.cis` 1.4.2
- `ansible.posix` 3.0.0
- `community.general` 14.0.0

## Add the role to another project

Copy the complete `rhel9_cis_standard` folder to the project's `roles/`
directory:

```text
your-project/
├── ansible.cfg
├── inventory.ini
├── playbook.yml
└── roles/
    └── rhel9_cis_standard/
```

Add the following two settings to the project's `ansible.cfg`. This is a
one-time configuration that enables automatic CSV creation:

```ini
[defaults]
callback_plugins = ./roles/rhel9_cis_standard/callback_plugins
callbacks_enabled = rhel9_cis_csv
```

No Python command needs to be run manually. The callback writes the CSV when
the role reaches its final task and also writes a partial CSV if the play fails.

## Call one phase

```yaml
---
- name: Apply RHEL 9 CIS phase 03
  hosts: rhel9_targets
  gather_facts: true
  become: true
  serial: 1
  roles:
    - role: rhel9_cis_standard
      cis_phase: '03'
```

Run normally:

```bash
ansible-playbook -i inventory.ini playbook.yml
```

## Use it in an in-place upgrade project

```yaml
roles:
  - role: windows_upgrade_assessment

  - role: rhel9_cis_standard
    cis_phase: '03'
    when: ansible_os_family | default('') == 'RedHat'

  - role: windows_upgrade_post_validation
```

For a Linux upgrade project, place the CIS role at the required point in the
same way. The role does not require a wrapper script.

## Run every phase from one playbook

Use `example/run_all_phases.yml`, or include the role in a loop:

```yaml
- name: Run all CIS phases
  ansible.builtin.include_role:
    name: rhel9_cis_standard
  loop: ['01', '02', '03', '04', '05', '06', '07']
  loop_control:
    loop_var: selected_cis_phase
  vars:
    cis_phase: "{{ selected_cis_phase }}"
```

## Automatic output

Default CSV path on the Ansible controller:

```text
reports/rhel9_cis_results.csv
```

To use a different path, set an environment variable on the controller before
running the normal Ansible playbook:

```bash
export RHEL9_CIS_CSV_OUTPUT=/var/reports/project-cis-results.csv
```

Backups are stored on each managed server:

```text
/var/backups/rhel9-cis/<run-id>/phase<phase>/
```

## CSV fields

- `host`
- `phase`
- `control_id`
- `checkpoint`
- `pre_validation`
- `remediation_required`
- `remediation_changed`
- `remediation_completed`
- `post_validation`
- `final_status`

When no remediation is required, `final_status` is `COMPLIANT`. When drift is
corrected and post-validation is clean, `final_status` is
`REMEDIATION_COMPLETED` and `remediation_completed` is `YES`.
