"""Automatically generate a per-checkpoint CIS CSV report."""

from __future__ import annotations

import csv
import os
import re
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

from ansible.plugins.callback import CallbackBase


DOCUMENTATION = r"""
callback: rhel9_cis_csv
type: aggregate
short_description: Automatically writes the RHEL 9 CIS checkpoint CSV
version_added: "1.0"
requirements:
  - Enable with callbacks_enabled=rhel9_cis_csv
"""

CONTROL_RE = re.compile(r"(?<![0-9.])([1-7](?:\.\d+){1,5})(?![0-9.])")
STAGE_TAGS = {
    "cis_pre_validation": "pre_validation",
    "cis_remediation": "remediation",
    "cis_post_validation": "post_validation",
}


class CallbackModule(CallbackBase):
    CALLBACK_VERSION = 2.0
    CALLBACK_TYPE = "aggregate"
    CALLBACK_NAME = "rhel9_cis_csv"
    CALLBACK_NEEDS_ENABLED = True

    def __init__(self):
        super().__init__()
        self.started = datetime.now(timezone.utc)
        self.results = defaultdict(lambda: defaultdict(lambda: {
            "seen": False,
            "executed": False,
            "changed": False,
            "failed": False,
            "task": "",
        }))

    @staticmethod
    def _stage(task):
        tags = {str(tag) for tag in getattr(task, "tags", [])}
        for tag, stage in STAGE_TAGS.items():
            if tag in tags:
                return stage
        return None

    def _record(self, result, status):
        tags = {str(tag) for tag in getattr(result._task, "tags", [])}
        if "cis_csv_finalize" in tags or "RHEL9_CIS_CSV_FINALIZE" in result._task.get_name():
            self._write_report()
            return

        stage = self._stage(result._task)
        if not stage:
            return

        task_name = result._task.get_name().strip()
        controls = sorted(set(CONTROL_RE.findall(task_name)))
        if not controls:
            return

        data = result._result or {}
        for control in controls:
            state = self.results[(result._host.get_name(), control)][stage]
            state["seen"] = True
            state["executed"] |= status != "skipped"
            state["changed"] |= bool(data.get("changed", False))
            state["failed"] |= status in {"failed", "unreachable"}
            if not state["task"]:
                state["task"] = task_name

    def v2_runner_on_ok(self, result, **kwargs):
        self._record(result, "ok")

    def v2_runner_on_failed(self, result, ignore_errors=False):
        self._record(result, "failed_ignored" if ignore_errors else "failed")

    def v2_runner_on_unreachable(self, result):
        self._record(result, "unreachable")

    def v2_runner_on_skipped(self, result):
        self._record(result, "skipped")

    def v2_playbook_on_stats(self, stats):
        self._write_report()

    def _write_report(self):
        if not self.results:
            return

        output = Path(os.environ.get(
            "RHEL9_CIS_CSV_OUTPUT",
            "reports/rhel9_cis_results.csv",
        ))
        output.parent.mkdir(parents=True, exist_ok=True)

        rows = []
        for (host, control), stages in self.results.items():
            pre = stages["pre_validation"]
            remediation = stages["remediation"]
            post = stages["post_validation"]

            if pre["failed"]:
                final = "PRE_VALIDATION_FAILED"
            elif pre["seen"] and not pre["executed"]:
                final = "NOT_APPLICABLE"
            elif not pre["changed"]:
                final = "COMPLIANT"
            elif remediation["failed"]:
                final = "REMEDIATION_FAILED"
            elif post["failed"]:
                final = "POST_VALIDATION_FAILED"
            elif post["seen"] and not post["changed"]:
                final = "REMEDIATION_COMPLETED"
            elif post["changed"]:
                final = "NON_COMPLIANT_AFTER_REMEDIATION"
            else:
                final = "POST_VALIDATION_NOT_RECORDED"

            task = pre["task"] or remediation["task"] or post["task"]
            title = task.split("|", 1)[1].strip() if "|" in task else task
            rows.append({
                "generated_utc": datetime.now(timezone.utc).isoformat(),
                "host": host,
                "phase": control.split(".", 1)[0].zfill(2),
                "control_id": control,
                "checkpoint": title,
                "pre_validation": (
                    "NON_COMPLIANT" if pre["changed"] else
                    "NOT_APPLICABLE" if pre["seen"] and not pre["executed"] else
                    "COMPLIANT"
                ),
                "remediation_required": "YES" if pre["changed"] else "NO",
                "remediation_changed": "YES" if remediation["changed"] else "NO",
                "remediation_completed": "YES" if final == "REMEDIATION_COMPLETED" else "NO",
                "post_validation": (
                    "NON_COMPLIANT" if post["changed"] else
                    "COMPLIANT" if post["seen"] and post["executed"] else
                    "NOT_REQUIRED"
                ),
                "final_status": final,
            })

        fieldnames = [
            "generated_utc", "host", "phase", "control_id", "checkpoint",
            "pre_validation", "remediation_required", "remediation_changed",
            "remediation_completed", "post_validation", "final_status",
        ]
        with output.open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(sorted(rows, key=lambda row: (
                row["host"], row["phase"],
                [int(part) for part in row["control_id"].split(".")],
            )))

        self._display.display(f"RHEL 9 CIS CSV report: {output}", color="green")
