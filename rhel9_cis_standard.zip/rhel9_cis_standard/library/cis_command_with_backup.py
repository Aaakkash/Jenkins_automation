#!/usr/bin/python
"""Execute declared file-writing commands with recoverable pre-change copies.

Only regular files or absent paths are supported. Callers must declare ALL
affected paths; this module does not discover arbitrary command writes.
Unchanged snapshots are removed. Confirmed changed paths are returned as
file_backups for the CIS CSV callback, including partial command failures.
"""
from __future__ import annotations

import hashlib
import os
import shutil
import stat
import subprocess
import tempfile
from datetime import datetime, timezone

DOCUMENTATION = r"""
module: cis_command_with_backup
short_description: Back up declared files before a file-writing command
description:
  - Requires an explicit list of every file the supplied commands may modify.
  - Preserves pre-change file metadata using GNU cp --preserve=all.
  - Deletes temporary copies of files that did not change.
  - Does not inspect directories, package writes, services or undeclared paths.
  - Set no_log on calls carrying credentials in command arguments.
options:
  commands:
    description: Ordered commands, each supplied as a list of arguments.
    type: list
    elements: list
    required: true
  paths:
    description: Absolute regular-file paths affected by the commands.
    type: list
    elements: str
    required: true
  backup_root:
    description: Private backup storage root on the target host.
    type: path
    default: /var/backups/rhel9-cis
author: CIS automation
"""
EXAMPLES = r"""
- name: Create planned missing groups with file backups
  cis_command_with_backup:
    commands: '{{ cis_gid_create_commands }}'
    paths: [/etc/group, /etc/gshadow]
    backup_root: '{{ cis_backup_root }}'
"""


def fingerprint(path):
    try:
        info = os.lstat(path)
    except FileNotFoundError:
        return None
    if not stat.S_ISREG(info.st_mode):
        raise ValueError('Only regular files or absent paths are supported: ' + path)
    digest = hashlib.sha256()
    with open(path, 'rb') as stream:
        for part in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(part)
    attrs = tuple(sorted((key, os.getxattr(path, key, follow_symlinks=False))
                         for key in os.listxattr(path, follow_symlinks=False)))
    return (digest.hexdigest(), stat.S_IMODE(info.st_mode), info.st_uid,
            info.st_gid, info.st_mtime_ns, attrs)


def run_with_backup(commands, paths, backup_root, execute, cp_binary='/bin/cp', check=False):
    """execute(argv) returns (rc, stdout, stderr); no shell parsing is used."""
    work = None
    executed = []
    try:
        if not isinstance(commands, list) or not commands:
            raise ValueError('commands must contain at least one command')
        for argv in commands:
            if not isinstance(argv, list) or not argv or not all(isinstance(x, str) for x in argv):
                raise ValueError('Each command must be a nonempty list of strings')
        if not paths or any(not os.path.isabs(p) for p in paths):
            raise ValueError('Declare all affected files using absolute paths')
        if not os.path.isabs(backup_root):
            raise ValueError('backup_root must be an absolute path')
        paths = list(dict.fromkeys(os.path.normpath(p) for p in paths))
        before = {p: fingerprint(p) for p in paths}
        if check:
            return dict(changed=False, rc=0, file_backups=[], command_results=[],
                        msg='Check mode: commands and backups were not executed', planned_paths=paths)
        stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
        snapshots = {}
        if any(value is not None for value in before.values()):
            os.makedirs(backup_root, mode=0o700, exist_ok=True)
            work = tempfile.mkdtemp(prefix='.cis_prechange_' + stamp + '_', dir=backup_root)
            os.chmod(work, 0o700)
            for path, original in before.items():
                if original is None:
                    continue
                relative = path.lstrip('/') + '-backup_CIS_remediation_' + stamp
                copy = os.path.join(work, relative)
                os.makedirs(os.path.dirname(copy), mode=0o700, exist_ok=True)
                rc, stdout, stderr = execute([cp_binary, '--preserve=all', '--no-dereference', '--', path, copy])
                if rc:
                    raise ValueError('Pre-change backup failed for ' + path + ': ' + stderr)
                if fingerprint(path) != original or fingerprint(copy) != original:
                    raise ValueError('Backup verification failed or source changed concurrently: ' + path)
                snapshots[path] = relative
        failure = None
        for argv in commands:
            rc, stdout, stderr = execute(argv)
            executed.append(dict(cmd=argv, rc=rc, stdout=stdout, stderr=stderr))
            if rc:
                failure = dict(rc=rc, msg='File-writing command failed: ' + str(argv[0]))
                break
        changes = []
        for path in paths:
            after = fingerprint(path)
            if before[path] == after:
                if path in snapshots:
                    os.unlink(os.path.join(work, snapshots[path]))
                continue
            state = 'created' if before[path] is None else ('deleted' if after is None else 'modified')
            changes.append(dict(original_file=path, changed_file=path,
                                backup_file=None, change_type=state))
        retained = [entry for entry in changes if before[entry['original_file']] is not None]
        if work and retained:
            final = os.path.join(backup_root, 'changed_files_CIS_remediation_' + os.path.basename(work).split('.cis_prechange_', 1)[1])
            os.rename(work, final)
            work = final
            for entry in retained:
                entry['backup_file'] = os.path.join(final, snapshots[entry['original_file']])
        elif work:
            shutil.rmtree(work)
            work = None
        result = dict(changed=bool(changes), rc=0, file_backups=changes,
                      command_results=executed)
        if failure:
            result.update(failure, failed=True)
        return result
    except (OSError, ValueError) as error:
        result = dict(changed=bool(executed), failed=True, rc=2, msg=str(error),
                      file_backups=[], command_results=executed)
        if work and executed:
            result['recovery_snapshot_dir'] = work
        elif work:
            shutil.rmtree(work)
        return result


def main():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict(
        commands=dict(type='list', elements='list', required=True),
        paths=dict(type='list', elements='str', required=True),
        backup_root=dict(type='path', default='/var/backups/rhel9-cis'),
    ), supports_check_mode=True)
    cp_binary = module.get_bin_path('cp', required=True)

    def execute(argv):
        try:
            result = subprocess.run(argv, capture_output=True, text=True)
            return result.returncode, result.stdout, result.stderr
        except OSError as error:
            return 127, '', str(error)

    result = run_with_backup(module.params['commands'], module.params['paths'],
                             module.params['backup_root'], execute, cp_binary,
                             check=module.check_mode)
    failed = result.pop('failed', False)
    if failed:
        module.fail_json(**result)
    module.exit_json(**result)


if __name__ == '__main__':
    main()
 