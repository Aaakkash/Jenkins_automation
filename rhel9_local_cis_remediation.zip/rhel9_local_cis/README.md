# RHEL 9 local CIS remediation

This standalone role combines the local team's attached hardening tasks and the additional pasted tasks. It does not depend on a CIS collection. It uses ansible.builtin only. RHEL 8 is rejected. It is a hardening baseline, not a claim that 80 controls or every CIS requirement passes. Use the customer's exact Tenable audit after running.

## Files
- inventory.ini: target IP, SSH user, optional SSH key.
- config/cis_config.yml: all policy inputs and feature switches.
- site.yml: serial, one-host-at-a-time execution with before/after diagnostics.
- roles/local_cis/tasks/main.yml: remediation implementation.
- files/validate.py: read-only diagnostics (no shadow hashes in reports).
- No third-party Ansible collections are required.

## Configure before running
Use a working non-root SSH account with sudo. The role disables SSH root login by default and rejects root as its connection account. SSH keys are recommended; use --ask-pass only if password authentication is required. Use --ask-become-pass if sudo needs a password. Do not store passwords in inventory.

| Setting | What to enter |
|---|---|
| inventory ansible_host / ansible_user | Actual target IP and sudo account |
| cis_ntp_servers | Approved internal NTP names; [] preserves existing sources |
| cis_remove_packages | Remove packages only if not used by applications; NFS is preserved by default |
| cis_disable_modules | Remove usb-storage from list if USB storage is required |
| cis_mount_options | /home and /var restrictions; review application requirements; existing fstab mounts only |
| cis_kernel_enabled | false for hosts whose routing/network application conflicts with these settings |
| cis_banner / cis_ssh_settings | Approved banner and SSH policy |
| cis_crypto_policy | Empty preserves FIPS/custom policy; explicit full approved string changes it |
| cis_pam_enabled | true requires valid existing authselect profile with faillock/pwhistory support |
| cis_faillock_* | Local password lockout policy; default includes timed root lockout |
| cis_password_* | Local password quality/history/defaults; does not reset passwords or change current hashes |
| cis_cron_users / cis_at_users | Every user who must schedule jobs; defaults restrict to root |
| cis_journald_forward_to_syslog | false by default; assess logging architecture before changing |
| cis_aide_initialize / cis_aide_hour / cis_aide_minute | Initialize only first baseline; daily schedule; first run can take time |
| cis_grub_pbkdf2_hash | Optional Vault-protected grub2-mkpasswd-pbkdf2 result; empty skips password change |
| cis_fix_world_writable / cis_file_scan_roots | Optional permissions remediation only in reviewed roots; false/[] skips |
| cis_fix_dotfiles | Optional restrictive changes to selected shell dotfiles; false skips |

All other *_enabled settings select sections; these are configuration choices, not approval prompts. Inventory group and host names intentionally differ.

## Run from WSL/Linux controller
Requires a supported Ansible controller Python, ansible-core 2.19.x, SSH/sudo connectivity, and working RHEL repositories. Target uses /usr/bin/python3. Install dependencies on controller:

```bash
python3 -m pip install 'ansible-core>=2.19,<2.20'
ansible-inventory -i inventory.ini --graph
ansible rhel9_servers -i inventory.ini -m ansible.builtin.ping
ansible-playbook -i inventory.ini site.yml --syntax-check
ansible-playbook -i inventory.ini site.yml --limit phtlxsbupgr02 --ask-become-pass
```

Omit --ask-become-pass for passwordless sudo. Key authentication does not require -k. Once the test host is verified, remove --limit to process the inventory serially. This playbook deliberately rejects --check; several commands need actual target state. Use syntax-check and a test server.

## Behavior and verification
The role checks RHEL/authselect requirements, saves /etc and (when boot edits are enabled) /boot on the target, applies selected tasks, and always attempts before/after JSON reports under reports/ on the controller. A task failure still fails the play; always reporting does not turn failures into success. Unreachable hosts cannot guarantee a report. Backups contain credentials and stay root-only on the server; repeated runs consume space, so apply your retention policy.

SSH uses a dedicated Include at the start of sshd_config so earlier settings do not silently override a late 99-*.conf. sshd -t and effective values are checked before reload. Match-specific policies still need testing with the actual user/source context. A syntax-valid policy can still affect client compatibility. If validation fails, the changed file remains on disk for review; the running daemon is not reloaded by that step. Restore the configuration before any later daemon restart.

Authselect features are enabled on the current valid profile without --force or replacing SSSD/winbind selection. Password quality configuration only enforces policy where pam_pwquality is active; confirm your profile and review pwquality.conf.d overrides. Existing PAM module arguments can override faillock/history settings. Reports show current profile but are not a complete PAM policy audit.

Kernel settings are live/persistent. IPv6 sysctl tasks are skipped when default IPv6 facts are empty; that is not proof IPv6 is disabled. Module restrictions prevent future loads but loaded modules are not force-unloaded; plan a manual reboot and rescan. Boot argument changes likewise require a reboot to affect the running system. Crypto changes can require service restarts/reboot; none is automatic. DEFAULT is not a full CIS crypto policy.

AIDE initializes only if no active baseline exists and never replaces an existing active baseline. Existing daily jobs are preserved; remove duplicate legacy schedules after review. Cron must run and output needs monitoring. Chrony empty sources preserve configuration; verify actual synchronization with chronyc tracking. Services are restarted as necessary by this baseline (some every run); a second run is not guaranteed to report zero changes.

Separate /home or /var mounts absent from fstab are not created. Duplicate fstab entries require cleanup beforehand. World-writable optional scans use Ansible find and recurse across mounts; restrict roots carefully. Exclusions match basenames, not subtrees. Sticky bits are added without setting directories to 1777. Dotfile changes remove access rather than granting 0644 to private files.

Duplicate UID/GID, additional GID-0 groups and empty password fields are reported; identities/passwords are never automatically changed. The reports contain effective SSH settings, mounts, services, crypto policy and account diagnostics. Compare to config and run Tenable for full benchmark validation; the report is not an 80-control compliance score.

## Deliberate scope decisions
Satellite unregister/clean/force registration, release-unlock, full OS patching, OMI removal, old-kernel/rescue deletion and automatic reboot are excluded from this hardening role. Existing repository registration is preserved. nftables is installed but its service/rules are not enabled: firewall rollout needs approved rules, existing firewalld assessment and access testing; installing it alone is not firewall compliance. SELinux boot arguments are cleaned but runtime enforcing/type is not forced; investigate labeling/application readiness separately. Remote rsyslog routing, logrotate and all-log ownership policies were not supplied and are not invented. Obsolete RPM signing keys are not deleted. Existing password hashes/aging are not bulk changed. These gaps remain for the Unix team and Tenable rescan.

## Recovery
There is no automatic rollback of authentication or package changes. Use vCenter console access and a VM snapshot before the test run. The run prints /var/backups/local-cis/TIMESTAMP. Inspect its etc.tgz and boot.tgz before restoring selected files. For example, list with `tar -tzf /var/backups/local-cis/TIMESTAMP/etc.tgz`; restore the reviewed SSH configuration, then run `sshd -t` before reloading. Never extract an entire old /etc onto a running production host blindly. PAM feature changes also create authselect backups (`authselect backup-list` / `authselect backup-restore NAME`); use console access and the correct recorded backup. Filesystem, package, runtime sysctl, crypto, service and boot changes need corresponding recovery or snapshot restore; tar archives alone are not full rollback. Do not run Tenable results through a blanket chown or groupmod.

## References used for implementation
- https://docs.redhat.com/en/documentation/red_hat_enterprise_linux/9/html/configuring_authentication_and_authorization_in_rhel/configuring-user-authentication-using-authselect_configuring-authentication-and-authorization-in-rhel
- https://docs.redhat.com/en/documentation/red_hat_enterprise_linux/9/html/security_hardening/using-the-system-wide-cryptographic-policies_security-hardening

Validation of this deliverable: YAML parsing and Ansible syntax-check on controller. No execution against a RHEL target was possible here; perform a UAT run and Tenable rescan.
