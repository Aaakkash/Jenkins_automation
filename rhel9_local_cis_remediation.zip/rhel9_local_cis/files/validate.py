#!/usr/bin/env python3
"""Read-only diagnostics, not a CIS/Tenable certification engine."""
import subprocess,json,collections,os
results={}
def run(args):
 p=subprocess.run(args,text=True,capture_output=True)
 return {'rc':p.returncode,'stdout':p.stdout.strip(),'stderr':p.stderr.strip()}
for name,args in {
 'ssh_effective':['/usr/sbin/sshd','-T'],
 'authselect':['authselect','check'],
 'authselect_profile':['authselect','current'],
 'crypto_policy':['update-crypto-policies','--show'],
 'chrony_sources':['chronyc','sources'],
 'mounts':['findmnt','-o','TARGET,SOURCE,FSTYPE,OPTIONS'],
 'loaded_modules':['lsmod'],
 'selinux':['getenforce'],
 'aide_schedule':['cat','/etc/cron.d/local-cis-aide'],
 'services':['systemctl','is-active','sshd','chronyd','crond','rsyslog'],
}.items():
 try: results[name]=run(args)
 except OSError as e: results[name]={'error':str(e)}
for source,index,key in [('/etc/passwd',2,'duplicate_uids'),('/etc/group',2,'duplicate_gids')]:
 d=collections.defaultdict(list)
 for line in open(source):
  f=line.rstrip().split(':');d[f[index]].append(f[0])
 results[key]={k:v for k,v in d.items() if len(v)>1}
results['extra_gid0_groups']=[line.split(':')[0] for line in open('/etc/group') if line.split(':')[2]=='0' and line.split(':')[0]!='root']
results['empty_password_accounts']=[line.split(':')[0] for line in open('/etc/shadow') if line.split(':')[1]=='']
results['account_modes']={f:oct(os.stat(f).st_mode & 0o7777) for f in ['/etc/passwd','/etc/group','/etc/shadow','/etc/gshadow']}
results['aide_baseline_exists']=os.path.isfile('/var/lib/aide/aide.db.gz')
results['notice']='Diagnostics only. Duplicate IDs and empty passwords are reported, not changed. Compare effective settings with config; run Tenable after remediation. Existing loaded modules/boot/crypto changes may require manual reboot.'
print(json.dumps(results,indent=2))
