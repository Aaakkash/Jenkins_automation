# Ansible Collection: trippsc2.cis — RHEL 9-only adaptation

This package contains only the `trippsc2.cis.rhel9` role from the original collection. It applies selected CIS Red Hat Enterprise Linux 9 Benchmark v2.0.0 remediations according to role variables.

Use the accompanying `controller` project and its `group_vars/rhel9.yml` to run only the eight approved controls. The role's internal defaults enable many more rules and must not be used as an approved production profile without separate review.

Original project: <https://github.com/trippsoft/ansible-collection-cis>
