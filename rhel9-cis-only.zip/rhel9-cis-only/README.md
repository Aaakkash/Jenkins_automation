# RHEL 9 CIS collection and WSL execution project

This is a RHEL 9-only adaptation of `trippsc2.cis` 1.4.1. The collection source retains only the `rhel9` role. The `controller` project is configured to enable only these eight requested controls:

- 1.1.2.3.2 and 1.1.2.3.3: `nodev,nosuid` on `/home`
- 1.1.2.4.2 and 1.1.2.4.3: `nodev,nosuid` on `/var`
- 3.3.1: disable IPv4/IPv6 forwarding
- 3.3.2: disable IPv4 redirect sending
- 3.3.10: enable TCP SYN cookies
- 3.3.11: reject IPv6 router advertisements

Start with [controller/WSL_EXECUTION_GUIDE.md](controller/WSL_EXECUTION_GUIDE.md). The full role remains available in `collection/roles/rhel9`, but every non-requested rule is disabled by the supplied controller variables.

The source role is based on CIS Red Hat Enterprise Linux 9 Benchmark v2.0.0. Confirm that this is the benchmark/version required by the customer before production use.
