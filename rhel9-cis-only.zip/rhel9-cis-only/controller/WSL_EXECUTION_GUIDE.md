# Execute the RHEL 9 CIS role from VS Code connected to WSL

## 1. Prerequisites

- VS Code is connected to **WSL: Ubuntu**.
- WSL can reach the RHEL 9 VM on TCP 22.
- The RHEL 9 VM has Python 3, SSH and a user with sudo access.
- `/home` and `/var` are already separate filesystems. The role does not create partitions.
- A VM snapshot/backup and console access are available.
- The server is not a router/NAT/Kubernetes host that requires IP forwarding, and it does not rely on IPv6 router advertisements.

Run every command below in the VS Code WSL terminal, not PowerShell or Command Prompt.

## 2. Prepare Ansible in WSL

```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip openssh-client unzip
cd ~/projects/rhel9-cis-only
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install 'ansible-core>=2.16,<2.20' jmespath
```

Install required third-party collections:

```bash
cd controller
ansible-galaxy collection install -r requirements.yml -p ../installed_collections
```

If Galaxy reports `certificate verify failed`, install the corporate root CA supplied by your IT team in WSL. Do not use `--ignore-certs` for production work.

Install this local RHEL 9-only collection without contacting Galaxy:

```bash
ansible-galaxy collection install ../dist/trippsc2-cis-1.4.2.tar.gz -p ../installed_collections --no-deps --force
ansible-galaxy collection list -p ../installed_collections
```

Expected local collection: `trippsc2.cis 1.4.2`. Confirm `ansible.posix` and `community.general` are also listed.

## 3. Configure SSH

Create a key if you do not already have one:

```bash
ssh-keygen -t ed25519
ssh-copy-id ansible@RHEL9_SERVER_IP
ssh ansible@RHEL9_SERVER_IP
```

Accept the host key only after verifying its fingerprint with the Linux/server team. Exit the SSH session and edit `inventory/hosts.ini` with the real IP, SSH user and remote Python path. Never store a password in the inventory.

Test from the `controller` directory:

```bash
ansible-inventory --graph
ansible rhel9 -m ansible.builtin.ping
ansible rhel9 -b -K -m ansible.builtin.command -a 'id -u'
```

Use `-k` only if policy requires an SSH password; `-K` asks for the sudo password.

## 4. Perform mandatory prechecks

```bash
ansible-playbook playbooks/precheck.yml -K
```

Stop if the target is not RHEL 9, sudo fails, `/home` or `/var` is not a separate active mount, or any required sysctl key is unavailable.

Before remediation, take a VM snapshot and capture:

```bash
ansible rhel9 -b -K -m ansible.builtin.shell -a 'cp -a /etc/fstab /root/fstab.before-rhel9-cis && sysctl -a > /root/sysctl.before-rhel9-cis.txt'
```

Run that command once. Do not overwrite a useful baseline from an earlier change. Also review application, routing and maintenance approvals.

## 5. Review check mode and apply

Check syntax:

```bash
ansible-playbook playbooks/remediate.yml --syntax-check
```

Preview supported changes:

```bash
ansible-playbook playbooks/remediate.yml -K -e cis_apply_confirm=true --check --diff
```

Check mode cannot prove that remounts, kernel changes, handlers or reboot persistence will work. Review the output, then apply during the approved window:

```bash
ansible-playbook playbooks/remediate.yml -K -e cis_apply_confirm=true --diff
```

The supplied variables keep `rhel9cis_skip_reboot: true`. The role updates persistent `/home` and `/var` mount configuration but does not reboot automatically. Reboot through the approved operational process after reviewing `/etc/fstab` and confirming console recovery access.

## 6. Validate and test idempotency

After the approved reboot:

```bash
ansible-playbook playbooks/validate.yml -K
ansible-playbook playbooks/remediate.yml -K -e cis_apply_confirm=true
```

The validation playbook must report `failed=0`. The second remediation run should ideally report `changed=0`. Run the customer's CIS scanner and application/network regression tests as the final evidence.

## 7. Important scope

`group_vars/rhel9.yml` disables all collection rules and re-enables only the eight approved controls. Do not replace it with the role's defaults unless a full CIS hardening project has been reviewed. The original role applies the combined configured mount option list whenever either selected `/home` or `/var` mount rule is enabled.

For rollback, prefer restoring the VM snapshot. A targeted rollback must restore the captured `/etc/fstab`, restore the seven previous sysctl runtime/persistent values, reboot through console access and validate networking and applications.
